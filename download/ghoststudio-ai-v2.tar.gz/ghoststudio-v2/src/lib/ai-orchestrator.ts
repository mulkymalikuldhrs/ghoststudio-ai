/**
 * AI Orchestrator v2.0 — The central brain of GhostStudio AI
 *
 * Routes tasks to appropriate agents based on type.
 * Manages model tier selection (cheap/mid/premium).
 * Coordinates multi-step pipelines:
 *   - Content Pipeline: draft → humanic → SEO → score → repurpose → publish
 *   - Video Pipeline: script → image → voice → compose → publish
 *   - Heatmap Pipeline: detect → clip → subtitle → publish
 * Tracks costs per operation.
 * Logs all operations to SystemLog.
 * Error handling with fallbacks.
 *
 * Uses `z-ai-web-dev-sdk` for LLM calls.
 */

import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';
import { getAgent, listAgents, type ModelTier, type AgentEngine } from '@/lib/agents';

// ─── Model Tier Configuration ────────────────────────────────────────────────

export const MODEL_MAP: Record<ModelTier, string> = {
  cheap: 'openai/gpt-4o-mini',
  mid: 'anthropic/claude-3.5-sonnet',
  premium: 'anthropic/claude-3-opus',
};

// Task-to-tier routing table
export const TASK_MODEL_MAP: Record<string, ModelTier> = {
  tagging: 'cheap',
  formatting: 'cheap',
  metadata: 'cheap',
  image_prompt: 'cheap',
  summary: 'mid',
  seo: 'mid',
  repurpose: 'mid',
  scoring: 'mid',
  script: 'mid',
  strategy: 'mid',
  draft: 'premium',
  master_article: 'premium',
  humanic_rewrite: 'premium',
  editorial: 'premium',
  strategic_writing: 'premium',
};

// Job type to agent name mapping
const JOB_AGENT_MAP: Record<string, string> = {
  draft_job: 'draft-agent',
  rewrite_job: 'humanic-agent',
  seo_job: 'seo-agent',
  publish_job: 'publish-agent',
  memory_update_job: 'memory-agent',
  repurpose_job: 'repurpose-agent',
  scoring_job: 'scoring-agent',
  tagging_job: 'tagging-agent',
  script_job: 'script-agent',
  image_job: 'image-agent',
  voice_job: 'voice-agent',
  video_compose_job: 'video-compose-agent',
  heatmap_job: 'heatmap-agent',
  clip_job: 'clip-agent',
  strategy_job: 'strategy-agent',
  browser_job: 'browser-agent',
};

// ─── Type Definitions ────────────────────────────────────────────────────────

export interface AiCallOptions {
  tier?: ModelTier;
  taskType?: string;
  systemPrompt?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface DraftInput {
  idea: string;
  sources?: string[];
  angle?: string;
  workspaceId?: string;
  tone?: string;
  targetLength?: number;
}

export interface PipelineResult {
  draft: unknown;
  humanic: unknown;
  seo: unknown;
  scores: unknown;
}

export interface VideoPipelineResult {
  script: unknown;
  images: unknown;
  voice: unknown;
  video: unknown;
}

export interface HeatmapPipelineResult {
  heatmap: unknown;
  clips: unknown[];
}

export interface CostEntry {
  agent: string;
  tier: ModelTier;
  tokensEstimate: number;
  costEstimate: number;
  timestamp: Date;
}

// ─── ZAI Singleton ───────────────────────────────────────────────────────────

let zaiInstance: ZAI | null = null;

export async function getZAI(): Promise<ZAI> {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// ─── Core AI Call Router ─────────────────────────────────────────────────────

export async function aiCall(
  messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>,
  options: AiCallOptions = {}
): Promise<string> {
  const { tier, taskType, systemPrompt, temperature = 0.7 } = options;

  const resolvedTier = tier || (taskType ? TASK_MODEL_MAP[taskType] : 'mid');
  const model = MODEL_MAP[resolvedTier];

  const zai = await getZAI();

  const finalMessages = systemPrompt
    ? [{ role: 'system' as const, content: systemPrompt }, ...messages]
    : messages;

  try {
    const completion = await zai.chat.completions.create({
      messages: finalMessages,
      thinking: { type: 'disabled' },
    });

    const content = completion.choices[0]?.message?.content || '';

    await logAiAction(resolvedTier, model, taskType || 'unknown', content.length);

    return content;
  } catch (error) {
    await logAiError(resolvedTier, model, taskType || 'unknown', error);
    throw new Error(
      `AI call failed [tier=${resolvedTier}, model=${model}]: ${error instanceof Error ? error.message : 'Unknown error'}`
    );
  }
}

// ─── Route to Agent ──────────────────────────────────────────────────────────

export async function routeToAgent(
  jobType: string,
  payload: Record<string, unknown>,
  workspaceId?: string
): Promise<Record<string, unknown>> {
  const agentName = JOB_AGENT_MAP[jobType];

  if (!agentName) {
    return {
      status: 'no_agent_found',
      jobType,
      message: `No agent mapped for job type: ${jobType}`,
    };
  }

  const agent = getAgent(agentName);

  if (!agent) {
    return {
      status: 'agent_not_available',
      jobType,
      agentName,
      message: `Agent "${agentName}" is not registered`,
    };
  }

  const startTime = Date.now();

  try {
    // Add workspaceId to payload if not present
    if (workspaceId && !payload.workspaceId) {
      payload.workspaceId = workspaceId;
    }

    const result = await agent.execute(payload as Record<string, unknown>);
    const executionTime = Date.now() - startTime;

    await logAgentExecution(agentName, jobType, executionTime, true);

    return {
      status: 'agent_completed',
      jobType,
      agentName,
      executionTime,
      result: result as Record<string, unknown>,
    };
  } catch (error) {
    const executionTime = Date.now() - startTime;
    await logAgentExecution(agentName, jobType, executionTime, false, error);

    return {
      status: 'agent_failed',
      jobType,
      agentName,
      executionTime,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// ─── Content Pipeline ────────────────────────────────────────────────────────

export async function runContentPipeline(input: DraftInput): Promise<PipelineResult> {
  const { workspaceId } = input;

  // Step 1: Generate master draft
  const draftAgent = getAgent('draft-agent');
  if (!draftAgent) throw new Error('Draft agent not available');
  const draft = await draftAgent.execute(input as unknown as Record<string, unknown>);

  const draftOutput = draft as { markdown?: string; title?: string };

  // Step 2: Humanic rewrite
  const humanicAgent = getAgent('humanic-agent');
  if (!humanicAgent) throw new Error('Humanic agent not available');
  const humanic = await humanicAgent.execute({
    markdown: draftOutput.markdown || '',
    workspaceId,
  });

  const humanicOutput = humanic as { markdown?: string };

  // Step 3: SEO pack
  const seoAgent = getAgent('seo-agent');
  if (!seoAgent) throw new Error('SEO agent not available');
  const seo = await seoAgent.execute({
    content: humanicOutput.markdown || '',
    workspaceId,
  });

  // Step 4: Score the content
  const scoringAgent = getAgent('scoring-agent');
  if (!scoringAgent) throw new Error('Scoring agent not available');
  const scores = await scoringAgent.execute({
    content: humanicOutput.markdown || '',
    workspaceId,
  });

  return { draft, humanic, seo, scores };
}

// ─── Video Pipeline ──────────────────────────────────────────────────────────

export async function runVideoPipeline(input: {
  topic: string;
  duration: number;
  style: 'educational' | 'entertainment' | 'motivational' | 'horror' | 'documentary' | 'storytelling';
  imageStyle?: 'cinematic' | 'anime' | 'realistic' | 'abstract' | 'dark_fantasy' | 'minimalist' | 'vintage' | 'neon_cyberpunk';
  voice?: string;
  language?: string;
  aspectRatio?: '9:16' | '1:1' | '16:9';
  workspaceId?: string;
}): Promise<VideoPipelineResult> {
  const { topic, duration, style, imageStyle = 'cinematic', voice, language = 'en-US', aspectRatio = '9:16', workspaceId } = input;

  // Step 1: Generate script
  const scriptAgent = getAgent('script-agent');
  if (!scriptAgent) throw new Error('Script agent not available');
  const script = await scriptAgent.execute({
    topic,
    duration,
    style,
    workspaceId,
  });

  const scriptOutput = script as { scenes?: Array<{ narration: string; visual?: string; duration: number }>; title?: string };

  // Step 2: Generate image prompts for each scene
  const imageAgent = getAgent('image-agent');
  if (!imageAgent) throw new Error('Image agent not available');
  const images = imageAgent.execute ? await (async () => {
    if (Array.isArray(scriptOutput.scenes) && scriptOutput.scenes.length > 0) {
      const imagePrompts: Record<string, unknown>[] = [];
      for (const scene of scriptOutput.scenes) {
        const prompt = await imageAgent.execute({
          narration: scene.narration,
          style: imageStyle,
          aspectRatio,
          sceneContext: scene.visual,
          workspaceId,
        });
        imagePrompts.push(prompt);
      }
      return imagePrompts;
    }
    return [];
  })() : [];

  // Step 3: Generate voiceover for each scene
  const voiceAgent = getAgent('voice-agent');
  if (!voiceAgent) throw new Error('Voice agent not available');
  const voiceResults: Record<string, unknown>[] = [];
  if (Array.isArray(scriptOutput.scenes)) {
    for (const scene of scriptOutput.scenes) {
      const voiceResult = await voiceAgent.execute({
        text: scene.narration,
        voice,
        language: language as 'en-US' | 'en-GB' | 'es-ES' | 'fr-FR' | 'de-DE' | 'pt-BR' | 'ja-JP' | 'ko-KR' | 'zh-CN' | 'hi-IN' | 'ar-SA',
        workspaceId,
      });
      voiceResults.push(voiceResult);
    }
  }

  // Step 4: Compose video (requires actual image files, so this returns the composition plan)
  const videoComposeAgent = getAgent('video-compose-agent');
  const video = videoComposeAgent ? {
    scenes: scriptOutput.scenes,
    aspectRatio,
    compositionPlan: 'ready',
  } : null;

  return { script, images, voice: voiceResults, video };
}

// ─── Heatmap Pipeline ────────────────────────────────────────────────────────

export async function runHeatmapPipeline(input: {
  videoUrl: string;
  intensityThreshold?: number;
  minSegmentDuration?: number;
  maxSegmentDuration?: number;
  cropMode?: 'center' | 'split_left' | 'split_right';
  outputRatio?: '9:16' | '1:1' | '16:9';
  workspaceId?: string;
}): Promise<HeatmapPipelineResult> {
  const {
    videoUrl,
    intensityThreshold = 0.7,
    minSegmentDuration = 5,
    maxSegmentDuration = 60,
    cropMode = 'center',
    outputRatio = '9:16',
    workspaceId,
  } = input;

  // Step 1: Detect heatmap
  const heatmapAgent = getAgent('heatmap-agent');
  if (!heatmapAgent) throw new Error('Heatmap agent not available');
  const heatmap = await heatmapAgent.execute({
    videoUrl,
    intensityThreshold,
    minSegmentDuration,
    maxSegmentDuration,
    workspaceId,
  });

  const heatmapOutput = heatmap as { viralSegments?: Array<{ startTime: number; endTime: number }>; peakMoment?: { startTime: number; endTime: number } };

  // Step 2: Generate clips from viral segments
  const clipAgent = getAgent('clip-agent');
  const clips: unknown[] = [];

  if (clipAgent) {
    const segments = heatmapOutput.viralSegments || [];
    const segmentsToClip = segments.slice(0, 5); // Max 5 clips

    for (const segment of segmentsToClip) {
      try {
        const clip = await clipAgent.execute({
          videoPath: videoUrl,
          startTime: segment.startTime,
          endTime: segment.endTime,
          cropMode,
          outputRatio,
          generateSubtitles: true,
          workspaceId,
        });
        clips.push(clip);
      } catch {
        // Clip generation failure should not break the pipeline
      }
    }
  }

  return { heatmap, clips };
}

// ─── Quick Agent Execution ───────────────────────────────────────────────────

export async function executeAgent(
  agentName: string,
  input: Record<string, unknown>
): Promise<unknown> {
  const agent = getAgent(agentName);

  if (!agent) {
    throw new Error(`Agent not found: ${agentName}. Available agents: ${listAgents().map((a) => a.name).join(', ')}`);
  }

  return agent.execute(input);
}

// ─── Get Available Agents ────────────────────────────────────────────────────

export function getAvailableAgents(): Array<{
  name: string;
  description: string;
  modelTier: ModelTier;
  engine: AgentEngine;
}> {
  return listAgents();
}

// ─── Get Pipeline Status ─────────────────────────────────────────────────────

export function getPipelineDefinitions(): Array<{
  name: string;
  description: string;
  steps: string[];
}> {
  return [
    {
      name: 'content',
      description: 'Content creation pipeline',
      steps: ['draft', 'humanic', 'seo', 'scoring', 'repurpose', 'publish'],
    },
    {
      name: 'video',
      description: 'Video creation pipeline',
      steps: ['script', 'image', 'voice', 'video-compose', 'publish'],
    },
    {
      name: 'heatmap',
      description: 'Viral clip extraction pipeline',
      steps: ['heatmap', 'clip', 'publish'],
    },
  ];
}

// ─── Logging ─────────────────────────────────────────────────────────────────

async function logAiAction(
  tier: ModelTier,
  model: string,
  taskType: string,
  responseLength: number
): Promise<void> {
  try {
    await db.systemLog.create({
      data: {
        service: 'ai',
        level: 'info',
        action: 'ai_call_completed',
        message: `AI call completed: tier=${tier}, model=${model}, task=${taskType}`,
        metadataJson: JSON.stringify({ tier, model, taskType, responseLength }),
      },
    });
  } catch {
    // Logging failure should not break the pipeline
  }
}

async function logAiError(
  tier: ModelTier,
  model: string,
  taskType: string,
  error: unknown
): Promise<void> {
  try {
    await db.systemLog.create({
      data: {
        service: 'ai',
        level: 'error',
        action: 'ai_call_failed',
        message: `AI call failed: tier=${tier}, model=${model}, task=${taskType}`,
        metadataJson: JSON.stringify({
          tier,
          model,
          taskType,
          error: error instanceof Error ? error.message : String(error),
        }),
      },
    });
  } catch {
    // Logging failure should not break the pipeline
  }
}

async function logAgentExecution(
  agentName: string,
  jobType: string,
  executionTime: number,
  success: boolean,
  error?: unknown
): Promise<void> {
  try {
    await db.systemLog.create({
      data: {
        service: 'orchestrator',
        level: success ? 'info' : 'error',
        action: success ? 'agent_execution_completed' : 'agent_execution_failed',
        message: `Agent ${agentName} ${success ? 'completed' : 'failed'} for ${jobType} in ${executionTime}ms`,
        metadataJson: JSON.stringify({
          agentName,
          jobType,
          executionTime,
          success,
          error: error instanceof Error ? error.message : undefined,
        }),
      },
    });
  } catch {
    // Logging failure should not break the orchestrator
  }
}
