// Browser Manager — Puppeteer singleton pool for browser automation
// Manages browser instances, page pooling, and lifecycle

import puppeteer, { type Browser, type Page } from "puppeteer";

interface BrowserPoolEntry {
  browser: Browser;
  page: Page;
  inUse: boolean;
  lastUsed: Date;
}

class BrowserManager {
  private pool: BrowserPoolEntry[] = [];
  private maxInstances = 5;
  private instanceTimeoutMs = 10 * 60 * 1000; // 10 minutes

  // Get or create a browser page
  async getPage(): Promise<Page> {
    // Find an available page
    const available = this.pool.find((entry) => !entry.inUse);
    if (available) {
      available.inUse = true;
      available.lastUsed = new Date();
      return available.page;
    }

    // Create a new browser instance if under limit
    if (this.pool.length < this.maxInstances) {
      const entry = await this.createEntry();
      entry.inUse = true;
      this.pool.push(entry);
      return entry.page;
    }

    // Wait for a page to become available
    throw new Error("Browser pool is full. Please try again later.");
  }

  // Release a page back to the pool
  async releasePage(page: Page): Promise<void> {
    const entry = this.pool.find((e) => e.page === page);
    if (entry) {
      entry.inUse = false;
      entry.lastUsed = new Date();
    }
  }

  // Take a screenshot
  async screenshot(
    url: string,
    options: {
      selector?: string;
      fullPage?: boolean;
      format?: "png" | "jpeg" | "webp";
      viewport?: { width: number; height: number };
    } = {}
  ): Promise<Buffer> {
    const page = await this.getPage();

    try {
      // Set viewport
      await page.setViewport(options.viewport || { width: 1920, height: 1080 });

      // Navigate to URL
      await page.goto(url, {
        waitUntil: "networkidle2",
        timeout: 30000,
      });

      // Take screenshot
      let buffer: Buffer;

      if (options.selector) {
        const element = await page.$(options.selector);
        if (!element) {
          throw new Error(`Element not found: ${options.selector}`);
        }
        buffer = (await element.screenshot({
          type: options.format || "png",
        })) as Buffer;
      } else {
        buffer = (await page.screenshot({
          type: options.format || "png",
          fullPage: options.fullPage || false,
        })) as Buffer;
      }

      return buffer;
    } finally {
      await this.releasePage(page);
    }
  }

  // Navigate and get page content
  async getPageContent(url: string): Promise<{
    title: string;
    html: string;
    text: string;
    url: string;
  }> {
    const page = await this.getPage();

    try {
      await page.goto(url, {
        waitUntil: "networkidle2",
        timeout: 30000,
      });

      const title = await page.title();
      const html = await page.content();
      const text = await page.evaluate(() => document.body.innerText);
      const finalUrl = page.url();

      return { title, html, text, url: finalUrl };
    } finally {
      await this.releasePage(page);
    }
  }

  // Create a new browser pool entry
  private async createEntry(): Promise<BrowserPoolEntry> {
    const browser = await puppeteer.launch({
      headless: process.env.PUPPETEER_HEADLESS !== "false",
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--window-size=1920,1080",
      ],
      executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
    });

    const page = await browser.newPage();
    await page.setUserAgent(
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    );

    return {
      browser,
      page,
      inUse: false,
      lastUsed: new Date(),
    };
  }

  // Cleanup idle instances
  async cleanup(): Promise<number> {
    const now = new Date();
    let cleaned = 0;

    for (let i = this.pool.length - 1; i >= 0; i--) {
      const entry = this.pool[i];
      const idleMs = now.getTime() - entry.lastUsed.getTime();

      if (!entry.inUse && idleMs > this.instanceTimeoutMs) {
        await entry.browser.close();
        this.pool.splice(i, 1);
        cleaned++;
      }
    }

    return cleaned;
  }

  // Close all browsers
  async closeAll(): Promise<void> {
    for (const entry of this.pool) {
      await entry.browser.close();
    }
    this.pool = [];
  }
}

// Singleton
export const browserManager = new BrowserManager();

// Cleanup interval
setInterval(() => {
  browserManager.cleanup().catch(console.error);
}, 5 * 60 * 1000); // Every 5 minutes
