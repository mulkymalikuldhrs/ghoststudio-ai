// Live Preview — Real-time monitoring of browser sessions
// Captures screenshots and page state at intervals

import { browserManager } from "./browser-manager";

export interface LivePreviewState {
  url: string;
  title: string;
  screenshot: string; // Base64 encoded
  timestamp: Date;
  viewport: { width: number; height: number };
}

export class LivePreview {
  private activeSessions = new Map<string, NodeJS.Timeout>();
  private latestStates = new Map<string, LivePreviewState>();

  // Start monitoring a URL
  async startMonitoring(
    sessionId: string,
    url: string,
    intervalMs: number = 5000
  ): Promise<void> {
    // Stop existing session if any
    this.stopMonitoring(sessionId);

    // Capture initial state
    await this.captureState(sessionId, url);

    // Set up interval
    const interval = setInterval(async () => {
      await this.captureState(sessionId, url);
    }, intervalMs);

    this.activeSessions.set(sessionId, interval);
  }

  // Stop monitoring a session
  stopMonitoring(sessionId: string): void {
    const interval = this.activeSessions.get(sessionId);
    if (interval) {
      clearInterval(interval);
      this.activeSessions.delete(sessionId);
    }
    this.latestStates.delete(sessionId);
  }

  // Get the latest state for a session
  getLatestState(sessionId: string): LivePreviewState | undefined {
    return this.latestStates.get(sessionId);
  }

  // Capture current state of a URL
  private async captureState(sessionId: string, url: string): Promise<void> {
    try {
      const page = await browserManager.getPage();

      try {
        await page.goto(url, {
          waitUntil: "networkidle2",
          timeout: 15000,
        });

        const title = await page.title();
        const screenshotBuf = await page.screenshot({ type: "jpeg", quality: 70 });
        const screenshot = Buffer.isBuffer(screenshotBuf) ? screenshotBuf.toString("base64") : String(screenshotBuf);
        const viewport = page.viewport();

        this.latestStates.set(sessionId, {
          url,
          title,
          screenshot,
          timestamp: new Date(),
          viewport: viewport || { width: 1920, height: 1080 },
        });
      } finally {
        await browserManager.releasePage(page);
      }
    } catch (error) {
      console.error(`Live preview capture failed for ${sessionId}:`, error);
    }
  }

  // Stop all monitoring sessions
  stopAll(): void {
    for (const [sessionId] of this.activeSessions) {
      this.stopMonitoring(sessionId);
    }
  }

  // Get all active session IDs
  getActiveSessions(): string[] {
    return Array.from(this.activeSessions.keys());
  }
}

// Singleton
export const livePreview = new LivePreview();
