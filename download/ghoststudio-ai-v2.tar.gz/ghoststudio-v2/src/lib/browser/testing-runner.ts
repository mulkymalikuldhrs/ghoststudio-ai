// Testing Runner — E2E testing framework using Puppeteer
// Run automated tests against web applications

import { browserManager } from "./browser-manager";

export interface TestCase {
  name: string;
  steps: TestStep[];
}

export interface TestStep {
  action: "navigate" | "click" | "type" | "wait" | "assert" | "screenshot" | "scroll" | "select";
  selector?: string;
  value?: string;
  url?: string;
  timeout?: number;
  assertion?: (value: string) => boolean;
}

export interface TestResult {
  name: string;
  passed: boolean;
  steps: TestStepResult[];
  durationMs: number;
  error?: string;
}

export interface TestStepResult {
  action: string;
  passed: boolean;
  error?: string;
  screenshot?: string;
  durationMs: number;
}

export class TestingRunner {
  // Run a single test case
  async runTest(testCase: TestCase): Promise<TestResult> {
    const startTime = Date.now();
    const stepResults: TestStepResult[] = [];
    let allPassed = true;

    const page = await browserManager.getPage();

    try {
      for (const step of testCase.steps) {
        const stepStart = Date.now();
        let passed = true;
        let error: string | undefined;

        try {
          switch (step.action) {
            case "navigate":
              if (!step.url) throw new Error("URL is required for navigate");
              await page.goto(step.url, {
                waitUntil: "networkidle2",
                timeout: step.timeout || 30000,
              });
              break;

            case "click":
              if (!step.selector) throw new Error("Selector is required for click");
              await page.waitForSelector(step.selector, { timeout: step.timeout || 10000 });
              await page.click(step.selector);
              break;

            case "type":
              if (!step.selector || !step.value) throw new Error("Selector and value required for type");
              await page.waitForSelector(step.selector, { timeout: step.timeout || 10000 });
              await page.type(step.selector, step.value, { delay: 50 });
              break;

            case "wait":
              if (!step.selector) throw new Error("Selector is required for wait");
              await page.waitForSelector(step.selector, { timeout: step.timeout || 10000 });
              break;

            case "assert": {
              if (!step.selector) throw new Error("Selector is required for assert");
              const element = await page.$(step.selector);
              if (!element) throw new Error(`Element not found: ${step.selector}`);
              const text = await page.evaluate((el) => el.textContent, element);
              if (step.assertion && !step.assertion(text || "")) {
                throw new Error(`Assertion failed for element: ${step.selector}`);
              }
              break;
            }

            case "screenshot":
              // Capture screenshot for reporting
              break;

            case "scroll":
              await page.evaluate((pixels) => window.scrollBy(0, pixels), 500);
              break;

            case "select":
              if (!step.selector || !step.value) throw new Error("Selector and value required for select");
              await page.select(step.selector, step.value);
              break;
          }
        } catch (err) {
          passed = false;
          error = err instanceof Error ? err.message : "Step failed";
          allPassed = false;
        }

        stepResults.push({
          action: step.action,
          passed,
          error,
          durationMs: Date.now() - stepStart,
        });

        // Stop on first failure
        if (!passed) break;
      }
    } finally {
      await browserManager.releasePage(page);
    }

    return {
      name: testCase.name,
      passed: allPassed,
      steps: stepResults,
      durationMs: Date.now() - startTime,
      error: allPassed ? undefined : "One or more steps failed",
    };
  }

  // Run multiple test cases
  async runSuite(testCases: TestCase[]): Promise<TestResult[]> {
    const results: TestResult[] = [];

    for (const testCase of testCases) {
      const result = await this.runTest(testCase);
      results.push(result);
    }

    return results;
  }
}

// Singleton
export const testingRunner = new TestingRunner();
