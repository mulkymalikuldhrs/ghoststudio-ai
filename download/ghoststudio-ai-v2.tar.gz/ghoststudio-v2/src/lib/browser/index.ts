/**
 * GhostStudio AI v2.0 — Browser Automation Modules
 * Barrel export file
 */

// Re-export the main singleton instances
export { browserManager } from './browser-manager';
