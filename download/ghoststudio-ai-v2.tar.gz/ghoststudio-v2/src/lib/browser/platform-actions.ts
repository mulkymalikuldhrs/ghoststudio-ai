// Platform Actions — Auto-post via browser automation
// For platforms without API access (Substack, etc.)

import { browserManager } from "./browser-manager";
import { db } from "@/lib/db";

export interface PlatformActionConfig {
  platform: string;
  loginUrl: string;
  postUrl: string;
  selectors: {
    emailInput?: string;
    passwordInput?: string;
    loginButton?: string;
    titleInput: string;
    bodyInput: string;
    publishButton: string;
    tagInput?: string;
  };
}

// Platform configurations for browser-based publishing
const PLATFORM_CONFIGS: Record<string, PlatformActionConfig> = {
  substack: {
    platform: "substack",
    loginUrl: "https://substack.com/sign-in",
    postUrl: "https://substack.com/post",
    selectors: {
      emailInput: 'input[name="email"]',
      passwordInput: 'input[name="password"]',
      loginButton: 'button[type="submit"]',
      titleInput: 'input[placeholder*="Title"]',
      bodyInput: '[contenteditable="true"]',
      publishButton: 'button:has-text("Publish")',
    },
  },
};

export class PlatformActions {
  // Auto-post content via browser
  async autoPost(params: {
    userId: string;
    platform: string;
    title: string;
    body: string;
    tags?: string[];
  }): Promise<{ success: boolean; postUrl?: string; error?: string }> {
    const config = PLATFORM_CONFIGS[params.platform];
    if (!config) {
      return { success: false, error: `No browser config for platform: ${params.platform}` };
    }

    // Get credentials
    const credential = await db.apiCredential.findFirst({
      where: {
        userId: params.userId,
        platform: params.platform,
        isActive: true,
      },
    });

    if (!credential) {
      return { success: false, error: `No credentials for ${params.platform}` };
    }

    const page = await browserManager.getPage();

    try {
      // Navigate to post creation page
      await page.goto(config.postUrl, {
        waitUntil: "networkidle2",
        timeout: 30000,
      });

      // Fill in title
      if (config.selectors.titleInput) {
        await page.waitForSelector(config.selectors.titleInput, { timeout: 10000 });
        await page.click(config.selectors.titleInput, { clickCount: 3 });
        await page.type(config.selectors.titleInput, params.title, { delay: 50 });
      }

      // Fill in body
      if (config.selectors.bodyInput) {
        await page.waitForSelector(config.selectors.bodyInput, { timeout: 10000 });
        await page.click(config.selectors.bodyInput);
        await page.type(config.selectors.bodyInput, params.body, { delay: 30 });
      }

      // Add tags if available
      if (params.tags?.length && config.selectors.tagInput) {
        for (const tag of params.tags) {
          await page.type(config.selectors.tagInput, tag, { delay: 50 });
          await page.keyboard.press("Enter");
        }
      }

      // Click publish
      if (config.selectors.publishButton) {
        await page.waitForSelector(config.selectors.publishButton, { timeout: 10000 });
        await page.click(config.selectors.publishButton);
      }

      // Wait for navigation after publish
      await page.waitForNavigation({ waitUntil: "networkidle2", timeout: 30000 }).catch(() => {});

      const postUrl = page.url();

      return {
        success: true,
        postUrl,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Auto-post failed",
      };
    } finally {
      await browserManager.releasePage(page);
    }
  }

  // Take a screenshot of a platform's post editor
  async captureEditorScreenshot(
    platform: string,
    userId: string
  ): Promise<{ success: boolean; screenshot?: Buffer; error?: string }> {
    const config = PLATFORM_CONFIGS[platform];
    if (!config) {
      return { success: false, error: `No browser config for platform: ${platform}` };
    }

    try {
      const screenshot = await browserManager.screenshot(config.postUrl);
      return { success: true, screenshot };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Screenshot failed",
      };
    }
  }
}

// Singleton
export const platformActions = new PlatformActions();
