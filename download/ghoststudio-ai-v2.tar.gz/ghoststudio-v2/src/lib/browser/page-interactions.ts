// Page Interactions — Click, type, scroll helpers for browser automation

import { type Page } from "puppeteer";
import { browserManager } from "./browser-manager";

export interface InteractionResult {
  success: boolean;
  action: string;
  selector?: string;
  value?: string;
  error?: string;
  screenshot?: string; // Base64 encoded
  timestamp: Date;
}

export class PageInteractions {
  // Click an element
  async click(url: string, selector: string, options: { delay?: number } = {}): Promise<InteractionResult> {
    const page = await browserManager.getPage();
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
      await page.waitForSelector(selector, { timeout: 10000 });
      await page.click(selector, { delay: options.delay || 0 });

      return {
        success: true,
        action: "click",
        selector,
        timestamp: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        action: "click",
        selector,
        error: error instanceof Error ? error.message : "Click failed",
        timestamp: new Date(),
      };
    } finally {
      await browserManager.releasePage(page);
    }
  }

  // Type into an input field
  async type(
    url: string,
    selector: string,
    value: string,
    options: { delay?: number; clear?: boolean } = {}
  ): Promise<InteractionResult> {
    const page = await browserManager.getPage();
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
      await page.waitForSelector(selector, { timeout: 10000 });

      if (options.clear) {
        await page.click(selector, { clickCount: 3 });
        await page.keyboard.press("Backspace");
      }

      await page.type(selector, value, { delay: options.delay || 50 });

      return {
        success: true,
        action: "type",
        selector,
        value,
        timestamp: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        action: "type",
        selector,
        value,
        error: error instanceof Error ? error.message : "Type failed",
        timestamp: new Date(),
      };
    } finally {
      await browserManager.releasePage(page);
    }
  }

  // Scroll the page
  async scroll(
    url: string,
    options: { direction?: "up" | "down"; pixels?: number } = {}
  ): Promise<InteractionResult> {
    const page = await browserManager.getPage();
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });

      const pixels = options.pixels || 500;
      const direction = options.direction || "down";
      const scrollY = direction === "down" ? pixels : -pixels;

      await page.evaluate((scrollAmount: number) => {
        window.scrollBy(0, scrollAmount);
      }, scrollY);

      return {
        success: true,
        action: "scroll",
        value: `${direction} ${pixels}px`,
        timestamp: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        action: "scroll",
        error: error instanceof Error ? error.message : "Scroll failed",
        timestamp: new Date(),
      };
    } finally {
      await browserManager.releasePage(page);
    }
  }

  // Select an option from a dropdown
  async select(url: string, selector: string, value: string): Promise<InteractionResult> {
    const page = await browserManager.getPage();
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
      await page.waitForSelector(selector, { timeout: 10000 });
      await page.select(selector, value);

      return {
        success: true,
        action: "select",
        selector,
        value,
        timestamp: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        action: "select",
        selector,
        value,
        error: error instanceof Error ? error.message : "Select failed",
        timestamp: new Date(),
      };
    } finally {
      await browserManager.releasePage(page);
    }
  }

  // Wait for an element or timeout
  async waitFor(url: string, selector: string, timeoutMs: number = 10000): Promise<InteractionResult> {
    const page = await browserManager.getPage();
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
      await page.waitForSelector(selector, { timeout: timeoutMs });

      return {
        success: true,
        action: "wait",
        selector,
        timestamp: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        action: "wait",
        selector,
        error: error instanceof Error ? error.message : "Wait timeout",
        timestamp: new Date(),
      };
    } finally {
      await browserManager.releasePage(page);
    }
  }

  // Hover over an element
  async hover(url: string, selector: string): Promise<InteractionResult> {
    const page = await browserManager.getPage();
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
      await page.waitForSelector(selector, { timeout: 10000 });
      await page.hover(selector);

      return {
        success: true,
        action: "hover",
        selector,
        timestamp: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        action: "hover",
        selector,
        error: error instanceof Error ? error.message : "Hover failed",
        timestamp: new Date(),
      };
    } finally {
      await browserManager.releasePage(page);
    }
  }

  // Execute custom JavaScript on the page
  async evaluate<T>(url: string, fn: () => T): Promise<T> {
    const page = await browserManager.getPage();
    try {
      await page.goto(url, { waitUntil: "networkidle2", timeout: 30000 });
      return await page.evaluate(fn);
    } finally {
      await browserManager.releasePage(page);
    }
  }
}

// Singleton
export const pageInteractions = new PageInteractions();
