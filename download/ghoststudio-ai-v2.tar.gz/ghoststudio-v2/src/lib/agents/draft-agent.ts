// Draft Agent — Generates initial content from ideas, prompts, or source notes

import { type Agent, type AgentResult, registerAgent, type AgentType } from "./index";

async function runDraftAgent(payload: Record<string, unknown>): Promise<AgentResult> {
  const { topic, angle, tone, format, sourceNotes } = payload;

  // Draft agent logic: generate initial content
  // In production, this would call the AI service
  return {
    success: true,
    data: {
      draft: `Draft content for: ${topic}`,
      angle,
      tone,
      format,
      sourceNotes,
    },
  };
}

const draftAgent: Agent = {
  type: "draft" as AgentType,
  name: "Draft Agent",
  description: "Generates initial content from ideas, prompts, or source notes",
  category: "content",
  run: runDraftAgent,
  execute: async (payload) => {
    const result = await runDraftAgent(payload);
    if (!result.success) throw new Error(result.error || 'Draft agent failed');
    return result.data ?? {};
  },
};

registerAgent(draftAgent);
export { draftAgent };
