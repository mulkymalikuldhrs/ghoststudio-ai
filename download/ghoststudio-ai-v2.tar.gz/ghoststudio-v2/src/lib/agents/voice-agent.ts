// Voice Agent — Converts script text to speech using TTS

import { type Agent, type AgentResult, registerAgent, type AgentType } from "./index";

async function runVoiceAgent(payload: Record<string, unknown>): Promise<AgentResult> {
  const { text, voiceId, speed, pitch } = payload;

  return {
    success: true,
    data: {
      audioUrl: null,
      text,
      voiceId: voiceId || "alloy",
      speed: speed || 1.0,
      duration: Math.ceil(((text as string) || "").split(" ").length / 2.5),
      status: "pending",
    },
  };
}

const voiceAgent: Agent = {
  type: "voice" as AgentType,
  name: "Voice Agent",
  description: "Converts script text to speech using TTS",
  category: "video",
  run: runVoiceAgent,
  execute: async (payload) => {
    const result = await runVoiceAgent(payload);
    if (!result.success) throw new Error(result.error || 'Voice agent failed');
    return result.data ?? {};
  },
};

registerAgent(voiceAgent);
export { voiceAgent };
