// Humanic Agent — Removes robotic AI patterns and adds natural voice

import { type Agent, type AgentResult, registerAgent, type AgentType } from "./index";

async function runHumanicAgent(payload: Record<string, unknown>): Promise<AgentResult> {
  const { content } = payload;
  const markdown = content as string || "";

  // Check for robotic patterns
  const roboticPatterns = [
    "in conclusion", "it goes without saying", "at the end of the day",
    "leverage", "synergy", "delve", "furthermore", "moreover",
    "hence", "thereby", "utilize", "facilitate",
  ];

  const foundPatterns = roboticPatterns.filter((p) =>
    markdown.toLowerCase().includes(p)
  );

  return {
    success: true,
    data: {
      humanized: markdown,
      patternsFound: foundPatterns,
      patternsReplaced: foundPatterns.length,
      humanicScore: Math.max(0, 100 - foundPatterns.length * 10),
    },
  };
}

const humanicAgent: Agent = {
  type: "humanic" as AgentType,
  name: "Humanic Agent",
  description: "Removes robotic AI patterns and adds natural, human voice",
  category: "content",
  run: runHumanicAgent,
  execute: async (payload) => {
    const result = await runHumanicAgent(payload);
    if (!result.success) throw new Error(result.error || 'Humanic agent failed');
    return result.data ?? {};
  },
};

registerAgent(humanicAgent);
export { humanicAgent };
