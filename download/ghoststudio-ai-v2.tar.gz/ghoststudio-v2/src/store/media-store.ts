// ────────────────────────────────────────────────────────────────────────────────
// Media Store — Main OS Dashboard State (Zustand)
// GhostStudio AI v2.0
// ────────────────────────────────────────────────────────────────────────────────

import { create } from "zustand";
import type {
  ContentItem as ContentType,
  VideoProject as VideoProjectType,
  HeatmapClipJob as HeatmapClipJobType,
  SchedulerJob as SchedulerJobType,
  QueueStatus as QueueStatusType,
  MemoryEntry as MemoryEntryType,
  EnergyEntry as EnergyEntryType,
  AnalyticsEvent as AnalyticsEventType,
  AnalyticsSummary as AnalyticsSummaryType,
} from "@/types";

// Re-export types for consumer convenience
export type ContentItem = ContentType;
export type VideoProject = VideoProjectType;
export type HeatmapClipJob = HeatmapClipJobType;
export type SchedulerJob = SchedulerJobType;
export type QueueStatus = QueueStatusType;
export type MemoryEntry = MemoryEntryType;
export type EnergyEntry = EnergyEntryType;
export type AnalyticsEvent = AnalyticsEventType;
export type AnalyticsSummary = AnalyticsSummaryType;

// ─── Re-export types used by OS page ──────────────────────────────────────────

export type ContentStatus =
  | "idea"
  | "draft"
  | "editing"
  | "seo_review"
  | "ready"
  | "scheduled"
  | "published"
  | "archived"
  | "failed";

export type VideoStatus =
  | "draft"
  | "scripting"
  | "generating"
  | "rendering"
  | "completed"
  | "failed";

export interface HeatmapSegment {
  id: string;
  startTime: number;
  endTime: number;
  intensity: number;
  label: string;
}

export interface HeatmapJob {
  id: string;
  userId: string;
  youtubeUrl: string;
  status: string;
  progress: number;
  segments: HeatmapSegment[];
  outputUrl?: string;
  createdAt: string;
}

export interface BrowserInstance {
  id: string;
  status: string;
  pageCount: number;
  currentUrl: string;
}

export interface PlatformLogin {
  platform: string;
  label: string;
  loggedIn: boolean;
  username?: string;
}

export interface TestResult {
  id: string;
  suite: string;
  name: string;
  status: string;
  duration?: number;
  error?: string;
  timestamp: string;
}

export interface EnergyReport {
  overallEnergy: number;
  canPublish: boolean;
  entries: EnergyEntry[];
  warnings: string[];
}

// ─── Tab Types ───────────────────────────────────────────────────────────────

export type OSTab =
  | "content"
  | "video"
  | "publish"
  | "scheduler"
  | "memory"
  | "energy"
  | "analytics"
  | "browser"
  | "heatmap";

export type AutomationMode = "manual" | "semi_auto" | "full_auto";

// ─── Store Interface ─────────────────────────────────────────────────────────

interface MediaStore {
  // ── Content Pipeline ────────────────────────────────────────────────────
  contentItems: ContentItem[];
  selectedContentId: string | null;
  contentFilter: { status: string } | string;
  setContentItems: (items: ContentItem[]) => void;
  setSelectedContentId: (id: string | null) => void;
  setContentFilter: (filter: { status: string } | string) => void;

  // ── Video Studio ────────────────────────────────────────────────────────
  videoProjects: VideoProject[];
  selectedVideoId: string | null;
  selectedVideo: VideoProject | null;
  videoFilter: string;
  setVideoProjects: (projects: VideoProject[]) => void;
  setSelectedVideoId: (id: string | null) => void;
  setSelectedVideo: (video: VideoProject | null) => void;
  setVideoFilter: (filter: string) => void;

  // ── Heatmap / Viral Lab ─────────────────────────────────────────────────
  heatmapJobs: HeatmapJob[];
  currentHeatmapUrl: string | null;
  heatmapSegments: HeatmapSegment[];
  setHeatmapJobs: (jobs: HeatmapJob[]) => void;
  setCurrentHeatmapUrl: (url: string | null) => void;
  setHeatmapSegments: (segments: HeatmapSegment[]) => void;

  // ── Scheduler ───────────────────────────────────────────────────────────
  queueStatus: Record<string, number>;
  schedulerJobs: SchedulerJob[];
  setQueueStatus: (status: Record<string, number>) => void;
  setSchedulerJobs: (jobs: SchedulerJob[]) => void;

  // ── Memory ──────────────────────────────────────────────────────────────
  memories: MemoryEntry[];
  memoryCategory: string;
  memoryFilter: string;
  memorySearch: string;
  setMemories: (memories: MemoryEntry[]) => void;
  setMemoryCategory: (category: string) => void;
  setMemoryFilter: (filter: string) => void;
  setMemorySearch: (search: string) => void;

  // ── Analytics ───────────────────────────────────────────────────────────
  analyticsSummary: AnalyticsSummary | null;
  analyticsEvents: AnalyticsEvent[];
  setAnalyticsSummary: (summary: AnalyticsSummary | null) => void;
  setAnalyticsEvents: (events: AnalyticsEvent[]) => void;

  // ── Energy ──────────────────────────────────────────────────────────────
  energyReport: EnergyReport | null;
  energyEntries: EnergyEntry[];
  setEnergyReport: (report: EnergyReport | null) => void;
  setEnergyEntries: (entries: EnergyEntry[]) => void;

  // ── Browser ─────────────────────────────────────────────────────────────
  browserStatus: { active: boolean; pageCount: number } | null;
  browserInstance: BrowserInstance | null;
  platformLogins: PlatformLogin[];
  currentScreenshot: string | null;
  testResults: TestResult[];
  setBrowserStatus: (status: { active: boolean; pageCount: number } | null) => void;
  setBrowserInstance: (instance: BrowserInstance | null) => void;
  setPlatformLogins: (logins: PlatformLogin[]) => void;
  setCurrentScreenshot: (screenshot: string | null) => void;
  setTestResults: (results: TestResult[]) => void;

  // ── UI State ────────────────────────────────────────────────────────────
  activeTab: OSTab;
  setActiveTab: (tab: OSTab) => void;
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  automationMode: AutomationMode;
  setAutomationMode: (mode: AutomationMode) => void;
  workspaceId: string;
  activeWorkspaceId: string;
  setWorkspaceId: (id: string) => void;
  isLoading: boolean;
  isGenerating: boolean;
  setIsLoading: (loading: boolean) => void;
  setIsGenerating: (generating: boolean) => void;

  // ── Selected Content ──────────────────────────────────────────────────
  selectedContent: ContentItem | null;
  setSelectedContent: (content: ContentItem | null) => void;

  // ── Dialogs ─────────────────────────────────────────────────────────────
  showCreateContent: boolean;
  createContentOpen: boolean;
  showCreateVideo: boolean;
  showAddMemory: boolean;
  showContentDetail: boolean;
  contentDetailOpen: boolean;
  showVideoDetail: boolean;
  videoDetailOpen: boolean;
  showEnqueueJob: boolean;
  setShowCreateContent: (open: boolean) => void;
  setCreateContentOpen: (open: boolean) => void;
  setShowCreateVideo: (open: boolean) => void;
  setShowAddMemory: (open: boolean) => void;
  setShowContentDetail: (open: boolean) => void;
  setContentDetailOpen: (open: boolean) => void;
  setShowVideoDetail: (open: boolean) => void;
  setVideoDetailOpen: (open: boolean) => void;
  setShowEnqueueJob: (open: boolean) => void;
}

// ─── Store ────────────────────────────────────────────────────────────────────

export const useMediaStore = create<MediaStore>((set) => ({
  // ── Content Pipeline ────────────────────────────────────────────────────
  contentItems: [],
  selectedContentId: null,
  contentFilter: { status: "all" },
  setContentItems: (items) => set({ contentItems: items }),
  setSelectedContentId: (id) => set({ selectedContentId: id }),
  setContentFilter: (filter) => set({ contentFilter: filter }),

  // ── Video Studio ────────────────────────────────────────────────────────
  videoProjects: [],
  selectedVideoId: null,
  selectedVideo: null,
  videoFilter: "all",
  setVideoProjects: (projects) => set({ videoProjects: projects }),
  setSelectedVideoId: (id) => set({ selectedVideoId: id }),
  setSelectedVideo: (video) => set({ selectedVideo: video }),
  setVideoFilter: (filter) => set({ videoFilter: filter }),

  // ── Heatmap / Viral Lab ─────────────────────────────────────────────────
  heatmapJobs: [],
  currentHeatmapUrl: null,
  heatmapSegments: [],
  setHeatmapJobs: (jobs) => set({ heatmapJobs: jobs }),
  setCurrentHeatmapUrl: (url) => set({ currentHeatmapUrl: url }),
  setHeatmapSegments: (segments) => set({ heatmapSegments: segments }),

  // ── Scheduler ───────────────────────────────────────────────────────────
  queueStatus: {},
  schedulerJobs: [],
  setQueueStatus: (status) => set({ queueStatus: status }),
  setSchedulerJobs: (jobs) => set({ schedulerJobs: jobs }),

  // ── Memory ──────────────────────────────────────────────────────────────
  memories: [],
  memoryCategory: "all",
  memoryFilter: "all",
  memorySearch: "",
  setMemories: (memories) => set({ memories }),
  setMemoryCategory: (category) => set({ memoryCategory: category }),
  setMemoryFilter: (filter) => set({ memoryFilter: filter }),
  setMemorySearch: (search) => set({ memorySearch: search }),

  // ── Analytics ───────────────────────────────────────────────────────────
  analyticsSummary: null,
  analyticsEvents: [],
  setAnalyticsSummary: (summary) => set({ analyticsSummary: summary }),
  setAnalyticsEvents: (events) => set({ analyticsEvents: events }),

  // ── Energy ──────────────────────────────────────────────────────────────
  energyReport: null,
  energyEntries: [],
  setEnergyReport: (report) => set({ energyReport: report }),
  setEnergyEntries: (entries) => set({ energyEntries: entries }),

  // ── Browser ─────────────────────────────────────────────────────────────
  browserStatus: null,
  browserInstance: null,
  platformLogins: [],
  currentScreenshot: null,
  testResults: [],
  setBrowserStatus: (status) => set({ browserStatus: status }),
  setBrowserInstance: (instance) => set({ browserInstance: instance }),
  setPlatformLogins: (logins) => set({ platformLogins: logins }),
  setCurrentScreenshot: (screenshot) => set({ currentScreenshot: screenshot }),
  setTestResults: (results) => set({ testResults: results }),

  // ── UI State ────────────────────────────────────────────────────────────
  activeTab: "content",
  setActiveTab: (tab) => set({ activeTab: tab }),
  sidebarOpen: true,
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  automationMode: "semi_auto",
  setAutomationMode: (mode) => set({ automationMode: mode }),
  workspaceId: "demo-workspace",
  activeWorkspaceId: "demo-workspace",
  setWorkspaceId: (id) => set({ workspaceId: id, activeWorkspaceId: id }),
  isLoading: false,
  isGenerating: false,
  setIsLoading: (loading) => set({ isLoading: loading }),
  setIsGenerating: (generating) => set({ isGenerating: generating }),

  // ── Selected Content ──────────────────────────────────────────────────
  selectedContent: null,
  setSelectedContent: (content) => set({ selectedContent: content }),

  // ── Dialogs ─────────────────────────────────────────────────────────────
  showCreateContent: false,
  createContentOpen: false,
  showCreateVideo: false,
  showAddMemory: false,
  showContentDetail: false,
  contentDetailOpen: false,
  showVideoDetail: false,
  videoDetailOpen: false,
  showEnqueueJob: false,
  setShowCreateContent: (open) => set({ showCreateContent: open, createContentOpen: open }),
  setCreateContentOpen: (open) => set({ createContentOpen: open, showCreateContent: open }),
  setShowCreateVideo: (open) => set({ showCreateVideo: open }),
  setShowAddMemory: (open) => set({ showAddMemory: open }),
  setShowContentDetail: (open) => set({ showContentDetail: open, contentDetailOpen: open }),
  setContentDetailOpen: (open) => set({ contentDetailOpen: open, showContentDetail: open }),
  setShowVideoDetail: (open) => set({ showVideoDetail: open, videoDetailOpen: open }),
  setVideoDetailOpen: (open) => set({ videoDetailOpen: open, showVideoDetail: open }),
  setShowEnqueueJob: (open) => set({ showEnqueueJob: open }),
}));
