// ────────────────────────────────────────────────────────────────────────────────
// Browser Automation Types
// GhostStudio AI v2.0
// ────────────────────────────────────────────────────────────────────────────────

// ─── Enums / Union Types ─────────────────────────────────────────────────────

export type BrowserAction =
  | "click"
  | "type"
  | "scroll"
  | "select"
  | "wait"
  | "hover"
  | "screenshot"
  | "navigate";

export type BrowserSessionStatus =
  | "connected"
  | "disconnected"
  | "error";

// ─── Browser Session ─────────────────────────────────────────────────────────

export interface BrowserSession {
  id: string;
  url: string;
  headless: boolean;
  viewport: { width: number; height: number };
  status: BrowserSessionStatus;
  createdAt: string;
  lastActivity: string;
}

// ─── Browser Status ──────────────────────────────────────────────────────────

export interface BrowserStatus {
  active: boolean;
  pageCount: number;
  sessions: BrowserSession[];
  uptime: number;
}

// ─── Interaction ─────────────────────────────────────────────────────────────

export interface InteractionInput {
  action: BrowserAction;
  selector?: string;
  value?: string;
  url?: string;
  timeout?: number;
  sessionId?: string;
}

export interface InteractionResult {
  success: boolean;
  action: BrowserAction;
  selector?: string;
  value?: string;
  error?: string;
  screenshot?: string; // Base64 encoded
  timestamp: string;
}

// ─── Screenshot ──────────────────────────────────────────────────────────────

export interface ScreenshotInput {
  url: string;
  fullPage?: boolean;
  viewport?: { width: number; height: number };
  sessionId?: string;
}

export interface ScreenshotResult {
  screenshot: string; // Base64 encoded
  url: string;
  title: string;
  timestamp: string;
  viewport: { width: number; height: number };
}

// ─── Live Preview ────────────────────────────────────────────────────────────

export interface LivePreviewState {
  url: string;
  title: string;
  screenshot: string; // Base64 encoded
  timestamp: string;
  viewport: { width: number; height: number };
}

// ─── Testing ─────────────────────────────────────────────────────────────────

export interface TestCase {
  name: string;
  steps: TestStep[];
}

export interface TestStep {
  action: BrowserAction;
  selector?: string;
  value?: string;
  url?: string;
  timeout?: number;
}

export interface TestResult {
  name: string;
  passed: boolean;
  steps: TestStepResult[];
  durationMs: number;
  error?: string;
}

export interface TestStepResult {
  action: string;
  passed: boolean;
  error?: string;
  durationMs: number;
}

// ─── Platform Actions ────────────────────────────────────────────────────────

export interface PlatformActionInput {
  platform: string;
  action: "login" | "post" | "schedule" | "check_status";
  credentials?: Record<string, string>;
  data?: Record<string, unknown>;
}

export interface PlatformActionResult {
  success: boolean;
  platform: string;
  action: string;
  result?: Record<string, unknown>;
  error?: string;
  screenshot?: string;
}
