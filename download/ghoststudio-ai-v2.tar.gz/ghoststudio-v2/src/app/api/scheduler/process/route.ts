import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/scheduler/process - Process the next scheduled job
export async function POST() {
  try {
    const now = new Date();

    // Find the next job to process
    const job = await db.schedulerJob.findFirst({
      where: {
        status: "pending",
        nextAttempt: { lte: now },
      },
      orderBy: [{ priority: "asc" }, { nextAttempt: "asc" }],
    });

    if (!job) {
      return NextResponse.json({ message: "No jobs to process" });
    }

    // Lock the job
    const lockUntil = new Date(now.getTime() + 5 * 60 * 1000); // 5 min lock
    await db.schedulerJob.update({
      where: { id: job.id },
      data: {
        status: "running",
        lockedBy: `worker-${Date.now()}`,
        lockUntil,
      },
    });

    // Log the processing
    await db.systemLog.create({
      data: {
        service: "scheduler",
        level: "info",
        action: "job_process",
        message: `Processing job ${job.id} of type ${job.jobType}`,
        metadataJson: JSON.stringify({ jobId: job.id, jobType: job.jobType }),
      },
    });

    return NextResponse.json({
      message: "Job processing started",
      job: {
        id: job.id,
        jobType: job.jobType,
        priority: job.priority,
        payloadJson: job.payloadJson,
      },
    });
  } catch (error) {
    console.error("Scheduler process error:", error);
    return NextResponse.json(
      { error: "Failed to process scheduler job" },
      { status: 500 }
    );
  }
}
