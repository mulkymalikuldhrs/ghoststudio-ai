import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/scheduler - List scheduler jobs
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get("workspaceId");
    const status = searchParams.get("status");
    const jobType = searchParams.get("jobType");
    const limit = parseInt(searchParams.get("limit") || "20");

    if (!workspaceId) {
      return NextResponse.json(
        { error: "workspaceId is required" },
        { status: 400 }
      );
    }

    const where: Record<string, unknown> = { workspaceId };
    if (status) where.status = status;
    if (jobType) where.jobType = jobType;

    const jobs = await db.schedulerJob.findMany({
      where,
      orderBy: [{ priority: "asc" }, { nextAttempt: "asc" }],
      take: limit,
    });

    return NextResponse.json({ jobs });
  } catch (error) {
    console.error("Scheduler list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch scheduler jobs" },
      { status: 500 }
    );
  }
}

// POST /api/scheduler - Create scheduler job
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { workspaceId, jobType, priority = 5, payloadJson = {}, nextAttempt } = body;

    if (!workspaceId || !jobType) {
      return NextResponse.json(
        { error: "workspaceId and jobType are required" },
        { status: 400 }
      );
    }

    const job = await db.schedulerJob.create({
      data: {
        workspaceId,
        jobType,
        priority,
        payloadJson: JSON.stringify(payloadJson),
        nextAttempt: nextAttempt ? new Date(nextAttempt) : new Date(),
      },
    });

    return NextResponse.json(job, { status: 201 });
  } catch (error) {
    console.error("Scheduler create error:", error);
    return NextResponse.json(
      { error: "Failed to create scheduler job" },
      { status: 500 }
    );
  }
}
