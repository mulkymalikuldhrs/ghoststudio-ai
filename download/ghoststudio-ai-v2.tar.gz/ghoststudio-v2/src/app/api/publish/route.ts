import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/publish - Publish content to a platform
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { contentId, contentVariantId, platform, scheduledTime, isDryRun = false } = body;

    if (!contentId || !platform) {
      return NextResponse.json(
        { error: "contentId and platform are required" },
        { status: 400 }
      );
    }

    const contentItem = await db.contentItem.findUnique({
      where: { id: contentId },
      include: { variants: true },
    });

    if (!contentItem) {
      return NextResponse.json(
        { error: "Content item not found" },
        { status: 404 }
      );
    }

    // Get workspace for the publish job
    const workspaceId = contentItem.workspaceId;

    const publishJob = await db.publishJob.create({
      data: {
        workspaceId,
        contentId,
        contentVariantId,
        platform,
        status: "queued",
        scheduledTime: scheduledTime ? new Date(scheduledTime) : null,
        isDryRun,
      },
    });

    // Create scheduler job for processing
    await db.schedulerJob.create({
      data: {
        workspaceId,
        jobType: "publish_job",
        priority: 3,
        payloadJson: JSON.stringify({
          publishJobId: publishJob.id,
          platform,
          contentId,
        }),
        nextAttempt: scheduledTime ? new Date(scheduledTime) : new Date(),
      },
    });

    return NextResponse.json(publishJob, { status: 201 });
  } catch (error) {
    console.error("Publish error:", error);
    return NextResponse.json(
      { error: "Failed to create publish job" },
      { status: 500 }
    );
  }
}
