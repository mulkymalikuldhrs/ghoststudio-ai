import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/analytics - Get analytics data
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get("workspaceId");
    const contentId = searchParams.get("contentId");
    const metricType = searchParams.get("metricType");
    const platform = searchParams.get("platform");
    const days = parseInt(searchParams.get("days") || "30");

    if (!workspaceId) {
      return NextResponse.json(
        { error: "workspaceId is required" },
        { status: 400 }
      );
    }

    const since = new Date();
    since.setDate(since.getDate() - days);

    const where: Record<string, unknown> = {
      workspaceId,
      capturedAt: { gte: since },
    };
    if (contentId) where.contentId = contentId;
    if (metricType) where.metricType = metricType;
    if (platform) where.platform = platform;

    const events = await db.analyticsEvent.findMany({
      where,
      orderBy: { capturedAt: "desc" },
      take: 500,
    });

    // Aggregate by metric type
    const byMetric: Record<string, { total: number; count: number; avg: number }> = {};
    for (const event of events) {
      if (!byMetric[event.metricType]) {
        byMetric[event.metricType] = { total: 0, count: 0, avg: 0 };
      }
      byMetric[event.metricType].total += event.metricValue;
      byMetric[event.metricType].count += 1;
    }

    for (const key of Object.keys(byMetric)) {
      byMetric[key].avg =
        Math.round((byMetric[key].total / byMetric[key].count) * 100) / 100;
    }

    return NextResponse.json({
      events,
      summary: byMetric,
      period: { days, since },
    });
  } catch (error) {
    console.error("Analytics error:", error);
    return NextResponse.json(
      { error: "Failed to fetch analytics" },
      { status: 500 }
    );
  }
}

// POST /api/analytics - Record analytics event
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { workspaceId, contentId, platform, metricType, metricValue, rawPayload, source = "auto" } = body;

    if (!workspaceId || !metricType) {
      return NextResponse.json(
        { error: "workspaceId and metricType are required" },
        { status: 400 }
      );
    }

    const event = await db.analyticsEvent.create({
      data: {
        workspaceId,
        contentId,
        platform,
        metricType,
        metricValue: metricValue ?? 0,
        rawPayload: rawPayload ? JSON.stringify(rawPayload) : null,
        source,
      },
    });

    return NextResponse.json(event, { status: 201 });
  } catch (error) {
    console.error("Analytics create error:", error);
    return NextResponse.json(
      { error: "Failed to record analytics event" },
      { status: 500 }
    );
  }
}
