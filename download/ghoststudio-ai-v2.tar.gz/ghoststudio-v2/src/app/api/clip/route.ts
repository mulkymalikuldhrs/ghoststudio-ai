import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/clip - Generate a clip from a heatmap clip job
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { jobId } = body;

    if (!jobId) {
      return NextResponse.json(
        { error: "jobId is required" },
        { status: 400 }
      );
    }

    const job = await db.heatmapClipJob.findUnique({
      where: { id: jobId },
    });

    if (!job) {
      return NextResponse.json(
        { error: "Heatmap clip job not found" },
        { status: 404 }
      );
    }

    // Update status to clipping
    await db.heatmapClipJob.update({
      where: { id: jobId },
      data: { status: "clipping", progress: 50 },
    });

    return NextResponse.json({
      message: "Clip generation started",
      jobId,
      videoUrl: job.videoUrl,
      clipStart: job.clipStart,
      clipEnd: job.clipEnd,
      status: "clipping",
    });
  } catch (error) {
    console.error("Clip generate error:", error);
    return NextResponse.json(
      { error: "Failed to generate clip" },
      { status: 500 }
    );
  }
}
