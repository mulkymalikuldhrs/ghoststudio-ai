import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/memory - List memory entries
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get("workspaceId");
    const category = searchParams.get("category");

    if (!workspaceId) {
      return NextResponse.json(
        { error: "workspaceId is required" },
        { status: 400 }
      );
    }

    const where: Record<string, unknown> = { workspaceId, isActive: true };
    if (category) where.category = category;

    const entries = await db.memoryEntry.findMany({
      where,
      orderBy: { score: "desc" },
      take: 100,
    });

    return NextResponse.json({ entries });
  } catch (error) {
    console.error("Memory list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch memory entries" },
      { status: 500 }
    );
  }
}

// POST /api/memory - Create or update memory entry
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { workspaceId, category, key, value, score = 0, source = "manual", contextJson } = body;

    if (!workspaceId || !category || !key || !value) {
      return NextResponse.json(
        { error: "workspaceId, category, key, and value are required" },
        { status: 400 }
      );
    }

    const entry = await db.memoryEntry.upsert({
      where: {
        workspaceId_category_key: { workspaceId, category, key },
      },
      update: {
        value,
        score,
        source,
        contextJson: contextJson ? JSON.stringify(contextJson) : undefined,
      },
      create: {
        workspaceId,
        category,
        key,
        value,
        score,
        source,
        contextJson: contextJson ? JSON.stringify(contextJson) : null,
      },
    });

    return NextResponse.json(entry);
  } catch (error) {
    console.error("Memory create error:", error);
    return NextResponse.json(
      { error: "Failed to create memory entry" },
      { status: 500 }
    );
  }
}
