import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/energy - List energy entries (fatigue tracking)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get("workspaceId");

    if (!workspaceId) {
      return NextResponse.json(
        { error: "workspaceId is required" },
        { status: 400 }
      );
    }

    const entries = await db.energyEntry.findMany({
      where: { workspaceId },
      orderBy: { fatigueScore: "desc" },
    });

    // Calculate overall energy status
    const avgFatigue =
      entries.length > 0
        ? entries.reduce((sum, e) => sum + e.fatigueScore, 0) / entries.length
        : 0;

    let status = "healthy";
    if (avgFatigue > 70) status = "critical";
    else if (avgFatigue > 50) status = "warning";
    else if (avgFatigue > 30) status = "moderate";

    return NextResponse.json({
      entries,
      summary: {
        averageFatigue: Math.round(avgFatigue * 10) / 10,
        status,
        totalCategories: entries.length,
        criticalAreas: entries.filter((e) => e.fatigueScore > 70).map((e) => e.category),
      },
    });
  } catch (error) {
    console.error("Energy list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch energy entries" },
      { status: 500 }
    );
  }
}

// POST /api/energy - Update energy entry
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { workspaceId, category, topic, fatigueScore, publishCount } = body;

    if (!workspaceId || !category) {
      return NextResponse.json(
        { error: "workspaceId and category are required" },
        { status: 400 }
      );
    }

    // Find existing entry or create new
    const existing = await db.energyEntry.findFirst({
      where: { workspaceId, category, topic: topic || null },
    });

    let entry;
    if (existing) {
      entry = await db.energyEntry.update({
        where: { id: existing.id },
        data: {
          fatigueScore: fatigueScore ?? existing.fatigueScore,
          publishCount: publishCount ?? existing.publishCount,
        },
      });
    } else {
      entry = await db.energyEntry.create({
        data: {
          workspaceId,
          category,
          topic,
          fatigueScore: fatigueScore ?? 0,
          publishCount: publishCount ?? 0,
        },
      });
    }

    return NextResponse.json(entry);
  } catch (error) {
    console.error("Energy update error:", error);
    return NextResponse.json(
      { error: "Failed to update energy entry" },
      { status: 500 }
    );
  }
}
