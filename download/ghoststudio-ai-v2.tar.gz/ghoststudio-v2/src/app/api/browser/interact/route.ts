import { NextRequest, NextResponse } from "next/server";

// POST /api/browser/interact - Interact with a page (click, type, scroll)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { url, action, selector, value, options } = body;

    if (!url || !action) {
      return NextResponse.json(
        { error: "url and action are required" },
        { status: 400 }
      );
    }

    const validActions = ["click", "type", "scroll", "select", "wait", "hover", "screenshot"];
    if (!validActions.includes(action)) {
      return NextResponse.json(
        { error: `Invalid action. Must be one of: ${validActions.join(", ")}` },
        { status: 400 }
      );
    }

    // Placeholder — actual Puppeteer integration will be in page-interactions.ts
    return NextResponse.json({
      message: `Browser interaction: ${action}`,
      url,
      action,
      selector,
      value,
      options,
      success: true,
    });
  } catch (error) {
    console.error("Browser interact error:", error);
    return NextResponse.json(
      { error: "Failed to execute browser interaction" },
      { status: 500 }
    );
  }
}
