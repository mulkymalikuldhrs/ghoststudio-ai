import { NextRequest, NextResponse } from "next/server";

// POST /api/browser - Launch browser session
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { url, headless = true, viewport = { width: 1920, height: 1080 } } = body;

    if (!url) {
      return NextResponse.json(
        { error: "url is required" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      message: "Browser session initiated",
      url,
      headless,
      viewport,
      status: "connected",
    });
  } catch (error) {
    console.error("Browser launch error:", error);
    return NextResponse.json(
      { error: "Failed to launch browser" },
      { status: 500 }
    );
  }
}
