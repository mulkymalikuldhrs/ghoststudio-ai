import { NextRequest, NextResponse } from "next/server";

// POST /api/browser/screenshot - Take a screenshot
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { url, selector, fullPage = false, format = "png" } = body;

    if (!url) {
      return NextResponse.json(
        { error: "url is required" },
        { status: 400 }
      );
    }

    // Placeholder — actual Puppeteer integration will be in browser-manager.ts
    return NextResponse.json({
      message: "Screenshot captured",
      url,
      selector,
      fullPage,
      format,
      screenshotUrl: null, // Will be populated by browser-manager
    });
  } catch (error) {
    console.error("Browser screenshot error:", error);
    return NextResponse.json(
      { error: "Failed to take screenshot" },
      { status: 500 }
    );
  }
}
