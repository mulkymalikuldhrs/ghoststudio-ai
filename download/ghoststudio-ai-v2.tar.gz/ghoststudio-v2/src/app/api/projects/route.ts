import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/projects - List projects (legacy compatibility)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const status = searchParams.get("status");
    const limit = parseInt(searchParams.get("limit") || "20");

    if (!userId) {
      return NextResponse.json(
        { error: "userId is required" },
        { status: 400 }
      );
    }

    const where: Record<string, unknown> = { userId };
    if (status) where.status = status;

    const projects = await db.videoProject.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      take: limit,
    });

    return NextResponse.json({ projects });
  } catch (error) {
    console.error("Projects list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch projects" },
      { status: 500 }
    );
  }
}

// POST /api/projects - Create project (legacy compatibility)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, title, prompt, niche = "general" } = body;

    if (!userId || !title) {
      return NextResponse.json(
        { error: "userId and title are required" },
        { status: 400 }
      );
    }

    const project = await db.videoProject.create({
      data: {
        userId,
        title,
        prompt,
        niche,
        status: "draft",
      },
    });

    return NextResponse.json(project, { status: 201 });
  } catch (error) {
    console.error("Project create error:", error);
    return NextResponse.json(
      { error: "Failed to create project" },
      { status: 500 }
    );
  }
}
