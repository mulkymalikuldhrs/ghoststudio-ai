import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/content/[id] - Get content item by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const item = await db.contentItem.findUnique({
      where: { id },
      include: {
        variants: true,
        seoData: true,
        contentTags: true,
        publishJobs: true,
        analyticsEvents: {
          take: 20,
          orderBy: { capturedAt: "desc" },
        },
      },
    });

    if (!item) {
      return NextResponse.json(
        { error: "Content item not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(item);
  } catch (error) {
    console.error("Content get error:", error);
    return NextResponse.json(
      { error: "Failed to fetch content item" },
      { status: 500 }
    );
  }
}

// PUT /api/content/[id] - Update content item
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const item = await db.contentItem.update({
      where: { id },
      data: body,
    });

    return NextResponse.json(item);
  } catch (error) {
    console.error("Content update error:", error);
    return NextResponse.json(
      { error: "Failed to update content item" },
      { status: 500 }
    );
  }
}

// DELETE /api/content/[id] - Delete content item
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.contentItem.delete({ where: { id } });
    return NextResponse.json({ message: "Content item deleted" });
  } catch (error) {
    console.error("Content delete error:", error);
    return NextResponse.json(
      { error: "Failed to delete content item" },
      { status: 500 }
    );
  }
}
