import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/content/[id]/score - Score content using 4-dimension scoring
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { dimensions } = body;

    const contentItem = await db.contentItem.findUnique({
      where: { id },
    });

    if (!contentItem) {
      return NextResponse.json(
        { error: "Content item not found" },
        { status: 404 }
      );
    }

    // Calculate scores from dimensions or use defaults
    const qualityScore = dimensions?.quality ?? contentItem.qualityScore;
    const humanicScore = dimensions?.humanic ?? contentItem.humanicScore;
    const seoScore = dimensions?.seo ?? contentItem.seoScore;
    const trustScore = dimensions?.trust ?? contentItem.trustScore;

    // Weighted composite matching ContentScorer weights: quality=0.30, humanic=0.30, seo=0.25, trust=0.15
    const compositeScore = Math.round(
      qualityScore * 0.30 + humanicScore * 0.30 + seoScore * 0.25 + trustScore * 0.15
    );

    await db.contentItem.update({
      where: { id },
      data: {
        qualityScore,
        humanicScore,
        seoScore,
        trustScore,
        humanReviewRequired: compositeScore < 60,
      },
    });

    return NextResponse.json({
      contentId: id,
      scores: {
        quality: qualityScore,
        humanic: humanicScore,
        seo: seoScore,
        trust: trustScore,
        composite: compositeScore,
      },
      humanReviewRequired: compositeScore < 60,
    });
  } catch (error) {
    console.error("Content score error:", error);
    return NextResponse.json(
      { error: "Failed to score content" },
      { status: 500 }
    );
  }
}
