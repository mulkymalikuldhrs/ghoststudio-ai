import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/content/[id]/generate - Generate content using AI agents
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { agentType = "draft", platform, options } = body;

    const contentItem = await db.contentItem.findUnique({
      where: { id },
      include: { variants: true },
    });

    if (!contentItem) {
      return NextResponse.json(
        { error: "Content item not found" },
        { status: 404 }
      );
    }

    // Update status to indicate generation in progress
    await db.contentItem.update({
      where: { id },
      data: { status: "editing" },
    });

    // Log the generation request
    await db.systemLog.create({
      data: {
        service: "ai",
        level: "info",
        action: "content_generate",
        message: `Generating content with ${agentType} agent for: ${contentItem.title}`,
        metadataJson: JSON.stringify({ contentId: id, agentType, platform, options }),
      },
    });

    return NextResponse.json({
      message: "Content generation started",
      contentId: id,
      agentType,
      status: "editing",
    });
  } catch (error) {
    console.error("Content generate error:", error);
    return NextResponse.json(
      { error: "Failed to start content generation" },
      { status: 500 }
    );
  }
}
