import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/content - List content items
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get("workspaceId");
    const status = searchParams.get("status");
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = parseInt(searchParams.get("offset") || "0");

    if (!workspaceId) {
      return NextResponse.json(
        { error: "workspaceId is required" },
        { status: 400 }
      );
    }

    const where: Record<string, unknown> = { workspaceId };
    if (status) {
      where.status = status;
    }

    const [items, total] = await Promise.all([
      db.contentItem.findMany({
        where,
        orderBy: { updatedAt: "desc" },
        take: limit,
        skip: offset,
        include: {
          variants: true,
          seoData: true,
          contentTags: true,
        },
      }),
      db.contentItem.count({ where }),
    ]);

    return NextResponse.json({ items, total, limit, offset });
  } catch (error) {
    console.error("Content list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch content items" },
      { status: 500 }
    );
  }
}

// POST /api/content - Create content item
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      workspaceId,
      title,
      subtitle,
      slug,
      angle,
      topic,
      sourceNotes,
      sourceType,
      masterMarkdown,
    } = body;

    if (!workspaceId || !title || !slug) {
      return NextResponse.json(
        { error: "workspaceId, title, and slug are required" },
        { status: 400 }
      );
    }

    const item = await db.contentItem.create({
      data: {
        workspaceId,
        title,
        subtitle,
        slug,
        angle,
        topic,
        sourceNotes,
        sourceType: sourceType || "idea",
        masterMarkdown,
        status: "idea",
      },
    });

    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    console.error("Content create error:", error);
    return NextResponse.json(
      { error: "Failed to create content item" },
      { status: 500 }
    );
  }
}
