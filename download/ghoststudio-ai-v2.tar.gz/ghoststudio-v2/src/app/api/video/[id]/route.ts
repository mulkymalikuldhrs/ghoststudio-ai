import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/video/[id] - Get video project by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const project = await db.videoProject.findUnique({
      where: { id },
      include: {
        scenes: { orderBy: { order: "asc" } },
        assets: true,
        renderJobs: { orderBy: { createdAt: "desc" }, take: 5 },
      },
    });

    if (!project) {
      return NextResponse.json(
        { error: "Video project not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(project);
  } catch (error) {
    console.error("Video get error:", error);
    return NextResponse.json(
      { error: "Failed to fetch video project" },
      { status: 500 }
    );
  }
}

// PUT /api/video/[id] - Update video project
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const project = await db.videoProject.update({
      where: { id },
      data: body,
    });

    return NextResponse.json(project);
  } catch (error) {
    console.error("Video update error:", error);
    return NextResponse.json(
      { error: "Failed to update video project" },
      { status: 500 }
    );
  }
}

// DELETE /api/video/[id] - Delete video project
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.videoProject.delete({ where: { id } });
    return NextResponse.json({ message: "Video project deleted" });
  } catch (error) {
    console.error("Video delete error:", error);
    return NextResponse.json(
      { error: "Failed to delete video project" },
      { status: 500 }
    );
  }
}
