import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// POST /api/video/[id]/generate - Start video generation pipeline
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { pipeline = "standard", options = {} } = body;

    const project = await db.videoProject.findUnique({
      where: { id },
      include: { scenes: { orderBy: { order: "asc" } } },
    });

    if (!project) {
      return NextResponse.json(
        { error: "Video project not found" },
        { status: 404 }
      );
    }

    // Update project status
    await db.videoProject.update({
      where: { id },
      data: { status: "generating" },
    });

    // Create render job
    const renderJob = await db.videoRenderJob.create({
      data: {
        projectId: id,
        jobType: "full",
        status: "queued",
        configJson: JSON.stringify({ pipeline, options, sceneCount: project.scenes.length }),
      },
    });

    // Log generation start
    await db.systemLog.create({
      data: {
        service: "video_engine",
        level: "info",
        action: "video_generate",
        message: `Video generation started for: ${project.title}`,
        metadataJson: JSON.stringify({ projectId: id, pipeline, renderJobId: renderJob.id }),
      },
    });

    return NextResponse.json({
      message: "Video generation started",
      projectId: id,
      renderJobId: renderJob.id,
      pipeline,
      status: "generating",
    });
  } catch (error) {
    console.error("Video generate error:", error);
    return NextResponse.json(
      { error: "Failed to start video generation" },
      { status: 500 }
    );
  }
}
