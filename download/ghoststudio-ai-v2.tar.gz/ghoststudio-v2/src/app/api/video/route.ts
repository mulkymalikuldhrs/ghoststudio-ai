import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/video - List video projects
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const status = searchParams.get("status");
    const limit = parseInt(searchParams.get("limit") || "20");

    if (!userId) {
      return NextResponse.json(
        { error: "userId is required" },
        { status: 400 }
      );
    }

    const where: Record<string, unknown> = { userId };
    if (status) where.status = status;

    const projects = await db.videoProject.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      take: limit,
      include: {
        scenes: { orderBy: { order: "asc" } },
        _count: { select: { assets: true, renderJobs: true } },
      },
    });

    return NextResponse.json({ projects });
  } catch (error) {
    console.error("Video list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch video projects" },
      { status: 500 }
    );
  }
}

// POST /api/video - Create video project
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      workspaceId,
      title,
      prompt,
      niche = "general",
      style,
      aspectRatio = "9:16",
      voiceId = "alloy",
      subtitleStyle = "default",
      resolution = "1080x1920",
      configJson = {},
    } = body;

    if (!userId || !title) {
      return NextResponse.json(
        { error: "userId and title are required" },
        { status: 400 }
      );
    }

    const project = await db.videoProject.create({
      data: {
        userId,
        workspaceId,
        title,
        prompt,
        niche,
        style,
        aspectRatio,
        voiceId,
        subtitleStyle,
        resolution,
        configJson: JSON.stringify(configJson),
        status: "draft",
      },
    });

    return NextResponse.json(project, { status: 201 });
  } catch (error) {
    console.error("Video create error:", error);
    return NextResponse.json(
      { error: "Failed to create video project" },
      { status: 500 }
    );
  }
}
