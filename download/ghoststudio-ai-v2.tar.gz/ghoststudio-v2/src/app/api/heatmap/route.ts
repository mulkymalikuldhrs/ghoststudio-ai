import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/heatmap - List heatmap clip jobs
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const status = searchParams.get("status");
    const limit = parseInt(searchParams.get("limit") || "20");

    const where: Record<string, unknown> = {};
    if (userId) where.userId = userId;
    if (status) where.status = status;

    const jobs = await db.heatmapClipJob.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: limit,
    });

    return NextResponse.json({ jobs });
  } catch (error) {
    console.error("Heatmap list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch heatmap clip jobs" },
      { status: 500 }
    );
  }
}

// POST /api/heatmap - Create heatmap clip job
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      videoUrl,
      resolution = "1080p",
      outputFormat = "mp4",
      metadataJson = {},
    } = body;

    if (!userId || !videoUrl) {
      return NextResponse.json(
        { error: "userId and videoUrl are required" },
        { status: 400 }
      );
    }

    // Extract YouTube video ID from URL
    const videoIdMatch = videoUrl.match(
      /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
    );
    const videoId = videoIdMatch ? videoIdMatch[1] : null;

    const job = await db.heatmapClipJob.create({
      data: {
        userId,
        videoUrl,
        videoId,
        resolution,
        outputFormat,
        metadataJson: JSON.stringify(metadataJson),
        status: "pending",
      },
    });

    return NextResponse.json(job, { status: 201 });
  } catch (error) {
    console.error("Heatmap create error:", error);
    return NextResponse.json(
      { error: "Failed to create heatmap clip job" },
      { status: 500 }
    );
  }
}
