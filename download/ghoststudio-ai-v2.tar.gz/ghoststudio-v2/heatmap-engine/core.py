"""
GhostStudio AI v2.0 — Heatmap Engine (FastAPI)

Provides YouTube heatmap scanning, video clipping, and subtitle generation.

Architecture inspired by youtube-heatmap-clipper:
  - YouTube page HTML parsing for heatMarkerRenderer data
  - yt-dlp for video downloading
  - faster-whisper for subtitle generation
  - ffmpeg for video clipping and composition

V1: Functional heatmap extraction logic, stubbed download/clip/whisper pipelines.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

import requests
from fastapi import FastAPI, HTTPException, status
from loguru import logger
from pydantic import BaseModel, Field

# ============================================================
# Configuration
# ============================================================

OUTPUT_DIR = os.environ.get("HEATMAP_OUTPUT_DIR", "clips")
MIN_HEATMAP_SCORE = float(os.environ.get("MIN_HEATMAP_SCORE", "0.40"))
MAX_CLIP_DURATION = int(os.environ.get("MAX_CLIP_DURATION", "60"))
MAX_CLIPS_PER_VIDEO = int(os.environ.get("MAX_CLIPS_PER_VIDEO", "10"))
PADDING_SECONDS = int(os.environ.get("PADDING_SECONDS", "10"))
WHISPER_MODEL = os.environ.get("WHISPER_MODEL", "small")
DEFAULT_RESOLUTION = os.environ.get("DEFAULT_RESOLUTION", "1080p")
DEFAULT_FORMAT = os.environ.get("DEFAULT_FORMAT", "mp4")

# ============================================================
# Application Setup
# ============================================================

app = FastAPI(
    title="GhostStudio Heatmap Engine",
    version="2.0.0",
    description="YouTube heatmap scanning, video clipping, and subtitle generation service.",
)

app_start_time = datetime.now(timezone.utc)


# ============================================================
# Enums
# ============================================================


class ClipJobStatus(str, Enum):
    """Clip job processing statuses."""
    pending = "pending"
    downloading = "downloading"
    analyzing = "analyzing"
    clipping = "clipping"
    subtitling = "subtitling"
    completed = "completed"
    failed = "failed"


class OutputFormat(str, Enum):
    """Supported output formats."""
    mp4 = "mp4"
    webm = "webm"


class Resolution(str, Enum):
    """Supported output resolutions."""
    p720 = "720p"
    p1080 = "1080p"
    p4k = "4k"


# ============================================================
# Request Models
# ============================================================


class ScanRequest(BaseModel):
    """Request to scan a YouTube video for heatmap data."""
    url: str = Field(..., description="YouTube video URL (watch, shorts, or youtu.be)")
    min_score: float = Field(default=MIN_HEATMAP_SCORE, ge=0.0, le=1.0, description="Minimum heatmap intensity to include")


class ClipRequest(BaseModel):
    """Request to clip a segment from a YouTube video."""
    url: str = Field(..., description="YouTube video URL")
    start_time: Optional[float] = Field(default=None, ge=0.0, description="Manual clip start time (seconds). Auto-detected if omitted.")
    end_time: Optional[float] = Field(default=None, ge=0.0, description="Manual clip end time (seconds). Auto-detected if omitted.")
    padding: int = Field(default=PADDING_SECONDS, ge=0, le=60, description="Padding seconds before/after detected segment")
    output_format: OutputFormat = Field(default=OutputFormat.mp4, description="Output format")
    resolution: Resolution = Field(default=Resolution.p1080, description="Output resolution")
    generate_subtitles: bool = Field(default=True, description="Generate subtitles via Whisper")
    subtitle_language: Optional[str] = Field(default=None, description="Language code for Whisper (auto-detect if None)")
    crop_mode: str = Field(default="default", description="Crop mode: default, split_left, split_right")
    aspect_ratio: str = Field(default="9:16", description="Output aspect ratio: 9:16, 1:1, 16:9, original")


# ============================================================
# Response Models
# ============================================================


class HeatmapPoint(BaseModel):
    """A single heatmap data point."""
    start: float = Field(description="Start time in seconds")
    duration: float = Field(description="Duration in seconds")
    score: float = Field(description="Normalized intensity score (0-1)")


class ScanResponse(BaseModel):
    """Response from YouTube heatmap scan."""
    video_id: str
    video_title: Optional[str] = None
    channel_name: Optional[str] = None
    total_duration: Optional[int] = None
    heatmap_data: List[HeatmapPoint]
    peak_segments: List[HeatmapPoint]
    segment_count: int


class ClipJobInfo(BaseModel):
    """Clip job tracking information."""
    job_id: str
    video_id: str
    video_url: str
    status: ClipJobStatus
    progress: int = Field(default=0, ge=0, le=100)
    created_at: datetime
    clip_start: Optional[float] = None
    clip_end: Optional[float] = None
    clip_reason: Optional[str] = None
    peak_score: float = 0.0
    output_url: Optional[str] = None
    subtitle_url: Optional[str] = None
    error_message: Optional[str] = None


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    version: str
    uptime_seconds: float
    active_jobs: int
    dependencies: Dict[str, bool]


# ============================================================
# In-Memory Job Store (V1)
# ============================================================

class JobStore:
    """Simple in-memory job tracking for V1."""

    def __init__(self) -> None:
        self._jobs: Dict[str, Dict[str, Any]] = {}

    def create_job(self, video_id: str, video_url: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Create a new clip job and return its ID."""
        job_id = str(uuid.uuid4())
        self._jobs[job_id] = {
            "job_id": job_id,
            "video_id": video_id,
            "video_url": video_url,
            "status": ClipJobStatus.pending,
            "progress": 0,
            "created_at": datetime.now(timezone.utc),
            "clip_start": None,
            "clip_end": None,
            "clip_reason": None,
            "peak_score": 0.0,
            "output_url": None,
            "subtitle_url": None,
            "error_message": None,
            "metadata": metadata or {},
        }
        return job_id

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a job by ID."""
        return self._jobs.get(job_id)

    def update_job(self, job_id: str, **kwargs: Any) -> None:
        """Update job fields."""
        if job_id in self._jobs:
            self._jobs[job_id].update(kwargs)

    def active_count(self) -> int:
        """Count non-terminal jobs."""
        return sum(
            1 for j in self._jobs.values()
            if j["status"] not in (ClipJobStatus.completed, ClipJobStatus.failed)
        )


job_store = JobStore()


# ============================================================
# YouTube Heatmap Extraction (from youtube-heatmap-clipper)
# ============================================================


def extract_video_id(url: str) -> Optional[str]:
    """
    Extract YouTube video ID from various URL formats.

    Supports:
    - https://www.youtube.com/watch?v=VIDEO_ID
    - https://youtu.be/VIDEO_ID
    - https://www.youtube.com/shorts/VIDEO_ID

    Args:
        url: YouTube URL string

    Returns:
        Video ID string or None if URL is invalid
    """
    parsed = urlparse(url)

    if parsed.hostname in ("youtu.be", "www.youtu.be"):
        return parsed.path[1:]

    if parsed.hostname in ("youtube.com", "www.youtube.com", "m.youtube.com"):
        if parsed.path == "/watch":
            return parse_qs(parsed.query).get("v", [None])[0]
        if parsed.path.startswith("/shorts/"):
            return parsed.path.split("/")[2]

    return None


def fetch_heatmap_data(video_id: str, min_score: float = MIN_HEATMAP_SCORE) -> List[HeatmapPoint]:
    """
    Fetch and parse YouTube 'Most Replayed' heatmap data.

    Parses the heatMarkerRenderer from YouTube's page HTML to extract
    engagement intensity data for each segment of the video.

    Args:
        video_id: YouTube video ID
        min_score: Minimum normalized intensity score to include

    Returns:
        List of HeatmapPoint objects sorted by score (descending)
    """
    url = f"https://www.youtube.com/watch?v={video_id}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    }

    logger.info(f"Fetching heatmap data for video: {video_id}")

    try:
        response = requests.get(url, headers=headers, timeout=20)
        response.raise_for_status()
        html = response.text
    except requests.RequestException as e:
        logger.error(f"Failed to fetch YouTube page: {e}")
        return []

    # Parse heatMarkerRenderer data from page HTML
    # YouTube embeds heatmap data as JSON in the page source
    match = re.search(
        r'"markers":\s*(\[.*?\])\s*,\s*"?markersMetadata"?',
        html,
        re.DOTALL,
    )

    if not match:
        logger.warning(f"No heatmap data found for video {video_id}")
        return []

    try:
        markers = json.loads(match.group(1).replace('\\"', '"'))
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse heatmap markers JSON: {e}")
        return []

    results: List[HeatmapPoint] = []

    for marker in markers:
        # Extract heatMarkerRenderer from wrapper
        if "heatMarkerRenderer" in marker:
            marker = marker["heatMarkerRenderer"]

        try:
            score = float(marker.get("intensityScoreNormalized", 0))
            if score >= min_score:
                results.append(HeatmapPoint(
                    start=float(marker["startMillis"]) / 1000,
                    duration=min(float(marker["durationMillis"]) / 1000, MAX_CLIP_DURATION),
                    score=score,
                ))
        except (KeyError, ValueError, TypeError) as e:
            logger.debug(f"Skipping invalid heatmap marker: {e}")
            continue

    # Sort by score (highest engagement first)
    results.sort(key=lambda x: x.score, reverse=True)
    logger.info(f"Found {len(results)} high-engagement segments for video {video_id}")

    return results


def get_video_duration(video_id: str) -> Optional[int]:
    """
    Retrieve the total duration of a YouTube video in seconds.

    Uses yt-dlp to get duration without downloading the video.

    Args:
        video_id: YouTube video ID

    Returns:
        Duration in seconds, or None on failure
    """
    cmd = [
        sys.executable, "-m", "yt_dlp",
        "--get-duration",
        f"https://youtu.be/{video_id}",
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        time_parts = result.stdout.strip().split(":")

        if len(time_parts) == 2:
            return int(time_parts[0]) * 60 + int(time_parts[1])
        if len(time_parts) == 3:
            return int(time_parts[0]) * 3600 + int(time_parts[1]) * 60 + int(time_parts[2])
    except (subprocess.TimeoutExpired, ValueError, IndexError) as e:
        logger.warning(f"Failed to get duration for {video_id}: {e}")

    return None


def get_video_metadata(video_id: str) -> Dict[str, Optional[str]]:
    """
    Extract video title and channel name from YouTube page.

    Args:
        video_id: YouTube video ID

    Returns:
        Dict with 'title' and 'channel' keys
    """
    url = f"https://www.youtube.com/watch?v={video_id}"
    headers = {"User-Agent": "Mozilla/5.0"}

    try:
        response = requests.get(url, headers=headers, timeout=20)
        html = response.text

        # Extract title
        title_match = re.search(r'"title"\s*:\s*"([^"]+)"', html)
        title = title_match.group(1) if title_match else None

        # Extract channel name
        channel_match = re.search(r'"ownerChannelName"\s*:\s*"([^"]+)"', html)
        channel = channel_match.group(1) if channel_match else None

        return {"title": title, "channel": channel}
    except Exception as e:
        logger.warning(f"Failed to get metadata for {video_id}: {e}")
        return {"title": None, "channel": None}


def format_timestamp(seconds: float) -> str:
    """
    Convert seconds to SRT timestamp format (HH:MM:SS,mmm).

    Args:
        seconds: Time in seconds

    Returns:
        SRT-formatted timestamp string
    """
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


# ============================================================
# Background Pipeline Stubs
# ============================================================


async def _run_clip_job(job_id: str, request: ClipRequest) -> None:
    """
    Execute the full clip pipeline.

    Production flow:
    1. Scan heatmap data
    2. Identify peak segments
    3. Download video segment via yt-dlp
    4. Crop/resize via ffmpeg
    5. Generate subtitles via faster-whisper
    6. Burn subtitles via ffmpeg
    7. Upload result to storage

    V1: Functional heatmap scan, stubbed download/render.
    """
    video_id = extract_video_id(request.url)
    if not video_id:
        job_store.update_job(job_id, status=ClipJobStatus.failed, error_message="Invalid YouTube URL")
        return

    try:
        # Step 1: Analyze heatmap
        job_store.update_job(job_id, status=ClipJobStatus.analyzing, progress=10)
        heatmap = fetch_heatmap_data(video_id, min_score=MIN_HEATMAP_SCORE)

        if not heatmap:
            job_store.update_job(
                job_id,
                status=ClipJobStatus.failed,
                progress=10,
                error_message="No high-engagement segments found in heatmap data",
            )
            return

        await asyncio.sleep(1)
        job_store.update_job(job_id, progress=30)

        # Determine clip boundaries
        if request.start_time is not None and request.end_time is not None:
            clip_start = request.start_time
            clip_end = request.end_time
            peak_score = heatmap[0].score if heatmap else 0.0
            clip_reason = "Manual time range specified"
        else:
            # Auto-detect from top heatmap segment
            best = heatmap[0]
            clip_start = max(0, best.start - request.padding)
            clip_end = best.start + best.duration + request.padding
            peak_score = best.score
            clip_reason = f"Peak engagement at {best.start:.1f}s with intensity {best.score:.2f}"

        job_store.update_job(
            job_id,
            progress=40,
            clip_start=clip_start,
            clip_end=clip_end,
            clip_reason=clip_reason,
            peak_score=round(peak_score * 100, 1),
        )

        # Step 2: Download (V1 stub)
        job_store.update_job(job_id, status=ClipJobStatus.downloading, progress=50)
        await asyncio.sleep(3)  # Simulate download
        job_store.update_job(job_id, progress=70)

        # Step 3: Clip (V1 stub)
        job_store.update_job(job_id, status=ClipJobStatus.clipping, progress=75)
        await asyncio.sleep(2)  # Simulate ffmpeg crop
        job_store.update_job(job_id, progress=85)

        # Step 4: Subtitles (V1 stub)
        if request.generate_subtitles:
            job_store.update_job(job_id, status=ClipJobStatus.subtitling, progress=90)
            await asyncio.sleep(2)  # Simulate whisper + burn
            subtitle_url = f"https://storage.example.com/subtitles/{job_id[:8]}.srt"
        else:
            subtitle_url = None

        # Step 5: Finalize
        output_id = str(uuid.uuid4())[:8]
        output_url = f"https://storage.example.com/clips/{output_id}.{request.output_format.value}"

        job_store.update_job(
            job_id,
            status=ClipJobStatus.completed,
            progress=100,
            output_url=output_url,
            subtitle_url=subtitle_url,
        )
        logger.info(f"[Job {job_id}] Clip completed: {output_url}")

    except Exception as e:
        logger.error(f"[Job {job_id}] Clip pipeline failed: {e}")
        job_store.update_job(
            job_id,
            status=ClipJobStatus.failed,
            error_message=str(e),
        )


# ============================================================
# Whisper Subtitle Generation Stub
# ============================================================


async def generate_subtitles(
    video_path: str,
    output_path: str,
    language: Optional[str] = None,
    model_size: str = WHISPER_MODEL,
) -> bool:
    """
    Generate subtitle file using faster-whisper.

    Args:
        video_path: Path to the video file
        output_path: Path to write the SRT file
        language: Language code (auto-detect if None)
        model_size: Whisper model size (tiny, base, small, medium, large)

    Returns:
        True if successful, False otherwise

    V1: Stub implementation. In production, this would:
    1. Load faster_whisper.WhisperModel
    2. Transcribe the video audio
    3. Write SRT format output
    """
    logger.info(f"Subtitle generation requested: model={model_size}, language={language or 'auto'}")

    try:
        # Production code would be:
        # from faster_whisper import WhisperModel
        # model = WhisperModel(model_size, device="cpu", compute_type="int8")
        # segments, info = model.transcribe(video_path, language=language)
        # with open(output_path, "w", encoding="utf-8") as f:
        #     for i, segment in enumerate(segments, start=1):
        #         f.write(f"{i}\n")
        #         f.write(f"{format_timestamp(segment.start)} --> {format_timestamp(segment.end)}\n")
        #         f.write(f"{segment.text.strip()}\n\n")

        logger.info("Subtitle generation stubbed for V1")
        return True

    except Exception as e:
        logger.error(f"Subtitle generation failed: {e}")
        return False


# ============================================================
# API Endpoints
# ============================================================


@app.get("/health", response_model=HealthResponse, tags=["System"])
async def health_check() -> HealthResponse:
    """
    Health check endpoint.

    Returns system status, version, uptime, and dependency availability.
    """
    # Check ffmpeg availability
    import shutil
    ffmpeg_available = bool(shutil.which("ffmpeg"))

    uptime = (datetime.now(timezone.utc) - app_start_time).total_seconds()

    return HealthResponse(
        status="ok",
        version="2.0.0",
        uptime_seconds=uptime,
        active_jobs=job_store.active_count(),
        dependencies={
            "ffmpeg": ffmpeg_available,
            "yt_dlp": True,            # Would check yt-dlp binary
            "faster_whisper": True,     # Would check import availability
        },
    )


@app.post("/api/scan", response_model=ScanResponse, tags=["Heatmap"])
async def scan_youtube_url(request: ScanRequest) -> ScanResponse:
    """
    Scan a YouTube URL for heatmap (Most Replayed) data.

    Fetches the YouTube page HTML, parses heatMarkerRenderer data,
    and returns engagement intensity for each segment.

    This is the first step before clipping — use the returned
    peak_segments to decide what to clip.
    """
    video_id = extract_video_id(request.url)
    if not video_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid YouTube URL. Supported formats: youtube.com/watch?v=..., youtu.be/..., youtube.com/shorts/...",
        )

    # Fetch heatmap data
    heatmap_data = fetch_heatmap_data(video_id, min_score=request.min_score)

    # Get video metadata
    metadata = get_video_metadata(video_id)

    # Get total duration
    total_duration = get_video_duration(video_id)

    # Extract top peak segments (limited)
    peak_segments = heatmap_data[:MAX_CLIPS_PER_VIDEO]

    return ScanResponse(
        video_id=video_id,
        video_title=metadata.get("title"),
        channel_name=metadata.get("channel"),
        total_duration=total_duration,
        heatmap_data=heatmap_data,
        peak_segments=peak_segments,
        segment_count=len(heatmap_data),
    )


@app.post(
    "/api/clip",
    response_model=ClipJobInfo,
    status_code=status.HTTP_202_ACCEPTED,
    tags=["Clipping"],
)
async def clip_video(request: ClipRequest) -> ClipJobInfo:
    """
    Start a video clipping job.

    Downloads a YouTube video, identifies the peak engagement segment
    (or uses manual time range), clips it, optionally generates subtitles,
    and returns the result.

    If start_time and end_time are provided, uses those directly.
    Otherwise, auto-detects from heatmap data.

    Returns a job ID for tracking progress via /api/job/{id}.
    """
    video_id = extract_video_id(request.url)
    if not video_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid YouTube URL. Supported formats: youtube.com/watch?v=..., youtu.be/..., youtube.com/shorts/...",
        )

    # Validate manual time range if provided
    if request.start_time is not None and request.end_time is not None:
        if request.start_time >= request.end_time:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="start_time must be less than end_time",
            )

    # Create job
    job_id = job_store.create_job(
        video_id=video_id,
        video_url=request.url,
        metadata={
            "output_format": request.output_format.value,
            "resolution": request.resolution.value,
            "generate_subtitles": request.generate_subtitles,
            "crop_mode": request.crop_mode,
            "aspect_ratio": request.aspect_ratio,
        },
    )

    # Start background pipeline
    asyncio.create_task(_run_clip_job(job_id, request))

    job = job_store.get_job(job_id)
    assert job is not None

    return ClipJobInfo(
        job_id=job["job_id"],
        video_id=job["video_id"],
        video_url=job["video_url"],
        status=job["status"],
        progress=job["progress"],
        created_at=job["created_at"],
    )


@app.get("/api/job/{job_id}", response_model=ClipJobInfo, tags=["Jobs"])
async def get_job_status(job_id: str) -> ClipJobInfo:
    """
    Get the status of a clipping job.

    Returns current progress, status, output URLs, and any error messages.
    """
    job = job_store.get_job(job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job not found: {job_id}",
        )

    return ClipJobInfo(
        job_id=job["job_id"],
        video_id=job["video_id"],
        video_url=job["video_url"],
        status=job["status"],
        progress=job["progress"],
        created_at=job["created_at"],
        clip_start=job["clip_start"],
        clip_end=job["clip_end"],
        clip_reason=job["clip_reason"],
        peak_score=job["peak_score"],
        output_url=job["output_url"],
        subtitle_url=job["subtitle_url"],
        error_message=job["error_message"],
    )


# ============================================================
# Startup / Shutdown
# ============================================================


@app.on_event("startup")
async def startup() -> None:
    """Initialize services on startup."""
    logger.info("🚀 GhostStudio Heatmap Engine starting up...")
    logger.info(f"   Output directory: {OUTPUT_DIR}")
    logger.info(f"   Min heatmap score: {MIN_HEATMAP_SCORE}")
    logger.info(f"   Whisper model: {WHISPER_MODEL}")
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    logger.info("✅ Heatmap Engine ready")


@app.on_event("shutdown")
async def shutdown() -> None:
    """Cleanup on shutdown."""
    logger.info("🛑 GhostStudio Heatmap Engine shutting down...")


# ============================================================
# Standalone Entry Point
# ============================================================

if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("HEATMAP_ENGINE_PORT", "8001"))
    uvicorn.run(
        "core:app",
        host="0.0.0.0",
        port=port,
        reload=True,
        log_level="info",
    )
