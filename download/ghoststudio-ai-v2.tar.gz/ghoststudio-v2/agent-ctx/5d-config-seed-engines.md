# Task 5d — Configuration, Seed Data, and Python Engines

## Agent: Code Assistant
## Status: COMPLETED

## Summary

Created all 8 required files for GhostStudio AI v2.0's configuration, database seeding, and Python engine services.

## Files Created

### 1. `.env.example`
- Comprehensive environment variables for all services
- Database, NextAuth, OAuth, Stripe, AI, Video/Heatmap engines, Puppeteer, ComfyUI, TTS, Storage (R2), Redis, App config

### 2. `prisma/seed.ts`
- Seeds all 21 Prisma models with interconnected, realistic data
- Uses `hashPassword` from `src/lib/auth.ts` (SHA-256 via Web Crypto API — matches auth system)
- Idempotent: upsert/findFirst patterns for safe re-runs
- Data seeded:
  - 1 admin user (demo@ghoststudio.ai / demo1234)
  - 1 workspace ("GhostStudio HQ") with DNA config
  - 5 content items (published, ready, draft, idea, seo_review)
  - 3 content variants (WordPress, Medium, Twitter)
  - 2 SEO data entries
  - 5 content tags (topic, format, niche categories)
  - 2 publish jobs (published + queued)
  - 3 scheduler jobs (draft_job, seo_job, video_render_job)
  - 5 analytics events
  - 12 memory entries across categories (hook, topic, tone, timing, platform, cta, format, audience, style, video_style, hook_type)
  - 5 energy entries (topic_fatigue, tone_fatigue, publish_saturation, hook_repetition, visual_fatigue)
  - 3 video projects (education/motivation/horror niches)
  - 6 video scenes (2 per project)
  - 2 video assets
  - 5 video templates (modern, elegant, neon, minimal, cartoon)
  - 2 video render jobs
  - 2 heatmap clip jobs
  - 1 subscription (free plan)
  - 2 API keys
  - 2 API credentials (WordPress, OpenRouter)
  - 5 system log entries (across services and levels)

### 3. `video-engine/main.py`
- FastAPI application on port 8000
- Pydantic models for all request/response types with Enums
- Endpoints:
  - GET /health — Health check with service availability
  - POST /api/video/generate — Video generation from prompt (async pipeline)
  - POST /api/video/render — Video rendering from storyboard (async pipeline)
  - GET /api/templates — Template listing with filtering
  - POST /api/tts — Text-to-speech synthesis
  - POST /api/image — AI image generation
  - POST /api/compose — Scene composition with audio
  - GET /api/job/{id} — Job status tracking
- In-memory JobStore for V1
- Background pipeline stubs with realistic progress simulation
- 8 built-in templates across categories

### 4. `video-engine/requirements.txt`
- fastapi, uvicorn, pydantic, python-multipart, httpx, openai, edge-tts, ffmpeg-python, pillow, comfykit, loguru

### 5. `heatmap-engine/core.py`
- FastAPI application on port 8001 (standalone entry point)
- **Functional** YouTube heatmap extraction (parsed from page HTML, same regex as youtube-heatmap-clipper reference)
- Endpoints:
  - GET /health — Health check with dependency availability
  - POST /api/scan — YouTube URL heatmap scanning (functional)
  - POST /api/clip — Video clipping job (async pipeline)
  - GET /api/job/{id} — Job status tracking
- Heatmap extraction: `fetch_heatmap_data()` parses heatMarkerRenderer from YouTube page HTML
- Video metadata extraction, duration via yt-dlp
- SRT timestamp formatting
- Whisper subtitle generation stub
- Configurable via environment variables

### 6. `heatmap-engine/requirements.txt`
- fastapi, uvicorn, requests, yt-dlp, faster-whisper, ffmpeg-python, pydantic, loguru

### 7. `.gitignore`
- Standard Next.js + Python + Prisma + Docker patterns

### 8. `.dockerignore`
- Excludes dev artifacts, node_modules, Python cache, logs, env files

## Design Decisions

1. **Seed auth**: Uses the project's own `hashPassword` from `auth.ts` instead of bcryptjs — no extra dependency needed, passwords match the auth system exactly
2. **Idempotent seed**: Memory entries use `upsert` with the compound unique key; content items use `findFirst` by slug+workspace; video projects by userId+title
3. **Python engines**: V1 stubs with proper Pydantic models and async background tasks — ready for real implementation
4. **Heatmap engine**: Functional YouTube heatmap parsing (the core value prop), stubbed download/render/whisper pipelines
5. **Lint clean**: All TypeScript files pass ESLint checks

## Verification

- Python syntax validated for both engine files
- ESLint passes cleanly
- All 8 files confirmed present in the project
