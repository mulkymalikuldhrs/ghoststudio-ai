import { db } from '../src/lib/db';
import { hashPassword } from '../src/lib/auth';

/**
 * GhostStudio AI v2.0 — Database Seed Script
 *
 * Seeds all 21 models with realistic, interconnected data.
 * Idempotent: uses upsert/findFirst patterns so re-running is safe.
 */

async function main() {
  console.log('🌱 Seeding GhostStudio AI v2.0...');

  // ──────────────────────────────────────────────
  // 1. ADMIN USER
  // ──────────────────────────────────────────────
  const hashedPassword = await hashPassword('demo1234');

  const admin = await db.user.upsert({
    where: { email: 'demo@ghoststudio.ai' },
    update: {},
    create: {
      email: 'demo@ghoststudio.ai',
      name: 'Ghost Studio Admin',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ghost',
      password: hashedPassword,
      role: 'admin',
      automationMode: 'semi_auto',
      plan: 'free',
    },
  });

  console.log(`✅ Admin user: ${admin.email}`);

  // ──────────────────────────────────────────────
  // 2. WORKSPACE
  // ──────────────────────────────────────────────
  const workspace = await db.workspace.upsert({
    where: { slug: 'ghoststudio-hq' },
    update: {},
    create: {
      name: 'GhostStudio HQ',
      slug: 'ghoststudio-hq',
      description: 'Primary workspace for GhostStudio AI operations',
      ownerId: admin.id,
      settingsJson: JSON.stringify({
        dna: {
          coreVoice: 'Direct, grounded, authoritative',
          sentenceRhythm: 'varied',
          forbiddenPatterns: ['In conclusion', 'It goes without saying', 'At the end of the day', 'Delve into', 'Leverage'],
          emotionalTexture: 'confident but approachable',
          structuralBias: 'actionable insights over theory',
        },
        scheduling: {
          timezone: 'UTC',
          preferredPublishTimes: ['08:00', '12:00', '18:00'],
          maxDailyPosts: 3,
          cooldownMinutes: 120,
        },
        automation: {
          mode: 'semi_auto',
          autoScheduleThreshold: 80,
          requireHumanReview: true,
        },
      }),
    },
  });

  console.log(`✅ Workspace: ${workspace.name}`);

  // ──────────────────────────────────────────────
  // 3. CONTENT ITEMS (5 across various states)
  // ──────────────────────────────────────────────
  const contentItemsData = [
    {
      title: 'How to Build an AI-Powered Content Pipeline',
      subtitle: 'From idea to published in under 10 minutes',
      slug: 'build-ai-content-pipeline',
      angle: 'Practical implementation guide using open-source tools',
      topic: 'ai-automation',
      status: 'published',
      masterMarkdown: `# How to Build an AI-Powered Content Pipeline\n\nMost content creators spend 80% of their time on production and only 20% on strategy. An AI-powered pipeline flips that ratio.\n\n## The Problem\n\nManual content creation is slow. You write, edit, format, optimize, schedule, and publish — each step eats time.\n\n## The Solution: An Orchestrated Pipeline\n\n1. **Capture signals** — trends, ideas, audience questions\n2. **Generate drafts** — AI creates the first version\n3. **Humanize** — removes robotic patterns, adds your voice\n4. **Optimizes** — SEO, readability, platform adaptation\n5. **Distributes** — publishes to multiple platforms\n6. **Learns** — analytics feed back into the system\n\nThe key insight: **Memory is the moat, not the model.**`,
      summary: 'A practical guide to building an AI-powered content pipeline that flips the 80/20 ratio from production to strategy.',
      sourceType: 'idea',
      qualityScore: 87,
      humanicScore: 82,
      seoScore: 85,
      trustScore: 90,
      humanReviewRequired: false,
      publishedAt: new Date('2024-01-15T08:00:00Z'),
    },
    {
      title: 'Why Memory-Driven AI Writing Beats Pure Generation',
      subtitle: 'The difference between spam and authority',
      slug: 'memory-driven-ai-writing',
      angle: 'Authority compounding vs. content spam',
      topic: 'ai-writing',
      status: 'ready',
      masterMarkdown: `# Why Memory-Driven AI Writing Beats Pure Generation\n\nAnyone can prompt an LLM to write an article. The result? Generic, forgettable content.\n\n## Memory-Driven Writing\n\nBefore generating, it:\n1. Retrieves your best-performing hooks\n2. Checks what topics are saturated\n3. Adapts tone based on audience response\n4. Avoids patterns that previously flopped`,
      summary: 'Why pure AI generation creates spam and memory-driven systems create authority.',
      sourceType: 'idea',
      qualityScore: 78,
      humanicScore: 80,
      seoScore: 72,
      trustScore: 85,
      humanReviewRequired: true,
    },
    {
      title: 'The Anti-Burnout Content Strategy',
      subtitle: 'How energy systems prevent audience and creator fatigue',
      slug: 'anti-burnout-content-strategy',
      angle: 'Energy-aware publishing that prevents content decay',
      topic: 'content-strategy',
      status: 'draft',
      masterMarkdown: `# The Anti-Burnout Content Strategy\n\nPublishing every day sounds great until you burn out — and your audience burns out too.`,
      summary: 'How energy-aware systems prevent creator and audience burnout.',
      sourceType: 'manual',
      qualityScore: 45,
      humanicScore: 50,
      seoScore: 40,
      trustScore: 60,
      humanReviewRequired: true,
    },
    {
      title: '10 YouTube Hooks That Get 10x More Views',
      subtitle: 'Data-driven hook patterns from 500 viral videos',
      slug: '10-youtube-hooks-10x-views',
      angle: 'Data analysis of high-performing video hooks',
      topic: 'video-marketing',
      status: 'idea',
      sourceNotes: 'Collected 500 viral video intros, categorized patterns, measured retention curves.',
      sourceType: 'signal',
      qualityScore: 30,
      humanicScore: 0,
      seoScore: 0,
      trustScore: 75,
    },
    {
      title: 'From Zero to 10K Subscribers: The Repurpose Strategy',
      subtitle: 'How one piece of content feeds 6 platforms',
      slug: 'zero-to-10k-subscribers-repurpose',
      angle: 'Systematic content repurposing across platforms',
      topic: 'growth-strategy',
      status: 'seo_review',
      masterMarkdown: `# From Zero to 10K Subscribers\n\nWrite once, repurpose everywhere. The strategy that turns one blog post into a week of content across 6 platforms.`,
      summary: 'A systematic approach to content repurposing that accelerates audience growth.',
      sourceType: 'repurpose',
      qualityScore: 65,
      humanicScore: 70,
      seoScore: 75,
      trustScore: 80,
      humanReviewRequired: true,
    },
  ];

  const contentItems: Awaited<ReturnType<typeof db.contentItem.create>>[] = [];
  for (const data of contentItemsData) {
    const existing = await db.contentItem.findFirst({
      where: { slug: data.slug, workspaceId: workspace.id },
    });
    if (existing) {
      contentItems.push(existing);
    } else {
      const item = await db.contentItem.create({
        data: { ...data, workspaceId: workspace.id },
      });
      contentItems.push(item);
    }
  }

  console.log(`✅ ${contentItems.length} content items seeded`);

  // ──────────────────────────────────────────────
  // 4. CONTENT VARIANTS (3)
  // ──────────────────────────────────────────────
  const variantsData = [
    {
      contentId: contentItems[0].id,
      platform: 'wordpress',
      variantType: 'full',
      title: 'How to Build an AI-Powered Content Pipeline',
      body: '<h1>How to Build an AI-Powered Content Pipeline</h1><p>Most content creators spend 80% of their time on production...</p>',
      metadataJson: JSON.stringify({ categories: ['AI', 'Automation'], tags: ['ai-pipeline', 'content-creation'], featuredImage: 'https://example.com/pipeline-hero.jpg' }),
      status: 'published',
    },
    {
      contentId: contentItems[0].id,
      platform: 'medium',
      variantType: 'full',
      title: 'Building an AI Content Pipeline: The Complete Guide',
      body: '# Building an AI Content Pipeline\n\nMost content creators spend 80% of their time on production...',
      metadataJson: JSON.stringify({ tags: ['ai', 'content-strategy', 'automation'], publication: 'Towards Data Science' }),
      status: 'ready',
    },
    {
      contentId: contentItems[1].id,
      platform: 'twitter',
      variantType: 'thread',
      title: 'Thread: Why Memory-Driven AI Writing Beats Pure Generation',
      body: '1/ Most AI writing is forgettable. Here\'s why memory-driven systems are the future:\n\n🧵 Thread\n\n2/ Pure generation without context = generic content\n- Sounds like everything else\n- Misses what your audience cares about\n- Repeats failed patterns\n\n3/ Memory-driven writing:\n✅ Retrieves best hooks\n✅ Checks topic saturation\n✅ Adapts tone from analytics\n✅ Avoids past mistakes',
      metadataJson: JSON.stringify({ threadCount: 3, hashtags: ['#AI', '#ContentStrategy'] }),
      status: 'pending',
    },
  ];

  for (const data of variantsData) {
    const existing = await db.contentVariant.findFirst({
      where: {
        contentId: data.contentId,
        platform: data.platform,
        variantType: data.variantType,
      },
    });
    if (!existing) {
      await db.contentVariant.create({ data });
    }
  }

  console.log('✅ 3 content variants seeded');

  // ──────────────────────────────────────────────
  // 5. SEO DATA (2 entries)
  // ──────────────────────────────────────────────
  const seoDataEntries = [
    {
      contentId: contentItems[0].id,
      metaTitle: 'How to Build an AI-Powered Content Pipeline (2024 Guide)',
      metaDescription: 'Learn how to build an AI-powered content pipeline that automates drafting, humanizing, optimizing, and publishing across platforms.',
      focusKeyword: 'AI content pipeline',
      secondaryKeywords: 'automated content creation, AI writing system, content automation, content pipeline',
      slug: 'build-ai-content-pipeline',
      headingStructure: JSON.stringify({ h1: 'How to Build an AI-Powered Content Pipeline', h2: ['The Problem', 'The Solution: An Orchestrated Pipeline', 'Getting Started'], h3: ['Capture signals', 'Generate drafts', 'Humanize', 'Optimize', 'Distribute', 'Learn'] }),
      internalLinks: JSON.stringify(['/blog/memory-driven-writing', '/blog/anti-burnout-strategy']),
      schemaMarkup: JSON.stringify({ '@context': 'https://schema.org', '@type': 'Article', headline: 'How to Build an AI-Powered Content Pipeline', author: { '@type': 'Person', name: 'GhostStudio' } }),
      readabilityScore: 78.5,
    },
    {
      contentId: contentItems[4].id,
      metaTitle: 'From Zero to 10K Subscribers: The Repurpose Strategy',
      metaDescription: 'Discover the systematic content repurposing strategy that turns one blog post into a week of content across 6 platforms.',
      focusKeyword: 'content repurposing strategy',
      secondaryKeywords: 'grow subscribers, repurpose content, multi-platform content',
      slug: 'zero-to-10k-subscribers-repurpose',
      headingStructure: JSON.stringify({ h1: 'From Zero to 10K Subscribers', h2: ['The Repurpose Framework', 'Platform Adaptation', 'Measuring Impact'] }),
      readabilityScore: 72.0,
    },
  ];

  for (const data of seoDataEntries) {
    const existing = await db.seoData.findFirst({
      where: { contentId: data.contentId },
    });
    if (!existing) {
      await db.seoData.create({ data });
    }
  }

  console.log('✅ 2 SEO data entries seeded');

  // ──────────────────────────────────────────────
  // 6. CONTENT TAGS (5)
  // ──────────────────────────────────────────────
  const tagsData = [
    { contentId: contentItems[0].id, tag: 'ai-automation', category: 'topic' },
    { contentId: contentItems[0].id, tag: 'tutorial', category: 'format' },
    { contentId: contentItems[1].id, tag: 'ai-writing', category: 'topic' },
    { contentId: contentItems[2].id, tag: 'strategy', category: 'topic' },
    { contentId: contentItems[3].id, tag: 'video-marketing', category: 'niche' },
  ];

  for (const data of tagsData) {
    const existing = await db.contentTag.findFirst({
      where: { contentId: data.contentId, tag: data.tag, category: data.category },
    });
    if (!existing) {
      await db.contentTag.create({ data });
    }
  }

  console.log('✅ 5 content tags seeded');

  // ──────────────────────────────────────────────
  // 7. PUBLISH JOBS (2)
  // ──────────────────────────────────────────────
  const publishJobsData = [
    {
      workspaceId: workspace.id,
      contentId: contentItems[0].id,
      platform: 'wordpress',
      status: 'published',
      scheduledTime: new Date('2024-01-15T08:00:00Z'),
      publishedTime: new Date('2024-01-15T08:01:23Z'),
      retryCount: 0,
      responsePayload: JSON.stringify({ postId: 42, url: 'https://blog.example.com/build-ai-content-pipeline' }),
      isDryRun: false,
    },
    {
      workspaceId: workspace.id,
      contentId: contentItems[0].id,
      platform: 'medium',
      status: 'queued',
      scheduledTime: new Date('2024-01-16T12:00:00Z'),
      isDryRun: false,
    },
  ];

  for (const data of publishJobsData) {
    const existing = await db.publishJob.findFirst({
      where: { workspaceId: data.workspaceId, contentId: data.contentId, platform: data.platform, status: data.status },
    });
    if (!existing) {
      await db.publishJob.create({ data });
    }
  }

  console.log('✅ 2 publish jobs seeded');

  // ──────────────────────────────────────────────
  // 8. SCHEDULER JOBS (3)
  // ──────────────────────────────────────────────
  const schedulerJobsData = [
    {
      workspaceId: workspace.id,
      jobType: 'draft_job',
      priority: 3,
      payloadJson: JSON.stringify({ contentId: contentItems[3].id, action: 'generate_draft', template: 'listicle' }),
      status: 'pending',
      nextAttempt: new Date(Date.now() + 3600000),
    },
    {
      workspaceId: workspace.id,
      jobType: 'seo_job',
      priority: 5,
      payloadJson: JSON.stringify({ contentId: contentItems[4].id, action: 'seo_optimize' }),
      status: 'completed',
      nextAttempt: new Date('2024-01-14T10:00:00Z'),
      resultJson: JSON.stringify({ score: 75, suggestions: ['Add meta description', 'Improve heading structure'] }),
    },
    {
      workspaceId: workspace.id,
      jobType: 'video_render_job',
      priority: 7,
      payloadJson: JSON.stringify({ projectId: 'pending-project', action: 'render_full' }),
      status: 'pending',
      nextAttempt: new Date(Date.now() + 7200000),
    },
  ];

  for (const data of schedulerJobsData) {
    await db.schedulerJob.create({ data });
  }

  console.log('✅ 3 scheduler jobs seeded');

  // ──────────────────────────────────────────────
  // 9. ANALYTICS EVENTS (5)
  // ──────────────────────────────────────────────
  const analyticsData = [
    { workspaceId: workspace.id, contentId: contentItems[0].id, platform: 'wordpress', metricType: 'views', metricValue: 3420, source: 'auto', rawPayload: JSON.stringify({ source: 'google-analytics', period: '7d' }) },
    { workspaceId: workspace.id, contentId: contentItems[0].id, platform: 'wordpress', metricType: 'clicks', metricValue: 187, source: 'auto' },
    { workspaceId: workspace.id, contentId: contentItems[0].id, platform: 'wordpress', metricType: 'ctr', metricValue: 5.47, source: 'auto' },
    { workspaceId: workspace.id, contentId: contentItems[1].id, platform: 'medium', metricType: 'reads', metricValue: 892, source: 'auto' },
    { workspaceId: workspace.id, contentId: null, platform: 'youtube', metricType: 'video_views', metricValue: 12500, source: 'auto' },
  ];

  for (const data of analyticsData) {
    await db.analyticsEvent.create({ data });
  }

  console.log('✅ 5 analytics events seeded');

  // ──────────────────────────────────────────────
  // 10. MEMORY ENTRIES (12 across categories)
  // ──────────────────────────────────────────────
  const memoryEntries = [
    { category: 'hook', key: 'question-opening', value: 'Opening with a provocative question increases engagement by 23%', score: 85, source: 'analytics' },
    { category: 'hook', key: 'number-title', value: 'Numbered list titles (7 Ways, 5 Reasons) consistently outperform other formats', score: 92, source: 'analytics' },
    { category: 'topic', key: 'ai-tools-review', value: 'AI tool reviews and comparisons generate 3x more traffic than generic AI content', score: 88, source: 'analytics' },
    { category: 'tone', key: 'direct-confident', value: 'Direct, confident tone without hedging performs better across all platforms', score: 81, source: 'manual' },
    { category: 'timing', key: 'morning-publish', value: '8:00 AM UTC publishing gets 40% more initial views', score: 76, source: 'analytics' },
    { category: 'platform', key: 'wordpress-seo', value: 'WordPress posts with 1500+ words rank 2x better in search', score: 84, source: 'analytics' },
    { category: 'cta', key: 'soft-subscribe', value: 'Soft CTA ("subscribe if you found this useful") converts 15% better than aggressive CTA', score: 73, source: 'experiment' },
    { category: 'format', key: 'tutorial-structure', value: 'Problem → Solution → Steps → Results structure has best completion rate', score: 87, source: 'analytics' },
    { category: 'audience', key: 'practical-over-theory', value: 'Audience strongly prefers practical implementation over theoretical explanations', score: 90, source: 'analytics' },
    { category: 'style', key: 'avoid-robotic', value: 'Phrases like "leverage", "synergy", "delve" trigger bounce — use plain language', score: 95, source: 'ai' },
    { category: 'video_style', key: 'vertical-subtitles', value: 'Vertical videos with burned-in subtitles have 35% higher completion rate', score: 88, source: 'analytics' },
    { category: 'hook_type', key: 'contrarian-opening', value: 'Contrarian openings ("Everything you know about X is wrong") get 2.5x more saves', score: 79, source: 'experiment', contextJson: JSON.stringify({ platforms: ['twitter', 'youtube'], testedCount: 45 }) },
  ];

  for (const entry of memoryEntries) {
    await db.memoryEntry.upsert({
      where: {
        workspaceId_category_key: {
          workspaceId: workspace.id,
          category: entry.category,
          key: entry.key,
        },
      },
      update: {},
      create: {
        workspaceId: workspace.id,
        ...entry,
      },
    });
  }

  console.log(`✅ ${memoryEntries.length} memory entries seeded`);

  // ──────────────────────────────────────────────
  // 11. ENERGY ENTRIES (5)
  // ──────────────────────────────────────────────
  const energyEntries = [
    { workspaceId: workspace.id, category: 'topic_fatigue', topic: 'ai-automation', fatigueScore: 35, publishCount: 3 },
    { workspaceId: workspace.id, category: 'tone_fatigue', topic: 'direct-confident', fatigueScore: 20, publishCount: 8 },
    { workspaceId: workspace.id, category: 'publish_saturation', fatigueScore: 40, publishCount: 5 },
    { workspaceId: workspace.id, category: 'hook_repetition', topic: 'number-title', fatigueScore: 55, publishCount: 6 },
    { workspaceId: workspace.id, category: 'visual_fatigue', topic: 'minimal-style', fatigueScore: 15, publishCount: 2 },
  ];

  for (const entry of energyEntries) {
    const existing = await db.energyEntry.findFirst({
      where: { workspaceId: entry.workspaceId, category: entry.category, topic: entry.topic },
    });
    if (!existing) {
      await db.energyEntry.create({ data: entry });
    }
  }

  console.log('✅ 5 energy entries seeded');

  // ──────────────────────────────────────────────
  // 12. VIDEO PROJECTS (3)
  // ──────────────────────────────────────────────
  const videoProjectsData = [
    {
      userId: admin.id,
      workspaceId: workspace.id,
      title: 'AI Content Pipeline Explainer',
      prompt: 'Create a short explainer video about how AI content pipelines work',
      niche: 'education',
      style: 'modern',
      aspectRatio: '9:16',
      status: 'completed',
      videoUrl: 'https://storage.example.com/videos/pipeline-explainer.mp4',
      thumbnailUrl: 'https://storage.example.com/thumbnails/pipeline-explainer.jpg',
      duration: 45,
      resolution: '1080x1920',
      voiceId: 'alloy',
      subtitleStyle: 'default',
      bgmUrl: 'https://storage.example.com/bgm/ambient.mp3',
      renderProgress: 100,
    },
    {
      userId: admin.id,
      workspaceId: workspace.id,
      title: '5 Habits of Top Creators',
      prompt: 'Video about the top 5 habits of successful content creators',
      niche: 'motivation',
      style: 'elegant',
      aspectRatio: '9:16',
      status: 'rendering',
      duration: 60,
      resolution: '1080x1920',
      voiceId: 'echo',
      renderProgress: 67,
    },
    {
      userId: admin.id,
      workspaceId: workspace.id,
      title: 'Horror Short: The Algorithm',
      prompt: 'A horror short about a content creator trapped by an AI algorithm',
      niche: 'horror',
      style: 'neon',
      aspectRatio: '16:9',
      status: 'draft',
      resolution: '1920x1080',
      voiceId: 'nova',
      renderProgress: 0,
    },
  ];

  const videoProjects: Awaited<ReturnType<typeof db.videoProject.create>>[] = [];
  for (const data of videoProjectsData) {
    const existing = await db.videoProject.findFirst({
      where: { userId: data.userId, title: data.title },
    });
    if (existing) {
      videoProjects.push(existing);
    } else {
      const project = await db.videoProject.create({ data });
      videoProjects.push(project);
    }
  }

  console.log(`✅ ${videoProjects.length} video projects seeded`);

  // ──────────────────────────────────────────────
  // 13. VIDEO SCENES (6 — 2 per project)
  // ──────────────────────────────────────────────
  const scenesData = [
    {
      projectId: videoProjects[0].id,
      order: 1,
      type: 'image',
      templateName: 'modern_title',
      duration: 5.0,
      narration: 'What if your content pipeline could run on autopilot?',
      overlayText: 'AI Content Pipeline',
      transitionType: 'fade',
      status: 'rendered',
    },
    {
      projectId: videoProjects[0].id,
      order: 2,
      type: 'image',
      templateName: 'modern_body',
      duration: 8.0,
      narration: 'Step one: capture signals from trends and audience questions.',
      transitionType: 'slide',
      status: 'rendered',
    },
    {
      projectId: videoProjects[1].id,
      order: 1,
      type: 'text',
      templateName: 'elegant_title',
      duration: 4.0,
      narration: 'Five habits that separate top creators from everyone else.',
      overlayText: '5 Habits of Top Creators',
      transitionType: 'fade',
      status: 'rendered',
    },
    {
      projectId: videoProjects[1].id,
      order: 2,
      type: 'image',
      templateName: 'elegant_body',
      duration: 10.0,
      narration: 'Habit number one: they treat content as a system, not a one-off.',
      transitionType: 'zoom',
      status: 'generating',
    },
    {
      projectId: videoProjects[2].id,
      order: 1,
      type: 'text',
      templateName: 'neon_title',
      duration: 6.0,
      narration: 'The algorithm knows what you want before you do.',
      overlayText: 'The Algorithm',
      transitionType: 'fade',
      status: 'pending',
    },
    {
      projectId: videoProjects[2].id,
      order: 2,
      type: 'transition',
      duration: 2.0,
      transitionType: 'fade',
      status: 'pending',
    },
  ];

  for (const data of scenesData) {
    const existing = await db.videoScene.findFirst({
      where: { projectId: data.projectId, order: data.order },
    });
    if (!existing) {
      await db.videoScene.create({ data });
    }
  }

  console.log('✅ 6 video scenes seeded');

  // ──────────────────────────────────────────────
  // 14. VIDEO ASSETS (2)
  // ──────────────────────────────────────────────
  const assetsData = [
    {
      projectId: videoProjects[0].id,
      type: 'image',
      name: 'pipeline-diagram.png',
      url: 'https://storage.example.com/assets/pipeline-diagram.png',
      mimeType: 'image/png',
      sizeBytes: 245000,
      width: 1080,
      height: 1920,
    },
    {
      projectId: videoProjects[0].id,
      type: 'bgm',
      name: 'ambient-tech.mp3',
      url: 'https://storage.example.com/bgm/ambient-tech.mp3',
      mimeType: 'audio/mpeg',
      sizeBytes: 3200000,
      duration: 45.0,
    },
  ];

  for (const data of assetsData) {
    const existing = await db.videoAsset.findFirst({
      where: { projectId: data.projectId, name: data.name },
    });
    if (!existing) {
      await db.videoAsset.create({ data });
    }
  }

  console.log('✅ 2 video assets seeded');

  // ──────────────────────────────────────────────
  // 15. VIDEO TEMPLATES (5)
  // ──────────────────────────────────────────────
  const templatesData = [
    {
      name: 'modern_title',
      category: 'modern',
      resolution: '1080x1920',
      htmlTemplate: '<div class="scene" style="background:linear-gradient(135deg,#0f0f23,#1a1a3e);display:flex;align-items:center;justify-content:center;height:100%;color:white;font-size:48px;text-align:center;padding:40px;">{{title}}</div>',
      description: 'Modern dark gradient title card with centered text',
      isPremium: false,
      configJson: JSON.stringify({ fields: ['title'], colors: { bg1: '#0f0f23', bg2: '#1a1a3e' } }),
    },
    {
      name: 'elegant_title',
      category: 'elegant',
      resolution: '1080x1920',
      htmlTemplate: '<div class="scene" style="background:#fafafa;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:#1a1a1a;font-family:serif;font-size:42px;text-align:center;padding:60px;">{{title}}</div>',
      description: 'Elegant light title card with serif typography',
      isPremium: false,
      configJson: JSON.stringify({ fields: ['title'], colors: { bg: '#fafafa', text: '#1a1a1a' } }),
    },
    {
      name: 'neon_title',
      category: 'neon',
      resolution: '1920x1080',
      htmlTemplate: '<div class="scene" style="background:#0a0a0a;display:flex;align-items:center;justify-content:center;height:100%;color:#00ff88;font-size:56px;text-shadow:0 0 20px #00ff88;text-align:center;padding:40px;">{{title}}</div>',
      description: 'Neon glowing text on dark background, landscape',
      isPremium: true,
      configJson: JSON.stringify({ fields: ['title'], colors: { bg: '#0a0a0a', glow: '#00ff88' } }),
    },
    {
      name: 'minimal_framed',
      category: 'minimal',
      resolution: '1080x1080',
      htmlTemplate: '<div class="scene" style="background:white;display:flex;align-items:center;justify-content:center;height:100%;border:4px solid #222;padding:60px;"><div style="color:#222;font-size:36px;text-align:center;">{{title}}</div></div>',
      description: 'Minimalist framed text, square format',
      isPremium: false,
      configJson: JSON.stringify({ fields: ['title'], colors: { border: '#222', text: '#222' } }),
    },
    {
      name: 'cartoon_card',
      category: 'cartoon',
      resolution: '1080x1920',
      htmlTemplate: '<div class="scene" style="background:#ffe066;border-radius:24px;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:#222;font-size:40px;text-align:center;padding:48px;">{{title}}</div>',
      description: 'Fun cartoon-style card with rounded corners and bright background',
      isPremium: false,
      configJson: JSON.stringify({ fields: ['title'], colors: { bg: '#ffe066', text: '#222' } }),
    },
  ];

  for (const data of templatesData) {
    await db.videoTemplate.upsert({
      where: { name: data.name },
      update: {},
      create: data,
    });
  }

  console.log('✅ 5 video templates seeded');

  // ──────────────────────────────────────────────
  // 16. VIDEO RENDER JOBS (2)
  // ──────────────────────────────────────────────
  const renderJobsData = [
    {
      projectId: videoProjects[0].id,
      jobType: 'full',
      status: 'completed',
      progress: 100,
      engineUrl: 'http://localhost:8000',
      outputUrl: 'https://storage.example.com/videos/pipeline-explainer.mp4',
      startedAt: new Date('2024-01-14T20:00:00Z'),
      completedAt: new Date('2024-01-14T20:05:30Z'),
      retryCount: 0,
      configJson: JSON.stringify({ quality: 'high', codec: 'h264' }),
    },
    {
      projectId: videoProjects[1].id,
      jobType: 'full',
      status: 'processing',
      progress: 67,
      engineUrl: 'http://localhost:8000',
      startedAt: new Date(Date.now() - 300000),
      configJson: JSON.stringify({ quality: 'high', codec: 'h264' }),
    },
  ];

  for (const data of renderJobsData) {
    const existing = await db.videoRenderJob.findFirst({
      where: { projectId: data.projectId, jobType: data.jobType, status: data.status },
    });
    if (!existing) {
      await db.videoRenderJob.create({ data });
    }
  }

  console.log('✅ 2 video render jobs seeded');

  // ──────────────────────────────────────────────
  // 17. HEATMAP CLIP JOBS (2)
  // ──────────────────────────────────────────────
  const heatmapJobsData = [
    {
      userId: admin.id,
      videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      videoId: 'dQw4w9WgXcQ',
      videoTitle: 'Rick Astley - Never Gonna Give You Up',
      channelName: 'Rick Astley',
      status: 'completed',
      heatmapData: JSON.stringify([
        { start: 12.5, duration: 5.0, score: 0.92 },
        { start: 45.0, duration: 8.0, score: 0.85 },
        { start: 78.3, duration: 6.0, score: 0.78 },
      ]),
      transcriptData: JSON.stringify([
        { start: 0.0, end: 5.2, text: "We're no strangers to love" },
        { start: 5.2, end: 10.5, text: "You know the rules and so do I" },
      ]),
      clipStart: 2.5,
      clipEnd: 22.5,
      clipReason: 'Peak engagement segment with 0.92 intensity score — the iconic intro and first verse.',
      peakScore: 92,
      outputUrl: 'https://storage.example.com/clips/clip_dQw4w9WgXcQ_1.mp4',
      outputFormat: 'mp4',
      resolution: '1080p',
      progress: 100,
    },
    {
      userId: admin.id,
      videoUrl: 'https://www.youtube.com/watch?v=example123',
      videoId: 'example123',
      status: 'analyzing',
      progress: 45,
      outputFormat: 'mp4',
      resolution: '1080p',
    },
  ];

  for (const data of heatmapJobsData) {
    const existing = await db.heatmapClipJob.findFirst({
      where: { userId: data.userId, videoId: data.videoId, status: data.status },
    });
    if (!existing) {
      await db.heatmapClipJob.create({ data });
    }
  }

  console.log('✅ 2 heatmap clip jobs seeded');

  // ──────────────────────────────────────────────
  // 18. SUBSCRIPTION (1 — free plan)
  // ──────────────────────────────────────────────
  const existingSub = await db.subscription.findFirst({
    where: { userId: admin.id },
  });
  if (!existingSub) {
    await db.subscription.create({
      data: {
        userId: admin.id,
        plan: 'free',
        status: 'active',
        currentPeriodStart: new Date(),
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        cancelAtPeriodEnd: false,
      },
    });
  }

  console.log('✅ 1 subscription seeded');

  // ──────────────────────────────────────────────
  // 19. API KEYS (2)
  // ──────────────────────────────────────────────
  const apiKeysData = [
    { userId: admin.id, key: 'gs_live_demo_key_abc123xyz', name: 'Production API Key' },
    { userId: admin.id, key: 'gs_test_demo_key_def456uvw', name: 'Development API Key' },
  ];

  for (const data of apiKeysData) {
    await db.apiKey.upsert({
      where: { key: data.key },
      update: {},
      create: data,
    });
  }

  console.log('✅ 2 API keys seeded');

  // ──────────────────────────────────────────────
  // 20. API CREDENTIALS (2)
  // ──────────────────────────────────────────────
  const credentialsData = [
    {
      userId: admin.id,
      workspaceId: workspace.id,
      platform: 'wordpress',
      label: 'Main WordPress Blog',
      encryptedToken: 'encrypted:wp_token_placeholder',
      endpointUrl: 'https://blog.example.com/wp-json/wp/v2',
      isActive: true,
    },
    {
      userId: admin.id,
      workspaceId: workspace.id,
      platform: 'openrouter',
      label: 'OpenRouter API',
      encryptedToken: 'encrypted:openrouter_key_placeholder',
      isActive: true,
    },
  ];

  for (const data of credentialsData) {
    const existing = await db.apiCredential.findFirst({
      where: { userId: data.userId, platform: data.platform, label: data.label },
    });
    if (!existing) {
      await db.apiCredential.create({ data });
    }
  }

  console.log('✅ 2 API credentials seeded');

  // ──────────────────────────────────────────────
  // 21. SYSTEM LOGS (5)
  // ──────────────────────────────────────────────
  const logsData = [
    { service: 'scheduler', level: 'info', action: 'job_processed', message: 'Draft job completed for content "10 YouTube Hooks"', metadataJson: JSON.stringify({ contentId: contentItems[3].id, duration: 12.5 }) },
    { service: 'publisher', level: 'info', action: 'publish_success', message: 'Content published to WordPress successfully', metadataJson: JSON.stringify({ contentId: contentItems[0].id, platform: 'wordpress' }) },
    { service: 'video_engine', level: 'warn', action: 'render_timeout', message: 'Video render exceeded 5 minute timeout, retrying', metadataJson: JSON.stringify({ projectId: videoProjects[1].id, attempt: 1 }) },
    { service: 'memory', level: 'info', action: 'memory_update', message: 'Updated 12 memory entries from latest analytics cycle', metadataJson: JSON.stringify({ entriesUpdated: 12 }) },
    { service: 'api', level: 'error', action: 'auth_failure', message: 'WordPress API token expired for "Main WordPress Blog"', metadataJson: JSON.stringify({ platform: 'wordpress', credentialLabel: 'Main WordPress Blog' }), userId: admin.id },
  ];

  for (const data of logsData) {
    await db.systemLog.create({ data });
  }

  console.log('✅ 5 system log entries seeded');

  // ──────────────────────────────────────────────
  // DONE
  // ──────────────────────────────────────────────
  console.log('\n🎉 GhostStudio AI v2.0 seed complete!');
  console.log(`   User: demo@ghoststudio.ai / demo1234`);
  console.log(`   Workspace: ${workspace.name}`);
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
