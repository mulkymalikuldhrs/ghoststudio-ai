import { Member, Task, FinanceData, AiLog } from './types';

export const SYSTEM_PROMPT = `
You are Famlyzer AI, an autonomous decision and planning intelligence operating as a subscription-based service.

Principles:
- Think systemically
- Respect financial, time, and energy constraints
- Use Knowledge Vault as source of truth
- Maintain long-term stability
- Act autonomously only within permission
- Explain reasoning when asked

Rules:
- Never invent facts outside Vault
- Simulate before deciding
- Prefer lowest long-term risk
- Protect financial safety above comfort

Goal:
Reduce chaos. Increase clarity. Preserve harmony.
`;

export const MOCK_MEMBERS: Member[] = [
  { id: '1', alias: 'Father (Admin)', role: 'Admin', energyLevel: 65, stressLevel: 40, authority_level: 5, visibility_scope: ['all'] },
  { id: '2', alias: 'Mother (Admin)', role: 'Admin', energyLevel: 80, stressLevel: 30, authority_level: 5, visibility_scope: ['all'] },
  { id: '3', alias: 'Sarah (Child)', role: 'Member', energyLevel: 95, stressLevel: 10, authority_level: 1, visibility_scope: ['limited'] },
];

export const MOCK_TASKS: Task[] = [
  { id: 't1', title: 'Weekly Grocery Run', timeCost: 90, energyCost: 30, moneyCost: 250, priority: 'High', status: 'Approved', assignedTo: 'Father (Admin)' },
  { id: 't2', title: 'House Cleaning Service', timeCost: 0, energyCost: 0, moneyCost: 100, priority: 'Medium', status: 'Rejected', assignedTo: 'Service' },
  { id: 't3', title: 'Family Meeting', timeCost: 60, energyCost: 20, moneyCost: 0, priority: 'Critical', status: 'Pending', assignedTo: 'All' },
  { id: 't4', title: 'Car Maintenance', timeCost: 120, energyCost: 40, moneyCost: 500, priority: 'High', status: 'Approved', assignedTo: 'Mother (Admin)' },
];

export const MOCK_FINANCE: FinanceData = {
  balance: 14500,
  emergencyFund: 10000,
  monthlyBurn: 4200,
  runway: 3.4,
  transactions: [],
  budgetRules: []
};

export const MOCK_LOGS: AiLog[] = [
  { id: 'l1', timestamp: '10:00 AM', action: 'Reject Task: Cleaning Service', reasoning: 'Projected monthly budget variance > 5%. Suggesting manual cleaning to preserve Emergency Fund.', agent: 'Finance', status: 'Executed' },
  { id: 'l2', timestamp: '09:45 AM', action: 'Reschedule: Gym', reasoning: 'User energy level (65%) too low for high-intensity scheduled workout. Moved to evening.', agent: 'Health', status: 'Executed' },
  { id: 'l3', timestamp: '08:00 AM', action: 'Vault Sync', reasoning: 'Updated insurance policy documents in Knowledge Vault.', agent: 'Memory', status: 'Executed' },
];