# Famlyzer AI (v1.2.1 Stable)

**Full Autonomous AI-Driven SaaS for Life, Family, Finance, & Decision Intelligence.**

Famlyzer AI is not just a dashboard; it is an AI agent system that manages time, money, energy, and relationships in a unified system. It operates based on a hierarchy of members, financial constraints, and a "Knowledge Vault" (Single Source of Truth).

## 💎 Design Philosophy: "Cold Glass" & "Auto Resolution"

The UI follows a strict **Premium Glassmorphism** aesthetic that is fully adaptive:
- **Auto Resolution**: Typography and layouts automatically scale from iPhone SE size up to 4K desktop screens using `viewport` intelligence and fluid Tailwind utilities.
- **PWA Native**: Works offline, installs to home screen, and behaves like a native app on iOS/Android.
- **User-Owned Data**: Zero-database architecture. All data lives in your personal Google Drive.

## 🚀 Core Features

### 1. 🏠 Dashboard (Command Center)
- **Real-time Metrics**: Visualizes stress levels vs. energy levels.
- **Financial Runway**: Instant view of liquidity and survival months.
- **AI Log**: A feed of decisions the AI has made autonomously.

### 2. 📅 Planner (Resource Allocation Engine)
- **Responsive Tables**: Horizontal scrolling lists for mobile, expansive data grids for desktop.
- **Auto-Optimization**: AI suggests task assignments based on user energy levels and roles.

### 3. 💸 Finance (Cashflow & Veto)
- **Liquidity Tracking**: Real-time view of assets.
- **Emergency Fund Protection**: Visual gauge for the most sacred asset.
- **AI Veto**: The system can autonomously block expenses (simulated) if they endanger the runway.

### 4. 🗄️ Knowledge Vault (Drive Integration)
- **Direct Sync**: Files uploaded are stored in a dedicated `/FamlyzerAI/vault/` folder in your Google Drive.
- **Context Awareness**: The AI reads these files to understand family rules, insurance policies, and financial statements.

## 🛠 Tech Stack

- **Frontend**: React 19, Tailwind CSS
- **Visualization**: Recharts
- **AI**: Google GenAI SDK (`@google/genai`)
- **Backend**: Google Drive API v3 (REST / Client-side)
- **Auth**: Google Identity Services (OAuth 2.0)
- **PWA**: Service Worker caching, Manifest.json

## 📦 Setup

1. **Google Cloud Console**:
   - Create a project and enable **Google Drive API**.
   - Create OAuth 2.0 Client ID (Web Application).
   - Add your local origin (e.g., `http://localhost:3000`) to Authorized JavaScript origins.

2. **Environment Variables**:
   Create a `.env` file or set variables in your environment:
   ```env
   API_KEY=your_gemini_api_key
   GOOGLE_CLIENT_ID=your_oauth_client_id
   ```

3. **Install Dependencies**:
   ```bash
   npm install
   ```

4. **Run**:
   ```bash
   npm start
   ```

## 🔐 Data Privacy & Ownership
**Famlyzer AI utilizes a "Zero-Server" architecture.**
- We do not have a backend database.
- Your app state is saved as `famlyzer_db.json` in your own Google Drive.
- Your files remain in your Google Drive.
- The AI processes data ephemerally; it does not train on your personal data.

## 📄 License
Private Blueprint. Copyright © 2025 Famlyzer AI.