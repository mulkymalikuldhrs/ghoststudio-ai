// Google Drive Backend Service for Famlyzer AI
// Handles OAuth, File I/O, Folder Structure (/FamlyzerAI/), and Offline Sync (IndexedDB)

import { AppState, WorkspaceType, AutonomousLevel } from '../types';

const CLIENT_ID = process.env.GOOGLE_CLIENT_ID || 'YOUR_CLIENT_ID_HERE'; 
const API_KEY = process.env.API_KEY || ''; 
const DISCOVERY_DOCS = ['https://www.googleapis.com/discovery/v1/apis/drive/v3/rest'];
const SCOPES = 'https://www.googleapis.com/auth/drive.file'; 

// --- IndexedDB Configuration ---
const DB_NAME = 'FamlyzerDB';
const DB_VERSION = 1;
const STORE_NAME = 'appState';
const KEY = 'root';

declare global {
  interface Window {
    google: any;
    gapi: any;
  }
}

export interface DriveUser {
  name: string;
  email: string;
  photoUrl: string;
  isAuthenticated: boolean;
}

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  webViewLink: string;
  createdTime: string;
  size?: string;
}

let tokenClient: any;
let accessToken: string | null = null;
let famlyzerFolderId: string | null = null;
let vaultFolderId: string | null = null;

// Initial State Template
const INITIAL_STATE: AppState = {
  config: {
    type: WorkspaceType.PERSONAL,
    name: 'My Workspace',
    createdAt: new Date().toISOString(),
    autonomousLevel: AutonomousLevel.FULL_AUTO
  },
  members: [
    { id: '1', alias: 'User (Admin)', role: 'Admin', authority_level: 5, energyLevel: 100, stressLevel: 0, visibility_scope: ['all'] }
  ],
  tasks: [],
  finance: {
    balance: 0,
    emergencyFund: 0,
    monthlyBurn: 0,
    runway: 0,
    transactions: [],
    budgetRules: [
        { category: 'Housing', limit: 0, priority: 'Needs'},
        { category: 'Food', limit: 0, priority: 'Needs'},
        { category: 'Lifestyle', limit: 0, priority: 'Wants'}
    ]
  },
  logs: []
};

// --- IndexedDB Helpers ---

const openDB = (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = (event: any) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
            }
        };
        request.onsuccess = (event: any) => resolve(event.target.result);
        request.onerror = (event: any) => reject(event.target.error);
    });
};

const saveToLocalDB = async (state: AppState): Promise<void> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.put(state, KEY);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
};

const loadFromLocalDB = async (): Promise<AppState | null> => {
    try {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(STORE_NAME, 'readonly');
            const store = transaction.objectStore(STORE_NAME);
            const request = store.get(KEY);
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    } catch (e) {
        console.error("IDB Access Error", e);
        return null;
    }
};

// --- Sync Logic ---

const syncLocalToDrive = async () => {
    if (!navigator.onLine || !accessToken || !famlyzerFolderId) return;
    console.log("Network online. Attempting sync...");
    
    try {
        const localData = await loadFromLocalDB();
        if (localData) {
            // Strategy: Last Write Wins (Local overwrites Cloud on reconnection)
            // In a production app, you would compare timestamps here.
            const content = JSON.stringify(localData, null, 2);
            await saveToDrive('famlyzer_db.json', content, 'application/json');
            console.log("Sync complete: Local data pushed to Drive.");
        }
    } catch (e) {
        console.error("Sync failed:", e);
    }
};

// Setup Auto-Sync Listener
if (typeof window !== 'undefined') {
    window.addEventListener('online', syncLocalToDrive);
}


// --- Main Drive Service ---

export const initDriveSystem = async (callback: (user: DriveUser | null) => void) => {
  if (!window.google) return;

  tokenClient = window.google.accounts.oauth2.initTokenClient({
    client_id: CLIENT_ID,
    scope: SCOPES,
    callback: async (tokenResponse: any) => {
      if (tokenResponse.error !== undefined) {
        console.error('Drive Auth Error:', tokenResponse);
        throw tokenResponse;
      }
      accessToken = tokenResponse.access_token;
      await loadGapiClient();
      
      const user: DriveUser = {
        name: "User (Drive Connected)",
        email: "drive@user.com", // In a real app, use People API to get profile
        photoUrl: "",
        isAuthenticated: true
      };
      
      await ensureFolderStructure();
      
      // Trigger a sync check on login
      await syncLocalToDrive();
      
      callback(user);
    },
  });
};

const loadGapiClient = async () => {
    return new Promise<void>((resolve, reject) => {
        window.gapi.load('client', async () => {
            try {
                await window.gapi.client.init({
                    apiKey: API_KEY,
                    discoveryDocs: DISCOVERY_DOCS,
                });
                resolve();
            } catch (e) {
                reject(e);
            }
        });
    });
};

export const connectDrive = () => {
    if(tokenClient) {
        tokenClient.requestAccessToken({prompt: ''});
    } else {
        console.error("Google Identity Services not initialized");
    }
};

const ensureFolderStructure = async () => {
    // 1. Ensure /FamlyzerAI/
    if (!famlyzerFolderId) {
        famlyzerFolderId = await getOrCreateFolder('FamlyzerAI');
    }
    
    // 2. Ensure /FamlyzerAI/vault/
    if (famlyzerFolderId && !vaultFolderId) {
        vaultFolderId = await getOrCreateFolder('vault', famlyzerFolderId);
    }
    
    return famlyzerFolderId;
};

const getOrCreateFolder = async (name: string, parentId?: string): Promise<string | null> => {
    try {
        const query = `name = '${name}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false ${parentId ? `and '${parentId}' in parents` : ''}`;
        const response = await window.gapi.client.drive.files.list({
            q: query,
            fields: 'files(id)',
        });
        
        if (response.result.files && response.result.files.length > 0) {
            return response.result.files[0].id;
        } else {
            const fileMetadata: any = {
                name: name,
                mimeType: 'application/vnd.google-apps.folder',
            };
            if (parentId) {
                fileMetadata.parents = [parentId];
            }
            const createResponse = await window.gapi.client.drive.files.create({
                resource: fileMetadata,
                fields: 'id',
            });
            return createResponse.result.id;
        }
    } catch (err) {
        console.error(`Error ensuring folder ${name}:`, err);
        return null;
    }
};

export const loadAllData = async (): Promise<AppState | null> => {
    // 1. Try Drive First (Source of Truth)
    if (navigator.onLine && famlyzerFolderId) {
        try {
            const data = await loadFromDrive('famlyzer_db.json');
            if (data) {
                const parsed = JSON.parse(data);
                // Update local cache on successful fetch
                await saveToLocalDB(parsed); 
                return parsed;
            }
        } catch (e) {
            console.warn("Drive load failed, falling back to local DB.", e);
        }
    }

    // 2. Fallback to Local DB (Offline or Drive Error)
    console.log("Loading data from Local IndexedDB...");
    return await loadFromLocalDB();
};

export const saveAllData = async (state: AppState) => {
    // 1. Always Save Locally First (Fast & Offline Safe)
    try {
        await saveToLocalDB(state);
    } catch (e) {
        console.error("Local DB Save Failed:", e);
    }

    // 2. Sync to Drive if Online
    if (navigator.onLine && famlyzerFolderId && accessToken) {
        try {
            const content = JSON.stringify(state, null, 2);
            await saveToDrive('famlyzer_db.json', content, 'application/json');
        } catch (err) {
            console.warn("Drive sync failed. Data preserved locally.", err);
        }
    } else {
        console.log("Offline or not authenticated. Changes saved locally.");
    }
};

export const createNewWorkspace = async (type: WorkspaceType, name: string): Promise<AppState> => {
    const newState: AppState = {
        ...INITIAL_STATE,
        config: {
            ...INITIAL_STATE.config,
            type,
            name,
            createdAt: new Date().toISOString()
        }
    };
    await saveAllData(newState);
    return newState;
}

// Vault specific operations
export const listVaultFiles = async (): Promise<DriveFile[]> => {
    if (!navigator.onLine) return []; // Vault requires online for now
    if (!vaultFolderId) return [];
    try {
        const response = await window.gapi.client.drive.files.list({
            q: `'${vaultFolderId}' in parents and trashed = false`,
            fields: 'files(id, name, mimeType, webViewLink, createdTime, size)',
            orderBy: 'createdTime desc'
        });
        return response.result.files || [];
    } catch (err) {
        console.error("Failed to list vault files", err);
        return [];
    }
};

export const uploadToVault = async (file: File): Promise<void> => {
    if (!accessToken || !vaultFolderId) return;
    
    // Convert file to Base64
    const base64Content = await fileToBase64(file);
    
    // Use multipart upload
    await multipartUpload(
        { 
            name: file.name, 
            mimeType: file.type, 
            parents: [vaultFolderId] 
        }, 
        base64Content, 
        file.type,
        true // isBase64
    );
};

// --- Low Level Helpers ---

// Helper to convert File to Base64 string (without data URL prefix)
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            // Remove "data:*/*;base64," prefix to get raw base64
            const base64 = result.split(',')[1];
            resolve(base64);
        };
        reader.onerror = error => reject(error);
    });
};

// Robust Multipart/Related Uploader to avoid 400 Bad Request
const multipartUpload = async (metadata: any, content: string, contentType: string, isBase64: boolean = false, fileId?: string) => {
    if (!accessToken) throw new Error("No access token");

    const boundary = '-------314159265358979323846';
    const delimiter = "\r\n--" + boundary + "\r\n";
    const close_delim = "\r\n--" + boundary + "--";

    let body = delimiter +
        'Content-Type: application/json\r\n\r\n' +
        JSON.stringify(metadata);

    body += delimiter +
        'Content-Type: ' + contentType + '\r\n';
    
    if (isBase64) {
        body += 'Content-Transfer-Encoding: base64\r\n';
    }

    body += '\r\n' + content + close_delim;

    const requestMethod = fileId ? 'PATCH' : 'POST';
    const requestUrl = `https://www.googleapis.com/upload/drive/v3/files${fileId ? '/' + fileId : ''}?uploadType=multipart`;

    const response = await fetch(requestUrl, {
        method: requestMethod,
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: body
    });
    
    if (!response.ok) {
        const errorText = await response.text();
        console.error('Drive Upload Error:', errorText);
        throw new Error(`Drive API Error: ${response.status}`);
    }
    
    return await response.json();
};

const saveToDrive = async (filename: string, content: string, mimeType: string) => {
    if (!accessToken || !famlyzerFolderId) return;
    
    try {
        // Check if file exists
        const listResponse = await window.gapi.client.drive.files.list({
            q: `name = '${filename}' and '${famlyzerFolderId}' in parents and trashed = false`,
            fields: 'files(id)',
        });
        
        const fileId = listResponse.result.files.length > 0 ? listResponse.result.files[0].id : undefined;

        await multipartUpload(
            { 
                name: filename, 
                mimeType: mimeType, 
                parents: fileId ? undefined : [famlyzerFolderId] 
            },
            content,
            mimeType,
            false, // isBase64
            fileId
        );
    } catch (err) {
        console.error(`Failed to save ${filename}:`, err);
        throw err; // Re-throw to handle in saveAllData
    }
};

const loadFromDrive = async (filename: string) => {
    if (!accessToken || !famlyzerFolderId) return null;
    try {
        const listResponse = await window.gapi.client.drive.files.list({
            q: `name = '${filename}' and '${famlyzerFolderId}' in parents and trashed = false`,
            fields: 'files(id)',
        });
        if (listResponse.result.files.length > 0) {
            const fileId = listResponse.result.files[0].id;
            const response = await window.gapi.client.drive.files.get({ fileId: fileId, alt: 'media' });
            return typeof response.result === 'string' ? response.result : JSON.stringify(response.result);
        }
        return null;
    } catch (err) {
        throw err;
    }
};