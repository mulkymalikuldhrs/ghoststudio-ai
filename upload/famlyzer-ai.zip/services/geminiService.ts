import { GoogleGenAI, GenerateContentResponse, Type, Schema } from "@google/genai";
import { SYSTEM_PROMPT } from '../constants';
import { AppState, Task, Member, TaskAssignment, FinancialAudit, FinanceData } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const checkApiKey = (): boolean => {
  if (!apiKey) {
    console.error("FATAL: Google Gemini API Key is missing. Please set REACT_APP_API_KEY or process.env.API_KEY.");
    return false;
  }
  return true;
};

/**
 * 1. PLANNER AGENT
 * Optimizes schedule based on energy levels and task priority.
 */
export const optimizeSchedule = async (tasks: Task[], members: Member[]): Promise<TaskAssignment[]> => {
    if (!checkApiKey()) return [];

    const unassignedTasks = tasks.filter(t => t.status === 'Pending' || t.assignedTo === 'Unassigned');
    if (unassignedTasks.length === 0) return [];

    const context = JSON.stringify({
        tasks: unassignedTasks.map(t => ({ id: t.id, title: t.title, energyCost: t.energyCost, priority: t.priority })),
        members: members.map(m => ({ id: m.id, alias: m.alias, energyLevel: m.energyLevel, role: m.role }))
    });

    const schema: Schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                taskId: { type: Type.STRING },
                assignedToId: { type: Type.STRING, description: "The ID of the member assigned (or 'Unassigned' if no fit)" },
                reasoning: { type: Type.STRING, description: "Short explanation based on energy and priority" }
            },
            required: ["taskId", "assignedToId", "reasoning"]
        }
    };

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `You are the Planner Agent. Assign tasks to members optimally.
            Rules:
            1. High energy cost tasks go to High energy members.
            2. Do not overload stressed members.
            3. Respect roles (Children shouldn't do Admin tasks).
            
            Context: ${context}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
                systemInstruction: SYSTEM_PROMPT
            },
        });

        const jsonStr = response.text || "[]";
        return JSON.parse(jsonStr) as TaskAssignment[];
    } catch (error) {
        console.error("Planner Agent Error:", error);
        return [];
    }
};

/**
 * 2. FINANCE AGENT
 * Audits cashflow and detects hazards.
 */
export const auditFinances = async (finance: FinanceData): Promise<FinancialAudit> => {
    if (!checkApiKey()) return { status: 'Safe', burnRateProjection: 0, recommendations: [], flaggedTransactions: [] };

    const context = JSON.stringify({
        balance: finance.balance,
        emergencyFund: finance.emergencyFund,
        burn: finance.monthlyBurn,
        transactions: finance.transactions.slice(0, 10), // Analyze recent 10
        rules: finance.budgetRules
    });

    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            status: { type: Type.STRING, enum: ["Safe", "Warning", "Critical"] },
            burnRateProjection: { type: Type.NUMBER, description: "Projected monthly burn based on recent transactions" },
            recommendations: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING } 
            },
            flaggedTransactions: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "IDs of transactions that violate rules"
            }
        },
        required: ["status", "burnRateProjection", "recommendations", "flaggedTransactions"]
    };

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `You are the Finance Agent. Audit the financial state.
            Rules:
            1. Safety First. If Emergency Fund < 1000, WARN.
            2. If projected burn > balance, CRITICAL.
            3. Identify wasteful transactions.
            
            Context: ${context}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
                systemInstruction: SYSTEM_PROMPT
            },
        });

        const jsonStr = response.text || "{}";
        return JSON.parse(jsonStr) as FinancialAudit;
    } catch (error) {
        console.error("Finance Agent Error:", error);
        return { status: 'Warning', burnRateProjection: 0, recommendations: ["Agent Offline"], flaggedTransactions: [] };
    }
};


/**
 * 3. CHAT INTERFACE
 * Conversational Context Injection
 */
export const chatWithFamlyzer = async (history: {role: string, parts: {text: string}[]}[], message: string, currentState: AppState) => {
    if (!checkApiKey()) throw new Error("API Key Missing");

    const contextSnapshot = {
        config: currentState.config,
        finances: { 
            balance: currentState.finance.balance, 
            runway: currentState.finance.runway,
            emergency: currentState.finance.emergencyFund
        },
        members: currentState.members.map(m => ({ alias: m.alias, energy: m.energyLevel, stress: m.stressLevel })),
        pendingTaskCount: currentState.tasks.filter(t => t.status === 'Pending').length
    };

    const contextString = `[REAL-TIME SYSTEM STATE]: ${JSON.stringify(contextSnapshot)}`;

    try {
        const chat = ai.chats.create({
            model: 'gemini-3-flash-preview',
            history: [
                { role: 'user', parts: [{ text: `SYSTEM INJECTION: Always consider this state when answering: ${contextString}` }] },
                { role: 'model', parts: [{ text: "Understood. I have loaded the real-time system state into my context window." }] },
                ...history
            ],
            config: {
                systemInstruction: SYSTEM_PROMPT,
            }
        });

        const result: GenerateContentResponse = await chat.sendMessage({ message });
        return result.text;
    } catch (error) {
        console.error("Chat Error:", error);
        throw error;
    }
}
