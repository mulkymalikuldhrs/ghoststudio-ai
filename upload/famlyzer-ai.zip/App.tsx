import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Planner from './components/Planner';
import Finance from './components/Finance';
import Vault from './components/Vault';
import AiAssistant from './components/AiAssistant';
import Onboarding from './components/Onboarding';
import { ViewState, Theme, AppState, WorkspaceType } from './types';
import { initDriveSystem, connectDrive, DriveUser, loadAllData, saveAllData, createNewWorkspace } from './services/driveService';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.DASHBOARD);
  const [theme, setTheme] = useState<Theme>('dark');
  const [user, setUser] = useState<DriveUser | null>(null);
  const [appState, setAppState] = useState<AppState | null>(null);
  const [loading, setLoading] = useState(false);
  const [isTrialExpired, setIsTrialExpired] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    document.body.setAttribute('data-theme', theme);
    const setupDrive = async () => {
        try {
            await initDriveSystem(async (connectedUser) => {
                setUser(connectedUser);
                if (connectedUser) {
                    setLoading(true);
                    const data = await loadAllData();
                    if (data) {
                        setAppState(data);
                        checkTrialStatus(data);
                    } else {
                        setCurrentView(ViewState.ONBOARDING);
                    }
                    setLoading(false);
                }
            });
        } catch (e) {
            console.log("Drive init pending user interaction");
        }
    };
    setupDrive();
  }, [theme]);

  // Central State Update Handler
  const handleStateUpdate = (updates: Partial<AppState>) => {
      if (!appState) return;
      const newState = { ...appState, ...updates };
      setAppState(newState);
      // Persist changes
      saveAllData(newState).catch(e => console.error("Auto-save failed", e));
  };

  const checkTrialStatus = (state: AppState) => {
      const created = new Date(state.config.createdAt);
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - created.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
      if (diffDays > 7) setIsTrialExpired(true);
  };

  const handleOnboardingComplete = async (type: WorkspaceType, name: string) => {
      setLoading(true);
      const newState = await createNewWorkspace(type, name);
      setAppState(newState);
      setCurrentView(ViewState.DASHBOARD);
      setLoading(false);
  };

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  const renderView = () => {
    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center h-[60vh] animate-liquid-pulse">
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-accent to-secondary blur-sm mb-6 animate-spin"></div>
                <div className="text-white/60 font-display tracking-widest text-sm uppercase">Synchronizing Neural Core</div>
            </div>
        );
    }

    if (currentView === ViewState.ONBOARDING) {
        return <Onboarding onComplete={handleOnboardingComplete} />;
    }

    if (!appState) return null; 

    const readOnly = isTrialExpired;

    switch (currentView) {
      case ViewState.DASHBOARD:
        return <Dashboard theme={theme} data={appState} />;
      case ViewState.PLANNER:
        return <Planner theme={theme} data={appState} onUpdate={handleStateUpdate} readOnly={readOnly} />;
      case ViewState.FINANCE:
        return <Finance theme={theme} data={appState} onUpdate={handleStateUpdate} readOnly={readOnly} />;
      case ViewState.VAULT:
        return <Vault theme={theme} data={appState} readOnly={readOnly} />;
      default:
        return <Dashboard theme={theme} data={appState} />;
    }
  };

  const menuItems = [
    { id: ViewState.DASHBOARD, label: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: ViewState.PLANNER, label: 'Plan', icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { id: ViewState.FINANCE, label: 'Finance', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: ViewState.VAULT, label: 'Vault', icon: 'M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v8a2 2 0 01-2 2H5z' },
  ];

  return (
    <div className="min-h-screen font-sans selection:bg-accent/30 selection:text-white overflow-hidden relative transition-colors duration-500 pb-24 md:pb-0">
      
      {/* Living Fluid Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
          <div className={`absolute top-[-10%] left-[-10%] w-[80vw] h-[80vw] rounded-full mix-blend-screen filter blur-[100px] opacity-40 animate-blob ${theme === 'dark' ? 'bg-purple-900' : 'bg-purple-300'}`}></div>
          <div className={`absolute top-[20%] right-[-20%] w-[70vw] h-[70vw] rounded-full mix-blend-screen filter blur-[80px] opacity-30 animate-blob animation-delay-2000 ${theme === 'dark' ? 'bg-blue-900' : 'bg-blue-200'}`} style={{animationDelay: '5s'}}></div>
          <div className={`absolute bottom-[-10%] left-[20%] w-[60vw] h-[60vw] rounded-full mix-blend-screen filter blur-[90px] opacity-30 animate-blob ${theme === 'dark' ? 'bg-teal-900' : 'bg-teal-200'}`} style={{animationDelay: '10s'}}></div>
      </div>

      {!isOnline && (
           <div className="fixed top-0 left-0 right-0 z-[80] bg-red-500/10 backdrop-blur-md border-b border-red-500/20 text-red-200 text-xs font-bold py-2 text-center flex items-center justify-center gap-2">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              OFFLINE MODE: LOCAL CACHE ACTIVE
          </div>
      )}

      {isTrialExpired && (
           <div className="fixed top-0 left-0 right-0 z-[70] bg-gradient-to-r from-red-600 to-orange-600 text-white text-xs font-bold py-3 text-center shadow-lg mt-[32px] md:mt-0 tracking-widest uppercase">
              Free Trial Expired • AI Offline
          </div>
      )}

      {!user && !loading && (
          <div className="fixed top-0 left-0 right-0 z-[60] bg-gradient-to-r from-blue-600/90 to-accent/90 backdrop-blur-md text-white text-xs font-bold py-2 text-center flex justify-center items-center gap-4 shadow-xl border-b border-white/10">
              <span className="tracking-wide hidden md:inline">Connect Drive to enable Liquid Storage.</span>
              <button 
                onClick={connectDrive} 
                className="bg-white/20 hover:bg-white/30 text-white px-4 py-1 rounded-full transition shadow-sm flex items-center gap-2 border border-white/20"
              >
                  Sync Drive
              </button>
          </div>
      )}

      <Sidebar 
        currentView={currentView} 
        setView={setCurrentView} 
        theme={theme}
        toggleTheme={toggleTheme}
      />
      
      <main className={`relative z-10 md:pl-32 p-4 md:p-8 min-h-screen transition-all duration-500 ease-out flex flex-col ${(!user || isTrialExpired || !isOnline) ? 'pt-12' : ''}`}>
          <div className="h-16 md:hidden flex items-center justify-between mb-4 liquid-card rounded-full px-5 mx-1 sticky top-4 z-40">
              <div className="text-xl font-bold flex items-center gap-2">
                 <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-accent to-secondary flex items-center justify-center text-xs text-white shadow-lg">F</div>
                 <span className="font-display tracking-tight">Famlyzer</span>
              </div>
               <div className="flex gap-2">
                    {!user && (
                        <button onClick={connectDrive} className="p-2 bg-blue-500/20 text-blue-400 rounded-full border border-blue-500/20">
                            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M12.002 10.957L16.276 3.655C15.011 2.614 13.513 2 12 2 6.477 2 2 6.477 2 12s4.477 10 10 10c1.865 0 3.606-.51 5.122-1.401l-4.27-7.397H12.002zM19.16 6.314c1.786 1.559 2.84 3.868 2.84 6.372 0 1.259-.282 2.456-.786 3.535l-4.509-7.809L19.16 6.314zM12.002 13.047l-4.28 7.408c1.32.348 2.704.545 4.133.545 2.756 0 5.25-.978 7.21-2.605l-4.253-7.375-2.81 2.027z" /></svg>
                        </button>
                    )}
                   <button className="p-2 bg-white/5 rounded-full border border-white/10" onClick={toggleTheme}>
                       {theme === 'dark' ? '☀️' : '🌙'}
                   </button>
               </div>
          </div>
          
          <div className="max-w-[1600px] mx-auto w-full">
            {renderView()}
          </div>
      </main>

      {currentView !== ViewState.ONBOARDING && (
          <nav className="fixed bottom-6 left-6 right-6 z-50 md:hidden liquid-dock py-4 px-6 flex justify-between items-center rounded-full">
             {menuItems.map((item) => (
                 <button
                    key={item.id}
                    onClick={() => setCurrentView(item.id)}
                    className={`relative transition-all duration-300 ${currentView === item.id ? 'text-accent scale-110' : 'text-muted'}`}
                 >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${currentView === item.id ? 'bg-white/10 shadow-[0_0_15px_rgba(255,255,255,0.2)]' : ''}`}>
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={currentView === item.id ? 2.5 : 1.5} d={item.icon} />
                        </svg>
                    </div>
                 </button>
             ))}
          </nav>
      )}

      {!isTrialExpired && appState && (
        <AiAssistant currentState={appState} />
      )}
    </div>
  );
};

export default App;
