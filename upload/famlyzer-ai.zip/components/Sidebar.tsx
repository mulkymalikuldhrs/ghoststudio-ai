import React from 'react';
import { ViewState, Theme } from '../types';

interface SidebarProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
  theme: Theme;
  toggleTheme: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, theme, toggleTheme }) => {
  const menuItems = [
    { id: ViewState.DASHBOARD, label: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: ViewState.PLANNER, label: 'Plan', icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { id: ViewState.FINANCE, label: 'Finance', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: ViewState.VAULT, label: 'Vault', icon: 'M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v8a2 2 0 01-2 2H5z' },
  ];

  return (
    <aside className="fixed left-6 top-1/2 -translate-y-1/2 z-50 hidden md:flex flex-col gap-6">
      <div className="liquid-dock rounded-full px-3 py-6 flex flex-col items-center gap-8 min-h-[500px] justify-between transition-colors duration-300 border border-white/10 shadow-[0_10px_40px_rgba(0,0,0,0.3)]">
        
        {/* Brand Icon */}
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-white/10 to-white/0 border border-white/20 flex items-center justify-center relative group cursor-pointer shadow-[inset_0_0_10px_rgba(255,255,255,0.1)]">
            <span className="font-display font-bold text-2xl text-transparent bg-clip-text bg-gradient-to-tr from-accent to-secondary">F</span>
            <div className="absolute inset-0 bg-accent/20 blur-xl rounded-full opacity-0 group-hover:opacity-60 transition duration-500"></div>
        </div>

        <nav className="flex flex-col gap-6 flex-1 justify-center w-full">
          {menuItems.map((item) => (
            <div key={item.id} className="relative group flex items-center justify-center w-full">
                <button
                onClick={() => setView(item.id)}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 relative
                    ${currentView === item.id 
                    ? 'text-white bg-accent/20 border border-accent/50 shadow-[0_0_15px_rgba(124,58,237,0.4)]' 
                    : 'text-muted hover:text-white hover:bg-white/10 border border-transparent'}`}
                >
                <svg className={`w-5 h-5`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
                </svg>
                
                {/* Active Fluid Dot */}
                {currentView === item.id && (
                     <div className="absolute -right-1 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-secondary rounded-full shadow-[0_0_10px_#2dd4bf] animate-pulse"></div>
                )}
                </button>

                {/* Liquid Tooltip */}
                <div className="absolute left-16 px-4 py-2 liquid-card rounded-full text-xs font-display font-medium text-main opacity-0 translate-x-[-10px] group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 pointer-events-none whitespace-nowrap z-50 shadow-xl border border-white/10">
                    {item.label}
                </div>
            </div>
          ))}
        </nav>

        <div className="w-full flex flex-col items-center gap-6">
             {/* Theme Toggle */}
             <button 
                onClick={toggleTheme}
                className="w-10 h-10 rounded-full flex items-center justify-center text-muted hover:text-white hover:bg-white/10 transition"
             >
                 {theme === 'dark' ? (
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                 ) : (
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
                 )}
             </button>

             {/* Live Status Pulse */}
             <div className="w-10 h-10 rounded-full border border-emerald-500/20 bg-emerald-500/5 flex items-center justify-center relative">
                <div className="absolute inset-0 bg-emerald-500/10 blur-md rounded-full"></div>
                <div className="w-2 h-2 bg-emerald-400 rounded-full shadow-[0_0_10px_#34d399] animate-pulse relative z-10"></div>
             </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;