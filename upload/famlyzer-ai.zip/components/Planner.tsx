import React, { useState } from 'react';
import { Task, Theme, AppState, AiLog } from '../types';
import { optimizeSchedule } from '../services/geminiService';

interface PlannerProps {
    theme: Theme;
    data: AppState;
    onUpdate: (updates: Partial<AppState>) => void;
    readOnly: boolean;
}

const Planner: React.FC<PlannerProps> = ({ theme, data, onUpdate, readOnly }) => {
  const [activeTab, setActiveTab] = useState<'tasks' | 'resources'>('tasks');
  const [isProcessing, setIsProcessing] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');

  const getStatusStyle = (status: Task['status']) => {
    switch (status) {
      case 'Approved': return 'text-secondary shadow-[0_0_10px_rgba(45,212,191,0.2)]';
      case 'Rejected': return 'text-red-400';
      case 'Pending': return 'text-yellow-400';
      case 'Done': return 'text-slate-400';
      default: return 'text-slate-400';
    }
  };

  const handleAddTask = () => {
      if (!newTaskTitle.trim()) return;
      const newTask: Task = {
          id: Date.now().toString(),
          title: newTaskTitle,
          timeCost: 30, // Default
          energyCost: 20, // Default
          moneyCost: 0,
          priority: 'Medium',
          status: 'Pending',
          assignedTo: 'Unassigned'
      };
      
      onUpdate({
          tasks: [...data.tasks, newTask]
      });
      setNewTaskTitle('');
  };

  const runAutoAssign = async () => {
      if (readOnly) return;
      setIsProcessing(true);
      
      try {
          const assignments = await optimizeSchedule(data.tasks, data.members);
          
          if (assignments.length > 0) {
              const updatedTasks = [...data.tasks];
              const newLogs: AiLog[] = [];

              assignments.forEach(assign => {
                  const taskIndex = updatedTasks.findIndex(t => t.id === assign.taskId);
                  if (taskIndex >= 0) {
                      const memberName = data.members.find(m => m.id === assign.assignedToId)?.alias || 'Unknown';
                      updatedTasks[taskIndex] = {
                          ...updatedTasks[taskIndex],
                          assignedTo: memberName,
                          status: 'Approved' // Auto-approve
                      };
                      
                      newLogs.push({
                          id: Date.now().toString() + Math.random(),
                          timestamp: new Date().toLocaleTimeString(),
                          action: `Assigned: ${updatedTasks[taskIndex].title}`,
                          reasoning: assign.reasoning,
                          agent: 'Planner',
                          status: 'Executed'
                      });
                  }
              });

              onUpdate({
                  tasks: updatedTasks,
                  logs: [...newLogs, ...data.logs] // Prepend new logs
              });
          }
      } catch (e) {
          console.error("Auto Assign Failed", e);
      } finally {
          setIsProcessing(false);
      }
  };

  return (
    <div className="space-y-6 pb-24 animate-fade-in-up">
      {/* Hero Header */}
      <div className="relative liquid-panel p-8 md:p-12 overflow-hidden mb-8 group">
           {/* Dynamic Background */}
           <div className={`absolute top-0 right-0 w-[600px] h-[600px] rounded-full blur-[120px] -mr-32 -mt-32 opacity-30 transition duration-1000 ${theme === 'dark' ? 'bg-secondary/20' : 'bg-accent/20'}`}></div>
           
           <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-end gap-8">
                <div className="flex items-center gap-6">
                    <div className="w-20 h-20 rounded-[2rem] bg-gradient-to-br from-white/10 to-transparent flex items-center justify-center border border-white/20 shadow-[0_10px_30px_rgba(0,0,0,0.3)] backdrop-blur-md flex-shrink-0">
                        <svg className="w-8 h-8 text-white drop-shadow-md" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                    </div>
                    <div>
                        <h2 className="text-xs font-bold text-secondary uppercase tracking-[0.3em] mb-2 glow-text">Allocation Engine</h2>
                        <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tighter text-white">Planner {readOnly && <span className="text-red-400 text-3xl align-middle tracking-normal ml-2 opacity-80">(Locked)</span>}</h1>
                    </div>
                </div>
                
                <div className="flex flex-col md:flex-row gap-4 w-full lg:w-auto">
                     {/* Liquid Tab Switcher */}
                     <div className="liquid-card p-1.5 rounded-full flex w-full md:w-auto border border-white/10">
                         <button 
                            onClick={() => setActiveTab('tasks')}
                            className={`flex-1 md:flex-none px-8 py-3 rounded-full text-sm font-bold transition-all duration-300 ${activeTab === 'tasks' ? 'bg-white text-black shadow-[0_5px_20px_rgba(0,0,0,0.2)]' : 'text-muted hover:text-white'}`}
                         >
                             Tasks
                         </button>
                         <button 
                            onClick={() => setActiveTab('resources')}
                            className={`flex-1 md:flex-none px-8 py-3 rounded-full text-sm font-bold transition-all duration-300 ${activeTab === 'resources' ? 'bg-white text-black shadow-[0_5px_20px_rgba(0,0,0,0.2)]' : 'text-muted hover:text-white'}`}
                         >
                             Resources
                         </button>
                     </div>

                    <button 
                        onClick={runAutoAssign}
                        disabled={readOnly || isProcessing}
                        className={`px-8 py-4 rounded-full font-bold transition-all duration-300 shadow-lg tracking-wide text-sm whitespace-nowrap border border-white/20 active:scale-95 hover:shadow-accent/40 flex items-center gap-2 ${readOnly ? 'bg-white/5 text-white/20 cursor-not-allowed shadow-none' : 'bg-gradient-to-r from-accent to-purple-600 text-white hover:scale-105'}`}
                    >
                        {isProcessing ? (
                            <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> OPTIMIZING...</>
                        ) : (
                            "+ AUTO ASSIGN"
                        )}
                    </button>
                </div>
           </div>
      </div>

      {activeTab === 'tasks' ? (
        /* Liquid List - Tasks */
        <div className="space-y-6">
            {/* Quick Add Task */}
            {!readOnly && (
                <div className="liquid-card p-2 rounded-2xl flex gap-4 items-center pl-6 border border-white/10">
                    <div className="w-2 h-2 rounded-full bg-accent animate-pulse"></div>
                    <input 
                        type="text" 
                        value={newTaskTitle}
                        onChange={(e) => setNewTaskTitle(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddTask()}
                        placeholder="Type new task vector..."
                        className="bg-transparent border-none focus:outline-none flex-1 text-white placeholder-white/30 h-10"
                    />
                    <button onClick={handleAddTask} className="bg-white/10 hover:bg-white text-white hover:text-black rounded-xl w-10 h-10 flex items-center justify-center transition">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
                    </button>
                </div>
            )}

            <div className="liquid-panel p-2 min-h-[400px] overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse min-w-[800px]">
                    <thead>
                        <tr className="text-white/40 text-[10px] uppercase tracking-widest border-b border-white/5">
                        <th className="p-6 pl-8 font-bold w-24">ID</th>
                        <th className="p-6 font-bold">Task Object</th>
                        <th className="p-6 font-bold">Constraints</th>
                        <th className="p-6 font-bold">Vector</th>
                        <th className="p-6 font-bold text-right pr-8">State</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {data.tasks.map((task, index) => (
                        <tr key={task.id} className="hover:bg-white/5 transition-all duration-300 group cursor-default">
                            <td className="p-6 pl-8 text-white/30 text-xs font-mono group-hover:text-white transition">
                                #{task.id.slice(-4)}
                            </td>
                            <td className="p-6">
                            <div className="font-bold text-lg font-display tracking-tight text-white group-hover:translate-x-2 transition duration-300 group-hover:text-secondary">{task.title}</div>
                            <div className="flex items-center gap-2 mt-2">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider border border-white/5 ${
                                    task.priority === 'Critical' ? 'bg-red-500/20 text-red-300' : 
                                    task.priority === 'High' ? 'bg-orange-500/20 text-orange-300' : 'bg-white/5 text-muted'
                                }`}>
                                    {task.priority}
                                </span>
                            </div>
                            </td>
                            <td className="p-6">
                            <div className="flex items-center gap-4 text-sm font-medium text-muted">
                                    {task.timeCost > 0 && <span className="flex items-center gap-1.5 bg-black/20 px-3 py-1.5 rounded-full border border-white/5"><svg className="w-3.5 h-3.5 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> {task.timeCost}m</span>}
                                    {task.moneyCost > 0 && <span className="flex items-center gap-1.5 bg-black/20 px-3 py-1.5 rounded-full border border-white/5"><span className="text-secondary font-bold">$</span>{task.moneyCost}</span>}
                            </div>
                            </td>
                            <td className="p-6">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-white/10 to-transparent flex items-center justify-center text-xs font-bold text-white border border-white/10 shadow-[inset_0_0_10px_rgba(255,255,255,0.1)]">
                                    {task.assignedTo === 'Unassigned' ? '?' : task.assignedTo.charAt(0)}
                                </div>
                                <span className={`text-sm font-medium ${task.assignedTo === 'Unassigned' ? 'text-white/30 italic' : 'text-white/90'}`}>{task.assignedTo}</span>
                            </div>
                            </td>
                            <td className="p-6 pr-8 text-right">
                            <span className={`text-xs font-bold uppercase tracking-wider ${getStatusStyle(task.status)}`}>{task.status}</span>
                            </td>
                        </tr>
                        ))}
                        {data.tasks.length === 0 && (
                            <tr>
                                <td colSpan={5} className="p-12 text-center text-muted">No vectors in queue. Add tasks to initiate.</td>
                            </tr>
                        )}
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
      ) : (
          /* Resource Heatmap View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.members.map(member => (
                  <div key={member.id} className="liquid-panel p-8 relative overflow-hidden group hover:shadow-[0_20px_50px_rgba(124,58,237,0.2)]">
                       <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition duration-500 scale-150 -mr-4 -mt-4">
                           <svg className="w-32 h-32 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg>
                       </div>
                       
                       <div className="relative z-10">
                           <h3 className="text-3xl font-display font-bold mb-1 text-white">{member.alias}</h3>
                           <p className="text-sm text-secondary font-bold uppercase tracking-wider mb-8">{member.role}</p>

                           <div className="space-y-6">
                               <div>
                                   <div className="flex justify-between text-xs font-bold mb-2 text-white/60 uppercase tracking-wide">
                                       <span>Energy Reserve</span>
                                       <span className="text-white">{100 - member.energyLevel}%</span>
                                   </div>
                                   <div className="w-full bg-black/30 h-3 rounded-full overflow-hidden shadow-inner border border-white/5">
                                       <div 
                                        className={`h-full rounded-full shadow-[0_0_15px_currentColor] transition-all duration-1000 ${member.energyLevel < 40 ? 'bg-red-400 text-red-400' : 'bg-secondary text-secondary'}`} 
                                        style={{width: `${100 - member.energyLevel}%`}}
                                       ></div>
                                   </div>
                               </div>

                               <div>
                                   <div className="flex justify-between text-xs font-bold mb-2 text-white/60 uppercase tracking-wide">
                                       <span>Stress Load</span>
                                       <span className="text-white">{member.stressLevel}%</span>
                                   </div>
                                   <div className="w-full bg-black/30 h-3 rounded-full overflow-hidden shadow-inner border border-white/5">
                                       <div 
                                        className="h-full bg-accent rounded-full shadow-[0_0_15px_#7c3aed]" 
                                        style={{width: `${member.stressLevel}%`}}
                                       ></div>
                                   </div>
                               </div>
                           </div>
                       </div>
                  </div>
              ))}
          </div>
      )}
    </div>
  );
};

export default Planner;
