import React, { useEffect, useState } from 'react';
import { Theme, AppState } from '../types';
import { listVaultFiles, uploadToVault, DriveFile } from '../services/driveService';

interface VaultProps {
    theme: Theme;
    data: AppState;
    readOnly: boolean;
}

const Vault: React.FC<VaultProps> = ({ theme, data, readOnly }) => {
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
      loadFiles();
  }, []);

  const loadFiles = async () => {
      setLoading(true);
      const docs = await listVaultFiles();
      setFiles(docs);
      setLoading(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (readOnly || !e.target.files || e.target.files.length === 0) return;
      
      const file = e.target.files[0];
      setUploading(true);
      await uploadToVault(file);
      await loadFiles();
      setUploading(false);
  };

  const formatSize = (bytes?: string) => {
      if (!bytes) return 'Unknown';
      const b = parseInt(bytes);
      if (b < 1024) return b + ' B';
      if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
      return (b / (1024 * 1024)).toFixed(1) + ' MB';
  };

  // Heuristic to guess context type based on filename
  const guessType = (name: string) => {
      const n = name.toLowerCase();
      if (n.includes('budget') || n.includes('invoice') || n.includes('tax')) return 'Finance';
      if (n.includes('health') || n.includes('medical') || n.includes('diet')) return 'Health';
      if (n.includes('rule') || n.includes('constitution') || n.includes('agreement')) return 'Rule';
      return 'General';
  };

  return (
    <div className="space-y-8 pb-20 animate-fade-in-up">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl md:text-6xl font-display font-bold text-white mb-2 tracking-tighter drop-shadow-lg">Knowledge Vault</h2>
          <p className="text-white/50 text-lg">Single Source of Truth. {readOnly && <span className="text-red-400 font-bold ml-2">(READ ONLY)</span>}</p>
        </div>
        <div className="flex gap-4">
            <button 
                onClick={loadFiles}
                className="liquid-card px-6 py-3 rounded-2xl text-white/80 font-bold hover:text-white transition hover:bg-white/10 flex items-center gap-2"
                disabled={loading}
            >
                <svg className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                <span className="hidden md:inline">Sync</span>
            </button>
            <label className={`bg-accent hover:bg-accent/80 text-white px-8 py-3 rounded-2xl font-bold transition cursor-pointer shadow-[0_0_25px_rgba(124,58,237,0.4)] flex items-center gap-2 border border-accent/50 ${readOnly ? 'opacity-50 cursor-not-allowed' : ''}`}>
                {uploading ? 'Uploading...' : '+ Upload'}
                <input 
                    type="file" 
                    className="hidden" 
                    onChange={handleFileUpload} 
                    disabled={readOnly || uploading}
                />
            </label>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* File Grid */}
          <div className="lg:col-span-2 space-y-6">
              <div className="liquid-panel p-6 min-h-[500px]">
                  {files.length === 0 && !loading ? (
                      <div className="flex flex-col items-center justify-center h-full text-white/30">
                          <svg className="w-20 h-20 mb-6 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                          <p className="text-lg">Vault is empty.</p>
                      </div>
                  ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead>
                                <tr className="text-white/40 text-xs uppercase tracking-widest border-b border-white/5">
                                    <th className="p-6 font-bold pl-8">Name</th>
                                    <th className="p-6 font-bold">Vector Type</th>
                                    <th className="p-6 font-bold">Modified</th>
                                    <th className="p-6 font-bold text-right"></th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                                {files.map(doc => (
                                    <tr key={doc.id} className="hover:bg-white/5 transition group">
                                        <td className="p-6 pl-8">
                                            <div className="flex items-center gap-6">
                                                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/60 group-hover:bg-accent/20 group-hover:text-accent transition shadow-inner">
                                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                                </div>
                                                <div>
                                                    <a href={doc.webViewLink} target="_blank" rel="noreferrer" className="text-white text-base font-bold hover:text-secondary transition block mb-1">{doc.name}</a>
                                                    <div className="text-xs text-white/30">{formatSize(doc.size)}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="p-6">
                                            <span className="px-4 py-1.5 rounded-lg text-xs font-bold bg-white/5 text-white/70 border border-white/10 uppercase tracking-wide">
                                                {guessType(doc.name)}
                                            </span>
                                        </td>
                                        <td className="p-6 text-sm text-white/40">{new Date(doc.createdTime).toLocaleDateString()}</td>
                                        <td className="p-6 text-right">
                                            <button className="w-8 h-8 rounded-full flex items-center justify-center text-white/20 hover:text-white hover:bg-white/10 transition">•••</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                  )}
              </div>
          </div>

          {/* Context Info */}
          <div className="lg:col-span-1 space-y-8">
              <div className="liquid-panel p-8">
                  <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-secondary shadow-[0_0_10px_#2dd4bf]"></div>
                      Capacity
                  </h3>
                  <div className="space-y-6">
                      <div className="relative pt-2">
                          <div className="flex justify-between text-xs font-bold text-white/50 mb-3 uppercase tracking-wider">
                              <span>Drive Usage</span>
                              <span>Unlimited</span>
                          </div>
                          <div className="w-full bg-black/30 h-3 rounded-full overflow-hidden border border-white/5 shadow-inner">
                              <div className="bg-gradient-to-r from-accent to-purple-400 h-full rounded-full w-[10%] shadow-[0_0_20px_#8b5cf6]"></div>
                          </div>
                      </div>
                      <div className="pt-8 border-t border-white/5">
                          <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                            <p className="text-xs text-white/60 leading-relaxed font-mono">
                                <span className="text-accent font-bold block mb-2 uppercase tracking-wide">Executive Protocol:</span> 
                                AI decisions are strictly bound to facts found within "Constitution" typed documents and verified PDF contracts.
                            </p>
                          </div>
                      </div>
                  </div>
              </div>

              {!readOnly && (
                <div className="liquid-card rounded-[2.5rem] p-8 border border-yellow-500/30 bg-gradient-to-br from-yellow-500/10 to-transparent relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition duration-500">
                        <svg className="w-32 h-32 text-yellow-500" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"/></svg>
                    </div>
                    <h3 className="text-yellow-200 font-bold text-xl mb-3 relative z-10">Missing Context</h3>
                    <p className="text-sm text-yellow-100/80 mb-6 relative z-10 leading-relaxed">
                        AI needs "Summer Vacation 2024 Budget" to resolve conflicting planner suggestions.
                    </p>
                    <button className="w-full py-3 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-200 rounded-xl text-sm font-bold border border-yellow-500/30 transition relative z-10 cursor-pointer shadow-[0_0_15px_rgba(234,179,8,0.2)]">
                        Upload Context
                    </button>
                </div>
              )}
          </div>
      </div>
    </div>
  );
};

export default Vault;