import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Theme, AppState, AiLog, Transaction } from '../types';
import { auditFinances } from '../services/geminiService';

interface FinanceProps {
    theme: Theme;
    data: AppState;
    onUpdate: (updates: Partial<AppState>) => void;
    readOnly: boolean;
}

const Finance: React.FC<FinanceProps> = ({ theme, data, onUpdate, readOnly }) => {
  const [isAuditing, setIsAuditing] = useState(false);
  const [newAmount, setNewAmount] = useState('');
  const [newDesc, setNewDesc] = useState('');

  // Transform budgetRules for the chart
  const expenseData = data.finance.budgetRules.map(rule => ({
      name: rule.category,
      amount: data.finance.transactions
        .filter(t => t.category === rule.category && t.type === 'Expense')
        .reduce((sum, t) => sum + t.amount, 0),
      limit: rule.limit
  }));

  const emergencyPercentage = data.finance.emergencyFund > 0 
    ? (data.finance.balance / data.finance.emergencyFund) * 100 
    : 0;

  const handleAddTransaction = () => {
      if(!newAmount || !newDesc) return;
      
      const newTx: Transaction = {
          id: Date.now().toString(),
          date: new Date().toISOString(),
          amount: parseFloat(newAmount),
          category: 'Lifestyle', // Default for MVP
          description: newDesc,
          type: 'Expense'
      };

      const newBalance = data.finance.balance - newTx.amount;

      onUpdate({
          finance: {
              ...data.finance,
              balance: newBalance,
              transactions: [newTx, ...data.finance.transactions]
          }
      });
      setNewAmount('');
      setNewDesc('');
  };

  const runAudit = async () => {
      if (readOnly) return;
      setIsAuditing(true);
      try {
          const result = await auditFinances(data.finance);
          
          const newLog: AiLog = {
              id: Date.now().toString(),
              timestamp: new Date().toLocaleTimeString(),
              action: `Financial Audit: ${result.status}`,
              reasoning: result.recommendations.join(". "),
              agent: 'Finance',
              status: 'Executed'
          };

          // Update Monthly Burn based on AI projection
          const newFinance = {
              ...data.finance,
              monthlyBurn: result.burnRateProjection > 0 ? result.burnRateProjection : data.finance.monthlyBurn,
              runway: result.burnRateProjection > 0 ? data.finance.balance / result.burnRateProjection : 0
          };

          onUpdate({
              finance: newFinance,
              logs: [newLog, ...data.logs]
          });

      } catch (e) {
          console.error("Audit failed", e);
      } finally {
          setIsAuditing(false);
      }
  };

  return (
    <div className="space-y-6 md:space-y-8 pb-4 animate-fade-in-up">
      <header className="px-2 flex justify-between items-end">
          <div>
            <h2 className="text-5xl md:text-7xl font-display font-bold text-white tracking-tighter mb-2 drop-shadow-lg">Finance {readOnly && <span className="text-red-400 text-3xl align-middle tracking-normal ml-2 opacity-80">(Locked)</span>}</h2>
            <p className="text-white/40 font-light text-base tracking-wide">Autonomous Cashflow Management</p>
          </div>
          <button 
                onClick={runAudit}
                disabled={isAuditing || readOnly}
                className="bg-white/10 hover:bg-white/20 border border-white/10 text-white font-bold px-6 py-3 rounded-2xl transition flex items-center gap-2"
          >
              {isAuditing ? <span className="animate-spin">⟳</span> : <span className="text-secondary">✦</span>} 
              {isAuditing ? 'Auditing...' : 'Run Audit Agent'}
          </button>
      </header>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="col-span-1 md:col-span-2 liquid-panel p-8 md:p-12 relative overflow-hidden flex flex-col justify-center min-h-[340px] border-t border-white/20">
               <div className="absolute -left-20 top-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-secondary/10 rounded-full blur-[100px] mix-blend-screen"></div>
               
               <h3 className="relative z-10 text-secondary text-xs uppercase font-bold tracking-[0.2em] mb-4 glow-text">Total Liquidity</h3>
               <div className="relative z-10 text-7xl md:text-9xl font-display font-bold text-white mb-10 tracking-tighter drop-shadow-[0_0_30px_rgba(255,255,255,0.2)]">${(data.finance.balance / 1000).toFixed(1)}k</div>
               
               <div className="relative z-10 flex gap-4">
                   <div className="liquid-card px-6 py-4 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl hover:bg-white/10 transition group cursor-default">
                       <span className="text-white/40 text-[10px] uppercase font-bold tracking-wider block mb-1">Monthly Burn</span>
                       <span className="text-white font-bold text-2xl group-hover:text-red-300 transition">${data.finance.monthlyBurn}</span>
                   </div>
                   <div className="liquid-card px-6 py-4 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl hover:bg-white/10 transition group cursor-default">
                       <span className="text-white/40 text-[10px] uppercase font-bold tracking-wider block mb-1">Runway</span>
                       <span className="text-white font-bold text-2xl group-hover:text-emerald-300 transition">{data.finance.runway.toFixed(1)} Mo</span>
                   </div>
               </div>
          </div>

          <div className="col-span-1 liquid-panel p-8 flex flex-col justify-between min-h-[340px]">
              <div>
                <h3 className="text-white/50 text-xs font-bold uppercase tracking-widest mb-2">Reserve Fund</h3>
                <div className="text-4xl font-display font-bold text-white mb-1">${data.finance.emergencyFund.toLocaleString()}</div>
                <div className="text-sm text-white/40 font-mono">Target: $12,000</div>
              </div>
              
              <div className="relative flex items-center justify-center py-8">
                  <div className="w-40 h-40 rounded-full border-4 border-white/5 flex items-center justify-center relative shadow-[inset_0_0_20px_rgba(0,0,0,0.5)] bg-black/20">
                      {/* Fluid Gauge */}
                      <div className="absolute inset-0 rounded-full border-[6px] border-white/10 border-t-transparent opacity-20 rotate-45"></div>
                      <div 
                        className="absolute inset-0 rounded-full border-[6px] border-secondary border-r-transparent border-b-transparent border-l-transparent shadow-[0_0_30px_#2dd4bf] transition-all duration-1000"
                        style={{ transform: `rotate(${45 + (emergencyPercentage * 3.6)}deg)` }}
                      ></div>
                      <span className="text-3xl font-bold text-white font-display drop-shadow-md">{Math.min(emergencyPercentage, 100).toFixed(0)}%</span>
                  </div>
              </div>

              <div className="text-center">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-secondary/10 border border-secondary/20 text-[10px] font-bold uppercase tracking-wide text-secondary shadow-[0_0_15px_rgba(45,212,191,0.2)]">
                       <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                       Sacred Asset
                  </div>
              </div>
          </div>
      </div>

      {/* Quick Transaction Input */}
      {!readOnly && (
          <div className="liquid-card p-4 rounded-3xl flex gap-4 items-center">
              <input 
                type="text" placeholder="Expense Description" 
                value={newDesc} onChange={e => setNewDesc(e.target.value)}
                className="bg-transparent border-b border-white/10 px-4 py-2 flex-1 text-white focus:border-secondary focus:outline-none"
              />
              <input 
                type="number" placeholder="Amount ($)" 
                value={newAmount} onChange={e => setNewAmount(e.target.value)}
                className="bg-transparent border-b border-white/10 px-4 py-2 w-32 text-white focus:border-secondary focus:outline-none"
              />
              <button onClick={handleAddTransaction} className="bg-red-500/20 text-red-200 px-6 py-2 rounded-xl font-bold hover:bg-red-500/40 transition">
                  - Spend
              </button>
          </div>
      )}

      {/* Budget Chart */}
      <div className="liquid-panel p-6 md:p-10">
          <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-bold font-display text-white">Variance Analysis</h3>
              <div className="text-xs font-bold text-white/60 bg-white/5 px-4 py-2 rounded-full uppercase tracking-wide border border-white/5">Current Epoch</div>
          </div>
          <div className="h-72 w-full">
               {expenseData.length > 0 ? (
                   <ResponsiveContainer width="100%" height="100%">
                       <BarChart data={expenseData} layout="vertical" margin={{ top: 0, right: 30, left: 20, bottom: 0 }} barGap={8}>
                           <XAxis type="number" hide />
                           <YAxis dataKey="name" type="category" stroke="rgba(255,255,255,0.3)" width={100} tick={{fontSize: 12, fill: 'rgba(255,255,255,0.7)', fontWeight: 500}} tickLine={false} axisLine={false} />
                           <Tooltip 
                                cursor={{fill: 'rgba(255,255,255,0.05)'}}
                                contentStyle={{ 
                                    backgroundColor: 'rgba(20, 20, 30, 0.8)', 
                                    backdropFilter: 'blur(20px)',
                                    borderColor: 'rgba(255,255,255,0.1)', 
                                    borderRadius: '16px',
                                    color: '#f8fafc',
                                    boxShadow: '0 10px 40px rgba(0,0,0,0.5)'
                                }}
                            />
                           <Bar dataKey="limit" fill="rgba(255,255,255,0.05)" radius={[0, 10, 10, 0]} barSize={24} />
                           <Bar dataKey="amount" radius={[0, 10, 10, 0]} barSize={24}>
                               {expenseData.map((entry, index) => (
                                   <Cell 
                                    key={`cell-${index}`} 
                                    fill={entry.amount > entry.limit ? '#ef4444' : '#f8fafc'} 
                                    filter={entry.amount > entry.limit ? 'drop-shadow(0 0 8px rgba(239,68,68,0.5))' : 'drop-shadow(0 0 5px rgba(255,255,255,0.3))'}
                                   />
                               ))}
                           </Bar>
                       </BarChart>
                   </ResponsiveContainer>
               ) : (
                   <div className="flex items-center justify-center h-full text-muted border-2 border-dashed border-white/5 rounded-3xl">No budget vectors defined.</div>
               )}
          </div>
      </div>

      {/* AI Intervention Log */}
      <div className="liquid-card rounded-[2.5rem] p-8 border border-red-500/30 bg-gradient-to-r from-red-900/20 to-transparent relative overflow-hidden">
          <div className="absolute inset-0 bg-red-500/5 mix-blend-overlay"></div>
          <div className="flex flex-col md:flex-row items-start gap-6 relative z-10">
               <div className="w-16 h-16 rounded-3xl bg-red-500/20 flex items-center justify-center text-red-400 shadow-[0_0_30px_rgba(239,68,68,0.3)] flex-shrink-0 border border-red-500/20">
                   <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
               </div>
               <div className="flex-1">
                   <div className="flex justify-between items-start mb-2">
                       <h4 className="text-2xl font-bold font-display text-white">Auto-Veto Protocol</h4>
                       <span className="text-xs font-bold text-red-200 bg-red-500/20 px-4 py-1.5 rounded-full uppercase tracking-wider border border-red-500/20 shadow-[0_0_15px_rgba(239,68,68,0.2)]">Active</span>
                   </div>
                   <p className="text-white/80 text-lg mb-4">
                       Monitoring real-time transactions for liquidity threats.
                   </p>
                   <p className="text-sm text-red-100/70 font-mono bg-black/30 p-4 rounded-2xl border border-white/5">
                       > "Any transaction exceeding 5% of monthly burn will require biometric approval while Reserve Fund < 100%."
                   </p>
               </div>
          </div>
      </div>
    </div>
  );
};

export default Finance;