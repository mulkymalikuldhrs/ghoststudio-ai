import React, { useState } from 'react';
import { WorkspaceType } from '../types';

interface OnboardingProps {
    onComplete: (type: WorkspaceType, name: string) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
    const [selectedType, setSelectedType] = useState<WorkspaceType | null>(null);
    const [name, setName] = useState('');

    const types = [
        {
            id: WorkspaceType.PERSONAL,
            title: 'Personal',
            desc: 'Optimize your own time, money, and energy.',
            icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z'
        },
        {
            id: WorkspaceType.FAMILY,
            title: 'Family',
            desc: 'Manage household chaos, chores, and harmony.',
            icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z'
        },
        {
            id: WorkspaceType.COMPANY,
            title: 'Company / Team',
            desc: 'Decision intelligence for organizations.',
            icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4'
        }
    ];

    const handleCreate = () => {
        if (selectedType && name.trim()) {
            onComplete(selectedType, name);
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 animate-fade-in-up">
            <div className="text-center mb-10 relative">
                {/* Decoration */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-accent/20 rounded-full blur-[50px] animate-pulse"></div>
                
                <h1 className="relative text-4xl md:text-6xl font-display font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60 drop-shadow-sm">
                    Initialize System
                </h1>
                <p className="text-muted text-lg max-w-xl mx-auto relative">
                    Select your workspace type. This defines how the AI prioritizes resources and handles hierarchy.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl mb-10">
                {types.map((t) => (
                    <button
                        key={t.id}
                        onClick={() => setSelectedType(t.id)}
                        className={`liquid-panel p-8 rounded-[2rem] text-left transition-all duration-300 relative group overflow-hidden ${selectedType === t.id ? 'border-accent bg-accent/10 shadow-[0_0_30px_rgba(139,92,246,0.2)] scale-105' : 'hover:border-white/30 hover:bg-white/5 opacity-80 hover:opacity-100'}`}
                    >
                         <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-4 transition-colors duration-300 ${selectedType === t.id ? 'bg-accent text-white shadow-[0_0_15px_rgba(124,58,237,0.4)]' : 'bg-white/10 text-muted group-hover:text-white'}`}>
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={t.icon} /></svg>
                         </div>
                         <h3 className="text-xl font-bold font-display mb-2 text-white">{t.title}</h3>
                         <p className="text-sm text-muted group-hover:text-white/70 transition-colors">{t.desc}</p>
                         
                         {selectedType === t.id && (
                             <div className="absolute top-4 right-4 text-accent animate-bounce">
                                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                             </div>
                         )}
                    </button>
                ))}
            </div>

            {selectedType && (
                <div className="w-full max-w-md animate-slide-up">
                    <div className="liquid-card p-2 rounded-2xl flex gap-2 border border-white/10 shadow-2xl">
                        <input 
                            type="text" 
                            placeholder={`Name your ${selectedType.toLowerCase()}...`}
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="flex-1 bg-transparent border-none focus:outline-none px-4 text-white placeholder:text-white/20 font-display"
                            autoFocus
                        />
                        <button 
                            onClick={handleCreate}
                            disabled={!name.trim()}
                            className="bg-white text-black font-bold px-6 py-3 rounded-xl hover:bg-white/90 disabled:opacity-50 disabled:cursor-not-allowed transition shadow-[0_0_15px_rgba(255,255,255,0.3)]"
                        >
                            Create
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Onboarding;