import React from 'react';
import { BarChart, Bar, Tooltip, ResponsiveContainer, XAxis, YAxis, Cell } from 'recharts';
import { Theme, AppState } from '../types';

interface DashboardProps {
    theme: Theme;
    data: AppState;
}

const Dashboard: React.FC<DashboardProps> = ({ theme, data }) => {
  const chartStroke = theme === 'dark' ? '#ffffff' : '#475569';
  
  // Real data mapping from members
  const memberData = data.members.map(m => ({
      name: m.alias.split(' ')[0],
      energy: m.energyLevel,
      stress: m.stressLevel
  }));

  const emergencyPercentage = data.finance.emergencyFund > 0 
    ? (data.finance.balance / data.finance.emergencyFund) * 100 
    : 0;

  return (
    <div className="space-y-6 md:space-y-8 pb-4 animate-fade-in-up">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 px-2">
        <div>
            <h2 className="text-4xl md:text-6xl font-display font-bold tracking-tight mb-2 text-transparent bg-clip-text bg-gradient-to-r from-white to-white/50 drop-shadow-sm">
            {data.config.name}
            </h2>
            <div className="flex items-center gap-3">
                <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-white/10 uppercase tracking-widest text-secondary border border-white/5 shadow-inner">{data.config.type}</span>
                <p className="text-muted font-light text-sm tracking-wide">Autonomous System Online</p>
            </div>
        </div>
        
        <div className="liquid-card rounded-full px-2 py-2 flex items-center gap-3 w-full md:w-auto">
             <div className="pl-4 flex items-center gap-2 text-muted flex-1 md:flex-initial">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                <input type="text" placeholder="Query Intelligence..." className="bg-transparent border-none focus:outline-none text-sm w-full md:w-48 placeholder-white/20 font-light text-main" />
             </div>
             <button className="px-6 py-2.5 rounded-full bg-gradient-to-r from-white to-slate-200 text-black text-xs font-bold hover:scale-105 transition shadow-[0_0_20px_rgba(255,255,255,0.3)] whitespace-nowrap active:scale-95">
                 ACT
             </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Metrics Hero */}
        <div className="col-span-1 lg:col-span-7 grid grid-cols-2 gap-4 md:gap-6">
             
             {/* Main Hero Card */}
             <div className="col-span-2 liquid-panel p-8 relative overflow-hidden flex flex-col justify-between min-h-[320px] group">
                {/* Inner Glow */}
                <div className={`absolute top-[-50%] right-[-20%] w-[500px] h-[500px] rounded-full blur-[100px] pointer-events-none opacity-40 transition duration-1000 group-hover:opacity-60 ${theme === 'dark' ? 'bg-accent/30' : 'bg-blue-400/30'}`}></div>
                
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start gap-4">
                    <div>
                        <div className="flex items-center gap-2 mb-4">
                            <span className="w-8 h-8 rounded-full bg-gradient-to-br from-white/10 to-transparent flex items-center justify-center border border-white/10"><svg className="w-4 h-4 text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg></span>
                            <span className="text-secondary font-bold text-xs tracking-widest uppercase glow-text">Runway Projection</span>
                        </div>
                        <h3 className="text-6xl md:text-8xl font-display font-bold tracking-tighter mb-2 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]">{data.finance.runway.toFixed(1)} <span className="text-3xl font-light text-white/30">Mo</span></h3>
                    </div>
                    <div className="liquid-card px-5 py-3 rounded-2xl w-full md:w-auto border border-white/20">
                        <div className="text-3xl font-bold font-display bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60">${(data.finance.balance/1000).toFixed(1)}k</div>
                        <div className="text-[10px] text-muted uppercase tracking-widest text-right">Liquidity</div>
                    </div>
                </div>

                <div className="relative z-10 space-y-4">
                     <div>
                         <div className="flex justify-between text-xs font-medium text-white/60 mb-2">
                             <span>Emergency Fund</span>
                             <span>{Math.min(emergencyPercentage, 100).toFixed(0)}%</span>
                         </div>
                         <div className="w-full bg-black/20 h-3 rounded-full overflow-hidden shadow-inner backdrop-blur-sm border border-white/5">
                             <div className="bg-gradient-to-r from-secondary to-accent h-full rounded-full w-[80%] shadow-[0_0_20px_rgba(45,212,191,0.5)] relative">
                                 <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                             </div>
                         </div>
                     </div>
                </div>
             </div>

             {/* Stat Card 1: Tasks */}
             <div className="col-span-1 liquid-panel p-6 flex flex-col justify-between h-48 md:h-60 group">
                 <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-transparent flex items-center justify-center mb-4 text-emerald-300 border border-emerald-500/10 group-hover:scale-110 transition duration-500 shadow-[0_0_15px_rgba(16,185,129,0.1)]">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                 </div>
                 <div>
                     <div className="text-4xl md:text-5xl font-bold font-display mb-1 text-white">{data.tasks.filter(t => t.status === 'Pending').length}</div>
                     <div className="text-xs font-bold uppercase tracking-wider text-muted">Pending Decisions</div>
                 </div>
             </div>

             {/* Stat Card 2: Energy */}
             <div className="col-span-1 liquid-panel p-6 flex flex-col justify-between h-48 md:h-60 group">
                 <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-accent/20 to-transparent flex items-center justify-center mb-4 text-accent border border-accent/10 group-hover:scale-110 transition duration-500 shadow-[0_0_15px_rgba(124,58,237,0.1)]">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                 </div>
                 <div>
                     <div className="text-4xl md:text-5xl font-bold font-display mb-1 text-white">{data.members.length > 0 ? Math.round(data.members.reduce((acc, m) => acc + m.energyLevel, 0) / data.members.length) : 0}%</div>
                     <div className="text-xs font-bold uppercase tracking-wider text-muted">System Energy</div>
                 </div>
             </div>
        </div>

        {/* Right: Chart (Real Member Stats) */}
        <div className="col-span-1 lg:col-span-5 liquid-panel p-6 md:p-8 flex flex-col">
            <div className="flex justify-between items-center mb-8">
                <h3 className="text-xl font-bold font-display text-white">Neural Stress Index</h3>
                <span className="text-[10px] font-bold text-white/60 bg-white/5 px-3 py-1.5 rounded-full uppercase tracking-wide border border-white/5">Real-Time</span>
            </div>
            
            <div className="flex-1 min-h-[220px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={memberData} barGap={10}>
                        <XAxis dataKey="name" stroke="rgba(255,255,255,0.3)" tick={{fill: 'rgba(255,255,255,0.5)', fontSize: 10}} axisLine={false} tickLine={false} />
                        <Tooltip 
                            contentStyle={{ 
                                backgroundColor: 'rgba(20, 20, 30, 0.6)', 
                                backdropFilter: 'blur(20px)',
                                border: '1px solid rgba(255,255,255,0.1)',
                                borderRadius: '16px',
                                boxShadow: '0 10px 40px rgba(0,0,0,0.5)',
                                color: '#fff' 
                            }} 
                            cursor={{fill: 'rgba(255,255,255,0.05)'}}
                        />
                        <Bar dataKey="stress" name="Stress" fill="#7c3aed" radius={[4, 4, 0, 0]} barSize={20} />
                        <Bar dataKey="energy" name="Energy" fill="#2dd4bf" radius={[4, 4, 0, 0]} barSize={20} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
            
            <div className="mt-6 flex gap-6 text-xs font-bold text-white/50 justify-center uppercase tracking-wider">
                <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-accent shadow-[0_0_10px_#7c3aed]"></span> Stress
                </div>
                <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-secondary shadow-[0_0_10px_#2dd4bf]"></span> Energy
                </div>
            </div>
        </div>
      </div>
      
      {/* AI Log Feed */}
      <div className="liquid-panel p-6 md:p-8">
           <h3 className="text-xl font-bold font-display mb-6 text-white border-b border-white/5 pb-4">Decision Protocol Log</h3>
           <div className="space-y-4">
                {data.logs.length > 0 ? data.logs.map((log, i) => (
                    <div key={i} className="flex items-start gap-4 p-4 rounded-3xl bg-white/5 border border-white/5 hover:bg-white/10 transition group cursor-default">
                         <div className="w-12 h-12 rounded-2xl bg-black/20 flex items-center justify-center text-[10px] font-mono text-muted border border-white/5 shadow-inner">
                             {log.timestamp}
                         </div>
                         <div>
                             <h4 className="font-bold text-sm mb-1 text-white group-hover:text-secondary transition">{log.action}</h4>
                             <p className="text-xs text-muted leading-relaxed max-w-2xl">{log.reasoning}</p>
                             <div className="mt-2 text-[10px] font-bold uppercase tracking-widest text-accent opacity-70">
                                 {log.agent} • {log.status}
                             </div>
                         </div>
                    </div>
                )) : (
                    <div className="text-center text-muted text-sm py-4">No autonomous decisions recorded in current epoch.</div>
                )}
           </div>
      </div>

    </div>
  );
};

export default Dashboard;