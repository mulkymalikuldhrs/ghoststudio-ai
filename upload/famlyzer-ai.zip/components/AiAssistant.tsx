import React, { useState, useEffect, useRef } from 'react';
import { chatWithFamlyzer } from '../services/geminiService';
import { ChatMessage, AppState } from '../types';

interface AiAssistantProps {
    currentState: AppState;
}

const AiAssistant: React.FC<AiAssistantProps> = ({ currentState }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
      { id: '1', role: 'model', text: `I am online. Workspace: ${currentState.config.name}. How can I assist with decision making today?` }
  ]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isThinking) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsThinking(true);

    try {
        const history = messages.map(m => ({
            role: m.role,
            parts: [{ text: m.text }]
        }));
        
        // Inject current real-time state into the chat context
        const responseText = await chatWithFamlyzer(history, input, currentState);
        
        const aiMsg: ChatMessage = { id: (Date.now() + 1).toString(), role: 'model', text: responseText };
        setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "I'm having trouble connecting to the decision core. Please check your API configuration." }]);
    } finally {
        setIsThinking(false);
    }
  };

  return (
    <>
      {/* Trigger Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-8 right-8 z-50 p-4 rounded-full shadow-[0_0_40px_rgba(139,92,246,0.5)] transition-all duration-300 hover:scale-110 active:scale-95 group border border-white/20 backdrop-blur-md
            ${isOpen ? 'bg-slate-900 rotate-45' : 'bg-gradient-to-tr from-accent to-blue-500 animate-liquid-pulse'}`}
      >
        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
        </svg>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-28 right-8 w-96 max-w-[calc(100vw-40px)] h-[600px] liquid-panel rounded-[2rem] shadow-2xl z-50 flex flex-col overflow-hidden animate-fade-in-up border border-white/10">
            {/* Header */}
            <div className="p-5 border-b border-white/5 bg-white/5 flex justify-between items-center backdrop-blur-xl relative z-10">
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center border border-accent/30 shadow-[0_0_15px_rgba(139,92,246,0.3)]">
                        <svg className="w-4 h-4 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </div>
                    <div>
                        <h3 className="text-white font-display font-bold text-sm">Famlyzer Core</h3>
                        <div className="flex items-center gap-1.5">
                             <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                             <p className="text-[10px] text-emerald-400/80 uppercase tracking-wider font-bold">Online</p>
                        </div>
                    </div>
                </div>
                <button onClick={() => setIsOpen(false)} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/10 text-white/40 hover:text-white transition">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6 custom-scrollbar scroll-smooth relative z-10">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[85%] p-4 text-sm leading-relaxed backdrop-blur-md shadow-lg ${
                            msg.role === 'user' 
                            ? 'bg-gradient-to-br from-accent to-purple-600 text-white rounded-[1.5rem] rounded-tr-sm border border-accent/50 shadow-[0_5px_15px_rgba(124,58,237,0.3)]' 
                            : 'liquid-card text-slate-100 rounded-[1.5rem] rounded-tl-sm border border-white/10'
                        }`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                {isThinking && (
                     <div className="flex justify-start">
                        <div className="liquid-card text-slate-400 rounded-2xl p-4 rounded-tl-none border border-white/5 flex items-center gap-2">
                             <span className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce"></span>
                             <span className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce delay-75"></span>
                             <span className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce delay-150"></span>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 bg-black/20 backdrop-blur-md border-t border-white/5 relative z-10">
                <div className="relative">
                    <input 
                        type="text" 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Type a command..." 
                        className="w-full bg-white/5 text-white pl-5 pr-12 py-3.5 rounded-xl border border-white/10 focus:border-accent/50 focus:outline-none focus:bg-white/10 transition-all placeholder:text-white/20 text-sm shadow-inner font-light"
                    />
                    <button 
                        onClick={handleSend}
                        className="absolute right-2 top-2 p-1.5 text-white/40 hover:text-accent transition hover:bg-white/5 rounded-lg"
                    >
                         <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                    </button>
                </div>
            </div>
        </div>
      )}
    </>
  );
};

export default AiAssistant;