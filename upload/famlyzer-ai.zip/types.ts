export enum ViewState {
  ONBOARDING = 'ONBOARDING',
  DASHBOARD = 'DASHBOARD',
  PLANNER = 'PLANNER',
  FINANCE = 'FINANCE',
  VAULT = 'VAULT',
  SETTINGS = 'SETTINGS'
}

export enum WorkspaceType {
  PERSONAL = 'Personal',
  FAMILY = 'Family',
  COMPANY = 'Company'
}

export enum AutonomousLevel {
  OBSERVE = 0,
  SUGGEST = 1,
  ACT_CONFIRM = 2,
  FULL_AUTO = 3
}

export type Theme = 'dark' | 'light';

// Blueprint: Member Schema
export interface Member {
  id: string;
  alias: string; // "Ayah", "Ibu", "Manager"
  role: 'Admin' | 'Member' | 'Guest';
  authority_level: 1 | 2 | 3 | 4 | 5; 
  energyLevel: number; // 0-100
  stressLevel: number; // 0-100
  visibility_scope: string[];
}

// Blueprint: Task Schema
export interface Task {
  id: string;
  title: string;
  description?: string;
  timeCost: number; // minutes
  energyCost: number; // 0-100 impact
  moneyCost: number;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Pending' | 'Approved' | 'Rejected' | 'Done';
  assignedTo: string; // Member ID or 'Unassigned'
  dependencies?: string[]; // IDs of other tasks
}

// Blueprint: Financial Entities
export interface Transaction {
  id: string;
  date: string;
  amount: number;
  category: string;
  description: string;
  type: 'Income' | 'Expense';
}

export interface BudgetRule {
  category: string;
  limit: number;
  priority: 'Needs' | 'Wants' | 'Savings';
}

export interface FinanceData {
  balance: number;
  emergencyFund: number;
  monthlyBurn: number;
  runway: number; // months calculated
  transactions: Transaction[];
  budgetRules: BudgetRule[];
}

export interface WorkspaceConfig {
  type: WorkspaceType;
  name: string;
  createdAt: string; // ISO Date for Trial Logic
  autonomousLevel: AutonomousLevel;
}

// Global App State to Sync with Drive
export interface AppState {
  config: WorkspaceConfig;
  members: Member[];
  tasks: Task[];
  finance: FinanceData;
  logs: AiLog[];
}

export interface AiLog {
  id: string;
  timestamp: string;
  action: string;
  reasoning: string;
  agent: 'Planner' | 'Finance' | 'Health' | 'Executive' | 'Memory';
  status: 'Executed' | 'Pending' | 'Failed';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  isThinking?: boolean;
}

// --- AI Action Types ---

export interface TaskAssignment {
  taskId: string;
  assignedToId: string; // Member ID
  reasoning: string;
}

export interface FinancialAudit {
  status: 'Safe' | 'Warning' | 'Critical';
  burnRateProjection: number;
  recommendations: string[];
  flaggedTransactions: string[]; // IDs
}
