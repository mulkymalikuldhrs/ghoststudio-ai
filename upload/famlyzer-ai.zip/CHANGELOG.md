# Changelog

All notable changes to the **Famlyzer AI** project will be documented in this file.

## [1.2.1] - Stability & Encoding Fixes
- **Drive API Fix**: Resolved "400 Bad Request" errors during file sync. Replaced standard `FormData` upload with a custom `multipart/related` request builder to strictly adhere to Google Drive API requirements for metadata+content uploads.
- **Gemini Service**: Added robust pre-flight checks for API keys and improved error logging for the Autonomous Agent core.
- **Performance**: Optimized base64 conversion logic for large file uploads to the Vault.

## [1.2.0] - Data Ownership Upgrade
- **Backend Migration**: Removed Firebase dependency completely.
- **Drive Integration**: Implemented `driveService.ts` for direct Google Drive file management.
- **Storage Logic**: System now creates and syncs to `/FamlyzerAI/` folder in the user's personal Drive.
- **Auth**: Switched to Google Identity Services (OAuth 2.0) with `drive.file` scope.
- **Vault**: Added file listing and upload capabilities directly linked to the user's cloud storage.

## [1.1.1] - Hotfix
- **Firebase Stability**: Fixed "Component auth has not been registered yet" error by removing conflicting wildcard import in `index.html` and standardizing SDK versions to `10.13.0`.

## [1.1.0] - Connected Core
- **Firebase Integration**: Successfully connected project `studio-2088066079-295af`.
- **Backend Services**: Initialized Authentication and Firestore services in the application layer.

## [1.0.0] - Final Release (Universal & Infinite)

### 📱 PWA & Mobile Native
- **Progressive Web App**: Added `manifest.json` and `sw.js` (Service Worker). The app is now installable and works offline (caches core shell).
- **Mobile Navigation Dock**: Implemented a floating glass bottom bar specifically for mobile users, replacing the sidebar to maximize screen real estate.
- **Viewport Intelligence**: Added `viewport-fit=cover` and safe-area padding to respect iPhone notches and home indicators.

### 🎨 Auto Resolution Design
- **Fluid Typography**: Headers now scale dynamically (`text-3xl` -> `text-5xl`) based on device width.
- **Responsive Tables**: Planner tables now feature overflow scrolling containers to prevent layout breakage on small screens.
- **Adaptive Padding**: Layouts automatically switch between compact mobile padding (`p-4`) and expansive desktop spacing (`p-8`).

---

## [0.3.0] - Daylight & Depth
- **Theme Engine**: Added Light Mode ("Frost" aesthetic) and Dark Mode ("Deep Space").
- **Sub-views**: Added Tab switching for Planner (Tasks vs Resources) and Finance.
- **Visuals**: Charts now adapt colors based on the active theme.

## [0.2.0] - The "Cold Glass" Update
- **New Typography**: Implemented **'Outfit'** font family.
- **Glassmorphism**: High-blur backdrops and deep ambient glows.
- **Layout**: Floating Glass Dock sidebar.

## [0.1.0] - Initial MVP
- Basic React structure.
- Navigation (Dashboard, Planner, Finance, Vault).
- Gemini AI Chat integration.